 * r-COREFERENCE-jmuzerelle_1292100574328: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292100299062']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers **[un métier manuel]** il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans des métiers manuels on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	
 * r-COREFERENCE-jmuzerelle_1292101331774: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292101269216']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers un métier manuel il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans **[des métiers manuels]** on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis tous ces métiers manuels qui sont des métiers rudes d' accord hein mais qui sont des métiers rémunérateurs croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment des petits métiers question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	
 * r-COREFERENCE-jmuzerelle_1292102709610: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292102584083']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers un métier manuel il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans des métiers manuels on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis **[tous ces métiers manuels]** qui sont des métiers rudes d' accord hein mais qui sont des métiers rémunérateurs croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment des petits métiers question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	 oui oui.
	 y a des heures y a des temps morts tout de même.
	 oui oui hum.
	 et qu' est -ce que vous pensez du latin à l' école ?.
	 ah ça je suis pas habileté à vous répondre euh d' après mes fils c' est valable parce que quand même c' est la c' est la la racine de notre langue quand même n' est -ce pas mais mes gosses en ont fait un peu moi eh bien évidemment je peux pas vous parler de ça puisque malheureusement je vous dis j' ai j' ai été qu' à l' école jusqu' à treize ans et j' ai jamais appris un mot de latin.
	
 * r-COREFERENCE-jmuzerelle_1292102747901: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292102607143']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers un métier manuel il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans des métiers manuels on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis tous ces métiers manuels qui sont **[des métiers rudes]** d' accord hein mais qui sont des métiers rémunérateurs croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment des petits métiers question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	 oui oui.
	 y a des heures y a des temps morts tout de même.
	 oui oui hum.
	 et qu' est -ce que vous pensez du latin à l' école ?.
	 ah ça je suis pas habileté à vous répondre euh d' après mes fils c' est valable parce que quand même c' est la c' est la la racine de notre langue quand même n' est -ce pas mais mes gosses en ont fait un peu moi eh bien évidemment je peux pas vous parler de ça puisque malheureusement je vous dis j' ai j' ai été qu' à l' école jusqu' à treize ans et j' ai jamais appris un mot de latin.
	
 * r-COREFERENCE-jmuzerelle_1292103123139: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292102772196']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers un métier manuel il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans des métiers manuels on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis tous ces métiers manuels qui sont des métiers rudes d' accord hein mais qui sont **[des métiers rémunérateurs]** croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment des petits métiers question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	 oui oui.
	 y a des heures y a des temps morts tout de même.
	 oui oui hum.
	 et qu' est -ce que vous pensez du latin à l' école ?.
	 ah ça je suis pas habileté à vous répondre euh d' après mes fils c' est valable parce que quand même c' est la c' est la la racine de notre langue quand même n' est -ce pas mais mes gosses en ont fait un peu moi eh bien évidemment je peux pas vous parler de ça puisque malheureusement je vous dis j' ai j' ai été qu' à l' école jusqu' à treize ans et j' ai jamais appris un mot de latin.
	
 * r-COREFERENCE-jmuzerelle_1292103277632: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292102827081']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers un métier manuel il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans des métiers manuels on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis tous ces métiers manuels qui sont des métiers rudes d' accord hein mais qui sont des métiers rémunérateurs croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment **[des petits métiers]** question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	 oui oui.
	 y a des heures y a des temps morts tout de même.
	 oui oui hum.
	 et qu' est -ce que vous pensez du latin à l' école ?.
	 ah ça je suis pas habileté à vous répondre euh d' après mes fils c' est valable parce que quand même c' est la c' est la la racine de notre langue quand même n' est -ce pas mais mes gosses en ont fait un peu moi eh bien évidemment je peux pas vous parler de ça puisque malheureusement je vous dis j' ai j' ai été qu' à l' école jusqu' à treize ans et j' ai jamais appris un mot de latin.
	
 * r-COREFERENCE-jmuzerelle_1294145466306: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1294145351820']
	et le le fait que l' orthographe soit mieux enseignée ça tient à quoi d' après vous ?.
	 parce que je crois que les études ont été plus poussées et puis qu' on aperçoit maintenant que les enfants ont une facilité beaucoup plus grande euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?.
	 bah c' est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un **[une autre matière]** deuxième matière aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de quelle circonstance est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	
 * r-COREFERENCE-jmuzerelle_1294145472668: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1294145404615']
	et le le fait que l' orthographe soit mieux enseignée ça tient à quoi d' après vous ?.
	 parce que je crois que les études ont été plus poussées et puis qu' on aperçoit maintenant que les enfants ont une facilité beaucoup plus grande euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?.
	 bah c' est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un une autre matière **[deuxième matière]** aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de quelle circonstance est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	
 * r-COREFERENCE-jmuzerelle_1294421660459: ['u-MENTION-jmuzerelle_1294348040361', 'u-MENTION-jmuzerelle_1294421256167']
	oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh quel instrument est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum **[quel type de papier]** utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et **[quel papier]** ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 instrument et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	
 * r-COREFERENCE-jmuzerelle_1294421660459: ['u-MENTION-jmuzerelle_1294348040361', 'u-MENTION-jmuzerelle_1294421256167']
	oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh quel instrument est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum **[quel type de papier]** utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et **[quel papier]** ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 instrument et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	
 * r-COREFERENCE-jmuzerelle_1294594615807: ['u-MENTION-jmuzerelle_1294590046254', 'u-MENTION-jmuzerelle_1294594263244']
	telle ou telle chose ?.
	 non non.
	 bon.
	 est -ce que vos vos parents faisaient attention à la façon dont vous parliez ?.
	 ah non non.
	 non et hum il est -ce qu' ils prenaient **[des sanctions]** si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour quel genre de choses surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles **[quelles sanctions]**.
	 les lignes les lignes les lignes.
	 oui.
	 et pour quel genre de choses ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * r-COREFERENCE-jmuzerelle_1294595724663: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294594682192']
	ah non non.
	 non et hum il est -ce qu' ils prenaient des sanctions si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles quelles sanctions.
	 les lignes les lignes les lignes.
	 oui.
	 et pour **[quel genre de choses]** ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * r-COREFERENCE-jmuzerelle_1294595724663: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294594682192']
	ah non non.
	 non et hum il est -ce qu' ils prenaient des sanctions si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles quelles sanctions.
	 les lignes les lignes les lignes.
	 oui.
	 et pour **[quel genre de choses]** ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * r-COREFERENCE-jmuzerelle_1357320739406: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1357320621452']
	et le le fait que l' orthographe soit mieux enseignée ça tient à quoi d' après vous ?.
	 parce que je crois que les études ont été plus poussées et puis qu' on aperçoit maintenant que les enfants ont une facilité beaucoup plus grande euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?.
	 bah **[c']** est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un une autre matière deuxième matière aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	
 * r-COREFERENCE-jmuzerelle_1358098362572: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294420807395']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh **[quel euh instrument]** ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et quel papier ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	
 * r-COREFERENCE-jmuzerelle_1358098362572: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294420807395']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh **[quel euh instrument]** ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et quel papier ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	
 * r-COREFERENCE-jmuzerelle_1358098936668: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294422956773']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 [...] ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 **[instrument]** et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	 vous avez.
	 dommage.
	 ça vienne à.
	 finir que je serais obligé de retourner mais enfin c' est c' est pas de toute façon comme c' est un questionnaire un peu fermé on pourra revenir dessus.
	 oui.
	 euh oui oui justement je vous disais est -ce qu' il y aurait des choses dans la façon de parler de votre femme qui vous agaceraient ?.
	 non.
	
 * r-ASSOCIATIVE-jmuzerelle_1293386353215: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385700098']
	oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à quel euh sujet ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 c' était Jacques.
	 la denture et la dentition.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre **[orthographe]** euh le sens des mots l' histoire ou la géographie ?.
	 l' orthographe.
	 l' orthographe oui.
	 le sens des mots aussi.
	 le sens des mots aussi oui.
	 oui et est -ce que vous avez aussi euh une ou des encyclopédies ?.
	 non.
	 non.
	 est -ce que vous possédez d' autres dictionnaires euh du genre euh par exemple Larousse ménager Larousse médical Larousse gastronomique ?.
	 euh ma femme a un Larousse ménager oui.
	 oui.
	 est -ce que vous possédez un livre euh sur euh l' art de parler ou la sur la prononciation ?.
	 non.
	 sur l' art d' écrire l' art d' écrire des lettres ? le Bon Usage ?.
	 non.
	 les difficultés de la langue française en orthographe ? ah oui oui.
	 ça je vous dis je me fie au au Littré quand euh je bute sur un mot.
	 un guide de politesse de savoir faire et caetera ? non et pourquoi est -ce que vous n' avez aucun de ces livres -là est -ce que vous ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1293386359863: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385761743']
	oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à quel euh sujet ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 c' était Jacques.
	 la denture et la dentition.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh **[le sens des mots]** l' histoire ou la géographie ?.
	 l' orthographe.
	 l' orthographe oui.
	 le sens des mots aussi.
	 le sens des mots aussi oui.
	 oui et est -ce que vous avez aussi euh une ou des encyclopédies ?.
	 non.
	 non.
	 est -ce que vous possédez d' autres dictionnaires euh du genre euh par exemple Larousse ménager Larousse médical Larousse gastronomique ?.
	 euh ma femme a un Larousse ménager oui.
	 oui.
	 est -ce que vous possédez un livre euh sur euh l' art de parler ou la sur la prononciation ?.
	 non.
	 sur l' art d' écrire l' art d' écrire des lettres ? le Bon Usage ?.
	 non.
	 les difficultés de la langue française en orthographe ? ah oui oui.
	 ça je vous dis je me fie au au Littré quand euh je bute sur un mot.
	 un guide de politesse de savoir faire et caetera ? non et pourquoi est -ce que vous n' avez aucun de ces livres -là est -ce que vous ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1293386365755: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385911944']
	oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à quel euh sujet ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 c' était Jacques.
	 la denture et la dentition.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh le sens des mots l' **[histoire]** ou la géographie ?.
	 l' orthographe.
	 l' orthographe oui.
	 le sens des mots aussi.
	 le sens des mots aussi oui.
	 oui et est -ce que vous avez aussi euh une ou des encyclopédies ?.
	 non.
	 non.
	 est -ce que vous possédez d' autres dictionnaires euh du genre euh par exemple Larousse ménager Larousse médical Larousse gastronomique ?.
	 euh ma femme a un Larousse ménager oui.
	 oui.
	 est -ce que vous possédez un livre euh sur euh l' art de parler ou la sur la prononciation ?.
	 non.
	 sur l' art d' écrire l' art d' écrire des lettres ? le Bon Usage ?.
	 non.
	 les difficultés de la langue française en orthographe ? ah oui oui.
	 ça je vous dis je me fie au au Littré quand euh je bute sur un mot.
	 un guide de politesse de savoir faire et caetera ? non et pourquoi est -ce que vous n' avez aucun de ces livres -là est -ce que vous ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1293386370631: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385955738']
	oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à quel euh sujet ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 c' était Jacques.
	 la denture et la dentition.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh le sens des mots l' histoire ou **[la géographie]** ?.
	 l' orthographe.
	 l' orthographe oui.
	 le sens des mots aussi.
	 le sens des mots aussi oui.
	 oui et est -ce que vous avez aussi euh une ou des encyclopédies ?.
	 non.
	 non.
	 est -ce que vous possédez d' autres dictionnaires euh du genre euh par exemple Larousse ménager Larousse médical Larousse gastronomique ?.
	 euh ma femme a un Larousse ménager oui.
	 oui.
	 est -ce que vous possédez un livre euh sur euh l' art de parler ou la sur la prononciation ?.
	 non.
	 sur l' art d' écrire l' art d' écrire des lettres ? le Bon Usage ?.
	 non.
	 les difficultés de la langue française en orthographe ? ah oui oui.
	 ça je vous dis je me fie au au Littré quand euh je bute sur un mot.
	 un guide de politesse de savoir faire et caetera ? non et pourquoi est -ce que vous n' avez aucun de ces livres -là est -ce que vous ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1294595775708: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294595147201']
	ah non non.
	 non et hum il est -ce qu' ils prenaient des sanctions si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles quelles sanctions.
	 les lignes les lignes les lignes.
	 oui.
	 et pour quel genre de choses ?.
	 ah bah si on avait mal conjugué **[un verbe]** vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * r-ASSOCIATIVE-jmuzerelle_1353950551135: ['u-MENTION-jmuzerelle_1292186508608', 'u-MENTION-jmuzerelle_1292186586927']
	oui.
	 hein ?.
	 oui.
	 mais on on peut faire des bons manuels moi vous vous me direz que j' en reviens toujours à cette question mais enfin y a des bons métiers manuels et on euh un élément moyen peut faire un un bon manuel tout de même et il gagne sa vie.
	 oui oui.
	 alors d' après vous euh jusqu' à **[quel âge]** est -ce qu' il faut que les enfants euh fassent des études ?.
	 je suis d' accord pour aller jusqu' à **[seize ans]** quand même c' est un minimum de bagages qu' il faut parce que moi j' en souffre de ça.
	 oui.
	 comprenez- vous moi j' ai été à l' école jusqu' à mon Certificat d' Etudes j' avais douze ans et demi et ça j' en ai toujours souffert.
	 oui.
	 n' est -ce pas mais j' estime que c' est valable qu' un gosse aille à l' école jusqu' à treize ans.
	 oui.
	 comprenez- vous ? mais alors là quoi à ce moment -là quoi qu' on dise carrément bon ben ça suffit hein parce un élé- un gosse je pense qu' à seize ans il s' est révélé ou alors euh euh c' est pas la peine.
	 oui.
	 y en a qui se révèlent tard mais enfin quand même je trouve qu' à seize ans euh un gosse s' est révélé s' il est valable pour faire un intellectuel euh un cadre ou enfin même un un un comment dirais- je un responsable euh assez haut placé mais sinon à seize ans bah qu' est -ce que vous voulez à ce moment -là qu' il prenne un bon métier manuel euh j' en reviens toujours avec mes questions.
	
 * r-ASSOCIATIVE-jmuzerelle_1358094904408: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294347096244']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 **[un stylo]**.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 même chose stylo à encre.
	
 * s-CHAIN-76: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292100299062', 'u-MENTION-jmuzerelle_1292101269216', 'u-MENTION-jmuzerelle_1292102584083', 'u-MENTION-jmuzerelle_1348844990034', 'u-MENTION-jmuzerelle_1292102607143', 'u-MENTION-jmuzerelle_1292102964263', 'u-MENTION-jmuzerelle_1292102772196', 'u-MENTION-jmuzerelle_1292102827081']
	oui oui.
	 à mon avis moi j' ai mes gosses qui ont été à l' école jusqu' à seize ans jusqu' au brevet et alors à ce moment -là je suis allé voir le le directeur de du lycée en lui demandant ce que euh mon aîné ce qu' il pourrait faire il m' a dit écoutez c' est un élément c' est un bon élément c' est un élément moyen en tout mais valable parce que travailleur mais quand il aura son bac ça sera son bâton de maréchal.
	 oui hum.
	 alors à ce moment -là j' ai pas commis l' erreur de certains parents de dire bon bah tant pis on va continuer on verra bien.
	 oui oui.
	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir.
	 oui oui oui.
	 comprenez- vous ? je l' ai aiguillé vers **[un métier manuel]** il est coiffeur.
	 hum hum.
	 hein parce que il a ce sens artistique que je crois un peu posséder et alors là il fait un boum terrible dans son métier.
	 oui oui oui.
	 terrible à l' heure actuelle il vient de faire deux concours à Paris là un concours à et un à Rouen il est sorti premier des championnats.
	 oui.
	 voyez ce qui prouve que même même dans **[des métiers manuels]** on on peut faire sa place j' estime.
	 oui hum.
	 alors qu' à l' heure actuelle on commet l' erreur de pousser les gosses trop je reconnais que c' est valable de dire qu' un un qu' un fils d' ouvrier c' est pas faut pas me faire dire ce que je veux pas dire j' estime qu' un fils d' ouvrier qui a les capacités de le faire est aussi valable que le fils d' un gros industriel c' est pas ça que je veux dire mais je trouve qu' à l' heure actuelle euh si vous voulez dans la classe moyenne on commet trop l' erreur de vouloir pousser les gosses vers les études alors que ça va faire des fruits secs d' ici cinq six ans mais enfin moi je vois ça comme ça.
	 oui oui oui oui oui.
	 moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis **[tous ces métiers manuels]** **[qui]** sont **[des métiers rudes]** d' accord hein mais **[qui]** sont **[des métiers rémunérateurs]** croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment **[des petits métiers]** question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois.
	 oui oui.
	 c' est quand même pas mal pour un manuel j' estime.
	 oui oui oui.
	 comprenez- vous ? et puis quand même les heures sont régentées on arrive à faire cinquante-quatre heures c' est encore peut-être beaucoup mais enfin y a quand même aussi des heures des présences c' est pas des heures de chez Renault hein.
	 oui oui.
	 y a des heures y a des temps morts tout de même.
	 oui oui hum.
	 et qu' est -ce que vous pensez du latin à l' école ?.
	 ah ça je suis pas habileté à vous répondre euh d' après mes fils c' est valable parce que quand même c' est la c' est la la racine de notre langue quand même n' est -ce pas mais mes gosses en ont fait un peu moi eh bien évidemment je peux pas vous parler de ça puisque malheureusement je vous dis j' ai j' ai été qu' à l' école jusqu' à treize ans et j' ai jamais appris un mot de latin.
	
 * s-CHAIN-175: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1357320621452', 'u-MENTION-jmuzerelle_1294145351820', 'u-MENTION-jmuzerelle_1294145404615']
	et le le fait que l' orthographe soit mieux enseignée ça tient à quoi d' après vous ?.
	 parce que je crois que les études ont été plus poussées et puis qu' on aperçoit maintenant que les enfants ont une facilité beaucoup plus grande euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?.
	 bah **[c']** est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un **[une autre matière]** **[deuxième matière]** aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de quelle circonstance est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	
 * s-CHAIN-197: ['u-MENTION-jmuzerelle_1294348040361', 'u-MENTION-jmuzerelle_1294421256167']
	oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh quel instrument est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum **[quel type de papier]** utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et **[quel papier]** ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 instrument et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	
 * s-CHAIN-197: ['u-MENTION-jmuzerelle_1294348040361', 'u-MENTION-jmuzerelle_1294421256167']
	oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh quel instrument est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum **[quel type de papier]** utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh quel euh instrument ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et **[quel papier]** ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 instrument et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	
 * s-CHAIN-205: ['u-MENTION-jmuzerelle_1294590046254', 'u-MENTION-jmuzerelle_1294593648454', 'u-MENTION-jmuzerelle_1294593996831', 'u-MENTION-jmuzerelle_1294594263244']
	telle ou telle chose ?.
	 non non.
	 bon.
	 est -ce que vos vos parents faisaient attention à la façon dont vous parliez ?.
	 ah non non.
	 non et hum il est -ce qu' ils prenaient **[des sanctions]** si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour quel genre de choses surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait **[des sanctions]** quelquefois ?.
	 oh oui assez **[ça]**.
	 oui pour.
	 il était assez sévère.
	 quelles **[quelles sanctions]**.
	 les lignes les lignes les lignes.
	 oui.
	 et pour quel genre de choses ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * s-CHAIN-207: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294594682192']
	ah non non.
	 non et hum il est -ce qu' ils prenaient des sanctions si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles quelles sanctions.
	 les lignes les lignes les lignes.
	 oui.
	 et pour **[quel genre de choses]** ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * s-CHAIN-207: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294594682192']
	ah non non.
	 non et hum il est -ce qu' ils prenaient des sanctions si vous disiez des choses euh ?.
	 bah non parce que malheureusement vous savez euh c- c' était tout à fait des ma mère.
	 votre mère oui.
	 oui.
	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.
	 pour l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 quelles quelles sanctions.
	 les lignes les lignes les lignes.
	 oui.
	 et pour **[quel genre de choses]** ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
 * s-CHAIN-262: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294420807395', 'u-MENTION-jmuzerelle_1294422956773']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh **[quel euh instrument]** ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et quel papier ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 **[instrument]** et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	 vous avez.
	 dommage.
	 ça vienne à.
	 finir que je serais obligé de retourner mais enfin c' est c' est pas de toute façon comme c' est un questionnaire un peu fermé on pourra revenir dessus.
	 oui.
	 euh oui oui justement je vous disais est -ce qu' il y aurait des choses dans la façon de parler de votre femme qui vous agaceraient ?.
	 non.
	
 * s-CHAIN-262: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294420807395', 'u-MENTION-jmuzerelle_1294422956773']
	non.
	 non est -ce que vous faites attention aux fautes d' orthographe ?.
	 oui.
	 oui est -ce que vous relisez ?.
	 oui.
	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez quel euh **[quel euh instrument]** ?.
	 même chose stylo à encre.
	 ah oui.
	 oui.
	 d' accord et quel papier ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 **[instrument]** et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	 vous avez.
	 dommage.
	 ça vienne à.
	 finir que je serais obligé de retourner mais enfin c' est c' est pas de toute façon comme c' est un questionnaire un peu fermé on pourra revenir dessus.
	 oui.
	 euh oui oui justement je vous disais est -ce qu' il y aurait des choses dans la façon de parler de votre femme qui vous agaceraient ?.
	 non.
	
