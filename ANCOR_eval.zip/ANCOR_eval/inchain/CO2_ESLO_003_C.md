 * r-COREFERENCE-aboyer_1301679309835: ['u-MENTION-jmuzerelle_1295977768588', 'u-MENTION-jmuzerelle_1295977572194']
	euh aller consulter un de mes confrères et vice et versa s' ils ne sont pas contents du service d' un de mes confrères ils peuvent venir me consulter dans les huit jours ou même le lendemain de cette première consultation euh su- sur le plan sur le plan des des honoraires voyez- vous bon ben les médec- les malades me payent leur consultation et ils en sont remboursés à soixante-quinze pour cent et ces honoraires sont des honoraires qui sont des honoraires fixés par décret et que je n' ai pas le droit de de dépasser sauf euh lorsque le malade pose des exigences qui ne sont pas les exigences habituelles si vous voulez.
	 hm hm.
	 ou s' il s' agit d' une urgence.
	 ah oui.
	 euh on peut également euh si on le veut mais enfin ceci ne peut pas se pratiquer euh demander des honoraires supérieurs lorsque la situation de fortune du malade est est une situation aisée mais ceci me paraît extrêmement difficile à appliquer enfin quant à moi je ne le pratique pas.
	 ah bon ? enfin pour un cas extrême par exemple du moment que Onassis viendrait amarrer dans la Loire ?.
	 oui mais enfin je pense qu' Onassis ne doit pas avoir la sécurité sociale et puis la Loire n' est pas navigable.
	 c' était le genre d' éventualité auquel je pensais.
	 oui.
	 est -ce que vous avez toujours eu l' intention de de devenir médecin ?.
	 non non je c' est peut-être une histoire un peu curieuse je pense que le des rai- les raisons profondes que je n- j' ai débrouillées au bout de d' assez longues années finalement je voulais être officier de marine et comme je suis myope je suis pas horriblement myope mais enfin je suis myope suffisamment pour que on m' ait refusé au concours de l' Ecole Navale que je n' ai pas présenté parce que je savais que j' étais myope et j' ai fait ma médecine parce que mon grand-père maternel était médecin que il y a pas mal de médecins dans ma famille qu' **[un de mes cousins]** **[que]** j' aimais beaucoup m' a traîné dans sa vieille Rosengart sur les les chemins euh euh de pavés du département du Nord voir un malade voir l' autre et que finalement ça m' a paru être un un métier qui comportait euh des contacts humains enrichissants et ça m' a tenté et puis alors ma spécialisation d' ophtalmologie je vous dis que c' était peut-être une revanche contre l' impossibilité de faire la Marine c' est possible et puis en fait c' est une euh c' est une spécialité qui est assez équilibrée parce que elle permet de de connaître pas mal de choses qui touchent à la médecine générale euh elle permet des satisfactions opératoires qui sont qui ne sont pas désagréables et euh un domaine propre qui est précis euh qui est euh euh vraiment très objectif où on peut examiner le malade euh d' une façon rigoureuse voyez- vous c' est en ça que je j' aime mon métier.
	 est -ce que dans votre profession il y a beaucoup de femmes qui exercent ?.
	 actuellement énormément actuellement énormément enfin si vous voulez la nouvelle génération des ophtalmologistes euh est j' ai l' impression a largement plus de cinquante pour cent féminine.
	 ah bon ?.
	 c' est environ soixante pour cent féminine dans parmi les étudiants actuels parmi les étudiants actuels c' est très très important euh ça a toujours été la si vous voulez la fraction féminine des ophtalmologistes depuis quelques années est importante mais j' ai l' impression qu' elle tend à le devenir de plus en plus et pour vous citer un exemple euh je suis attaché dans le service de d' ophtalmologie des enfants malades où je vais deux matinées par semaine eh bien parmi les externes que nous avons il y a euh deux garçons pour sept filles actuellement vous me direz que c' est un cas particulier de duque l on ne peut pas inférer une loi générale mais enfin euh c' est quand même sensible.
	 quand même un indice.
	 oui oui.
	 est -ce que vous voyez une explication à cela ?.
	 oui bien sûr y a une explication qui est très simple c' est que c' est un métier qui comporte fort peu d' urgences.
	 ah bon ?.
	 c' est un métier où pratiquement toute l' activité se fait facilement sur rendez-vous c' est un métier qui ne comporte pas de visites moi je fais en une visite en ville ou en campagne tous les quinze jours peut-être toutes les trois semaines ça ne dépasse pas ça voyez- vous donc euh une femme qui est mariée qui a qui a des enfants peut parfaitement euh travailler euh euh trois quatre cinq demi-journées par semaine comme elle l' entend et se réserver facilement euh le reste de son temps pour s' occuper de sa maison et de ses enfants et de son mari euh ce qui me semble difficile dans beaucoup d' autres euh spécialités il est évident que par exemple euh euh des professions comme la pédiatrie la gynéco-obstétrique pourraient être euh euh des spécialités féminines voyez -vous mais elles comportent beaucoup d' urgences qui sont euh peu compatibles avec une vie équilibrée de femme mariée.
	 hm oui c' est d' ailleurs une chose frappante pour un Anglais qui vient en France la proportion des femmes mariées qui travaillent.
	 et vous trouvez qu' elle est beaucoup plus importante en France qu' en Angleterre ?.
	 d' après la statistique.
	 oh je sais pas moi oui oui oui.
	 euh est -ce que d' une façon générale vous êtes pour ou contre ou.
	 le le travail des des femmes mariées ? à partir du moment je crois que à partir du moment où on peut trouver un un système où ce travail n' est pas un travail exclusif hein est un travail qui est aménagé pour la femme je crois que c' est sûrement très très intéressant et très équilibrant pour elle.
	 oui.
	 mais que euh le le travail de de huit heures par jour pour une femme mariée ayant des enfants pose d' énormes questions on en a parlé j' ai lu une série d' articles euh je ne sais plus dans quel journal il y a il y a un an où y avait -il eu ce projet de euh d' une loi sociale sur des de le travail à mi-temps des femmes je crois que ça ce serait une euh une chose qui serait sûrement très intéressante et très payante pour le pour les pour les femmes parce que ça les ça les sort de leur euh de leur vie de la maison qui n' est sûrement pas très euh très payant pour euh pour l' esprit enfin euh qui ne leur donne que peu d' aspirations intellectuelles si vous voulez et je je crois que ce serait très positif ça sûrement très positif maintenant ça se heurte euh aux entreprises et il est facile de concevoir que qu' un patron euh apprécie sûrement peu de ne pas avoir la même secrétaire le matin et l' après-midi parce qu' elles sont euh l' une et l' autre ça met deux fois plus de temps à former et je me rends fort bien compte que j' ai une secrétaire dont je suis parfaitement satisfait et s' il fallait que ce soit une différente que j' aie l' après-midi ça ne me plairait pas ou moins du moins.
	
 * r-COREFERENCE-aboyer_1302089860729: ['u-MENTION-jmuzerelle_1296479882592', 'u-MENTION-jmuzerelle_1296479995430']
	par exemple euh est -ce que chez vous vous possédez des dictionnaires ?.
	 nous sommes en train d' acheter un dictionnaire et c' est ma mère qui me l' offre elle m' a offert le premier tome d' une dictionnaire en trois volumes voyez- vous j' ai un tiers de dictionnaire valable mais j' ai des petits dictionnaires de poche.
	 oui euh le dictionnaire en trois volumes c' est lequel ?.
	 c' est le Larousse.
	 ah bon ? et du côté encyclopédie ?.
	 non enfin si ce n' est des encyclopédies professionnelles mais enfin ça c' est autre chose.
	 et en général dans **[votre famille]** **[qui]** est -ce qui se sert le plus souvent du dictionnaire ou des dictionnaires ?.
	 bon serait pas euh oui enfin euh je crois c' est à parité voyez- vous enfin et en général d' ailleurs c' est sur une euh euh c' est lors d' une discussion c' était un élément de référence donc c' est le plus souvent lors d' une discussion entre ma femme et moi par exemple ou s' il y a des amis que on se porte vers ce dictionnaire.
	 point d' interrogation.
	 est -ce que vous avez tendance à chercher un genre euh de renseignements plutôt qu' un autre ?.
	 est -ce qu' il s' agit ?.
	 c' est plus souvent c' est le plus souvent des des renseignements d' ordre historique.
	 oui et évidemment vous possédez vous devez posséder toute une collection d' ouvrages médicaux.
	 oui.
	 de référence et autres.
	 oui.
	 et pour le reste est -ce que vous avez des ouvrages de référence je ne sais pas du genre euh par exemple du genre le Larousse gastronomique ou ?.
	 non.
	 bon.
	 non quelques livres euh quelques livres de décoration.
	 oui.
	 et du côté du français est -ce que vous avez des ouvrages sur le français par exemple Grevisse Le Bon Usage ou des ?.
	 non mais je regrette de ne pas en avoir et j' ai souvent pensé à en acheter mais je ne l' ai pas fait je voulais en particulier acheter une grammaire mais je ne l' ai pas achetée c' est en projet d' acheter la grammaire de le Bidois tiens faut que je le note.
	 le Bidois oui.
	
 * r-COREFERENCE-aboyer_1302292409077: ['u-MENTION-jmuzerelle_1297096353345', 'u-MENTION-jmuzerelle_1297096208310']
	oui oui comme.
	 oui oui.
	 est -ce que ça peut se résumer en deux trois mots ou en ?.
	 oh ben euh j' aime tous les musiciens je crois sauf Massenet.
	 enfin avec le chant.
	 oui.
	 et le théâtre ?.
	 oui enfin ça fait fait bien bien longtemps que j' ai pas été au théâtre mais enfin j' aime bien le théâtre.
	 du côté classique du côté moderne expérimental ?.
	 bah euh le théâtre expérimental euh oui si il y a des bonnes choses il y a des bonnes choses qu' est -ce que j' ai **[quelle]** était **[cette pièce]** que j' ai vu ? cette pièce euh oui et euh au T N P là sur les euh c' est deux gars qui étaient exécutés là je me souv- je me souviens plus du titre de la pièce parce que j' ai une mémoire assez défaillante de temps en temps enfin c' est pas la peine je me souviens plus.
	 euh qu' on a fait.
	 si c' est ça c' est ça.
	 je vais trouver le titre.
	 et alors les périodiques le périodique médical.
	 hm hm.
	 le Monde vous m' avez dit.
	 oui République du Centre oui.
	 d' autres euh d' autres journaux.
	 que je reçois ?.
	 oui.
	 toute la pêche voyez- vous ah que je reçois.
	 oui oui.
	 ah qu- auquel je suis abonné ou que j' achète ? le Nouvel Observateur et le Canard Enchaîné.
	 et vous lisez vous lisez surtout l' histoire ?.
	 oui.
	 et de pendant ?.
	 oui oui mais pas tellement ça dépend c' est parfois vieux.
	 une dernière question c' est vraiment la dernière.
	 oui oui.
	 ne répondez pas si vous ne voulez pas enfin d' abord ce serait une réponse oui ou non est -ce qu' il y a un parti politique qui corresponde à vos opinions ?.
	
 * r-ASSOCIATIVE-aboyer_1301748853897: ['u-MENTION-jmuzerelle_1295981057115', 'u-MENTION-jmuzerelle_1295981148578']
	c' est un métier où pratiquement toute l' activité se fait facilement sur rendez-vous c' est un métier qui ne comporte pas de visites moi je fais en une visite en ville ou en campagne tous les quinze jours peut-être toutes les trois semaines ça ne dépasse pas ça voyez- vous donc euh une femme qui est mariée qui a qui a des enfants peut parfaitement euh travailler euh euh trois quatre cinq demi-journées par semaine comme elle l' entend et se réserver facilement euh le reste de son temps pour s' occuper de sa maison et de ses enfants et de son mari euh ce qui me semble difficile dans beaucoup d' autres euh spécialités il est évident que par exemple euh euh des professions comme la pédiatrie la gynéco-obstétrique pourraient être euh euh des spécialités féminines voyez -vous mais elles comportent beaucoup d' urgences qui sont euh peu compatibles avec une vie équilibrée de femme mariée.
	 hm oui c' est d' ailleurs une chose frappante pour un Anglais qui vient en France la proportion des femmes mariées qui travaillent.
	 et vous trouvez qu' elle est beaucoup plus importante en France qu' en Angleterre ?.
	 d' après la statistique.
	 oh je sais pas moi oui oui oui.
	 euh est -ce que d' une façon générale vous êtes pour ou contre ou.
	 le le travail des des femmes mariées ? à partir du moment je crois que à partir du moment où on peut trouver un un système où ce travail n' est pas un travail exclusif hein est un travail qui est aménagé pour la femme je crois que c' est sûrement très très intéressant et très équilibrant pour elle.
	 oui.
	 mais que euh le le travail de de huit heures par jour pour une femme mariée ayant des enfants pose d' énormes questions on en a parlé j' ai lu **[une série d' articles]** euh je ne sais plus dans **[quel journal]** il y a il y a un an où y avait -il eu ce projet de euh d' une loi sociale sur des de le travail à mi-temps des femmes je crois que ça ce serait une euh une chose qui serait sûrement très intéressante et très payante pour le pour les pour les femmes parce que ça les ça les sort de leur euh de leur vie de la maison qui n' est sûrement pas très euh très payant pour euh pour l' esprit enfin euh qui ne leur donne que peu d' aspirations intellectuelles si vous voulez et je je crois que ce serait très positif ça sûrement très positif maintenant ça se heurte euh aux entreprises et il est facile de concevoir que qu' un patron euh apprécie sûrement peu de ne pas avoir la même secrétaire le matin et l' après-midi parce qu' elles sont euh l' une et l' autre ça met deux fois plus de temps à former et je me rends fort bien compte que j' ai une secrétaire dont je suis parfaitement satisfait et s' il fallait que ce soit une différente que j' aie l' après-midi ça ne me plairait pas ou moins du moins.
	 oui.
	 oui.
	 euh.
	 sur le plan personnel euh est -ce que vous êtes marié ?.
	 oui je suis marié.
	 et est -ce que votre femme ?.
	 ma femme travaille.
	 ah bon ?.
	 ma femme travaille ma femme est psychologue.
	 oui.
	 et elle travaille euh dans des instituts d' enfants euh plus ou moins adaptés enfin plutôt inadaptés disons et en plus de ça elle a une clientèle personnelle ici euh dont elle met ses rendez -vous quand elle veut et alors elle est psychologue elle s' occupe surtout d' enfants mais voyez- vous par exemple elle a fait un choix qui fait protester un certain nombre de ses consultants elle ne travaille pas le jeudi alors que le jeudi c' est le jour où évidemment normalement elle devrait recevoir le maximum d' enfants où c' est le plus pratique pour les les parents et pour les enfants eh bien elle refuse de les recevoir le le jeudi disons que si une consultation de psychologie euh peut très facilement faire sauter une demi-journée de travail scolaire à partir du moment où c' est vraiment quelque chose d' important pour laquelle on vient la consulter et que ma foi le jeudi il faut qu' elle s' occupe de ses enfants à elle et que c' est une chose euh essentielle alors ça marche comme ça et voyez- vous je crois que euh bah le travail féminin devrait être compris un petit peu comme cela seulement ça se heurte évidemment au au dynamisme et à euh à la question de rentabilité des des sociétés industrielles ou commerciales.
	 effectivement.
	 bien encore une chose euh au sujet de laquelle il est très intéressant de faire la comparaison c' est le rôle des associations professionnelles surtout euh sur le dans les professions libérales comme la médecine est -ce que vous-même vous appartenez à une association.
	 non.
	 professionnelle ?.
	 euh association professionnelle c'est-à-dire travailler en euh être associé avec quelqu'un ?.
	 ou plutôt non non une association qui euh qui englobe euh tous les membres de votre profession.
	 ah oui vous parlez vous voulez parler sur le plan syndical ?.
	 si le terme s' applique oui.
	 oui bé ici il y a un il y a un syndicat il y a une syndicat euh département des des médecins du Loiret si vous voulez qui qui défend les les intérêts des des médecins euh sur le plan euh départemental euh euh vis-à-vis par exemple des des contributions directes euh et sur le plan national sur euh pour euh revendiquer sur le le statut que nous pouvons avoir vis-à-vis de la Sécurité Sociale sur le plan de nos honoraires et cetera.
	
 * r-ASSOCIATIVE-aboyer_1301941732741: ['u-MENTION-jmuzerelle_1296133993397', 'u-MENTION-jmuzerelle_1296134030610']
	si vous voulez oui.
	 euhm.
	 vous vous allez pas être publiés cette histoire non ?.
	 enfin ça dépend euh.
	 vous avez **[une voiture]** évidemment ?.
	 oui.
	 euh.
	 **[quel modèle]** qu' est -ce que vous avez comme voiture ?.
	 j' ai une Peugeot quatre cent quatre à injection.
	 euh.
	 et une autre deux-chevaux que j' ai depuis trois jours.
	 ah bon ?.
	 oui.
	 pourquoi est -ce que vous avez choisi ces modèles ?.
	 pourquoi j' ai acheté une quatre cent quatre à injection ?.
	 par exemple oui.
	 parce que c' est une voiture qui est très rapide.
	 oui.
	
 * r-ASSOCIATIVE-aboyer_1302206176414: ['u-MENTION-jmuzerelle_1296827485294', 'u-MENTION-jmuzerelle_1296827589883']
	je crois qu' il est pas po- il est i- il n' est il n' est pas possible il est inopérant.
	 mais par exemple dans des cas précis par exemple euh le français employé par les speakers de la télévision ?.
	 alors ça je crois que c' est important.
	 hm hm.
	 ça je crois que c' est important je crois que euh l- dans les moyens d' information nationalisés il y a indiscutablement une euh une responsabilité des des pouvoirs publics euh de de réprimander de réprimander les les speakers de la télévision euh qui qui parlent un français incorrect.
	 et vous-même quand vous étiez à l' école euh dans **[quelle matière]** étiez- vous le plus fort ?.
	 **[en physique]**.
	 ah oui ? ça change le nombre de témoins qui dit automatiquement le français.
	 est -ce que d' habitude vous avez quelque chose pour écrire sur vous ?.
	 toujours.
	 toujours euh quoi ?.
	 vous mettez une note ? un stylo à bille.
	 stylo bille oui.
	 stylo à bille.
	 vous possédez un stylo à encre euh ?.
	 oui je ne rédige jamais une ordonnance au stylo à bille je trouve que c' est incorrect et je n' écris jamais une lettre au stylo à bille parce que je trouve que c' est incorrect.
	 hm hm.
	
 * r-ASSOCIATIVE-aboyer_1302206219953: ['u-MENTION-jmuzerelle_1296827485294', 'u-MENTION-jmuzerelle_1296827696205']
	je crois qu' il est pas po- il est i- il n' est il n' est pas possible il est inopérant.
	 mais par exemple dans des cas précis par exemple euh le français employé par les speakers de la télévision ?.
	 alors ça je crois que c' est important.
	 hm hm.
	 ça je crois que c' est important je crois que euh l- dans les moyens d' information nationalisés il y a indiscutablement une euh une responsabilité des des pouvoirs publics euh de de réprimander de réprimander les les speakers de la télévision euh qui qui parlent un français incorrect.
	 et vous-même quand vous étiez à l' école euh dans **[quelle matière]** étiez- vous le plus fort ?.
	 en physique.
	 ah oui ? ça change le nombre de témoins qui dit automatiquement **[le français]**.
	 est -ce que d' habitude vous avez quelque chose pour écrire sur vous ?.
	 toujours.
	 toujours euh quoi ?.
	 vous mettez une note ? un stylo à bille.
	 stylo bille oui.
	 stylo à bille.
	 vous possédez un stylo à encre euh ?.
	 oui je ne rédige jamais une ordonnance au stylo à bille je trouve que c' est incorrect et je n' écris jamais une lettre au stylo à bille parce que je trouve que c' est incorrect.
	 hm hm.
	 et oui justement au sujet de la correspondance euh est -ce que vous devez écrire beaucoup pour votre profession ?.
	
 * r-ASSOCIATIVE-aboyer_1302250339864: ['u-MENTION-jmuzerelle_1297089349260', 'u-MENTION-jmuzerelle_1297089629832']
	ah et euh l' enseignement supérieur ? c' était.
	 à la Fac de Médecine de Paris.
	 oui quelques questions et puis on sera fini je vous le promets sur euh les poursuites culturelles ça j' y tiens parce que je crois que vous en avez qui sont très développées.
	 euh est -ce que vous écoutez la radio ?.
	 oui.
	 euhm **[quel genre d' émissions]** surtout ?.
	 bah j' écoute **[les informations sur Europe numéro Un]**.
	 hm.
	 et à par ça j' écoute France Musique.
	 oui.
	 pour écouter de la musique.
	 oui.
	 la télévision ?.
	 oui peu.
	 euh encore une fois des des émissions préférées ? quel genre euh d' émissions ?.
	 j' aime beaucoup j' aime beaucoup les émissions sportives.
	 oui.
	
 * r-ASSOCIATIVE-aboyer_1302250962976: ['u-MENTION-jmuzerelle_1297090400918', 'u-MENTION-jmuzerelle_1297090571644']
	oui.
	 beaucoup les émissions sportives à la télévision et puis bah ma foi euh les films.
	 oui.
	 pièces de théâtre il y a quelquefois des choses remarquables à la télévision en pièces de théâtre.
	 oui.
	 et **[le cinéma]** vous avez dit que vous y allez.
	 oui pas très souvent pas très souvent.
	 encore une fois la même question euh les préférences ?.
	 dans quel euh sens ?.
	 de préférence **[quel genre de film]** ?.
	 ou est -ce que vous avez des goûts variés.
	 bah j' aime euh j' aime bien les disons les euh le ciné- le cinéma actuel euh le cinéma euh euh un petit symbolique euh qui a été euh enfin euh qui a commencé en Italie enfin qui a fait un petit peu en France euh j' aime beaucoup ce cinéma moderne.
	 à votre avis est -ce que ces ces médias la radio le cinéma la télévision peuvent être des du comment dirais- je ? des instruments de culture ?.
	 oh sûrement oui.
	 est -ce que vous vous faites de la photo ?.
	 oui.
	
 * s-CHAIN-30: ['u-MENTION-jmuzerelle_1295977768588', 'u-MENTION-jmuzerelle_1295977572194']
	euh aller consulter un de mes confrères et vice et versa s' ils ne sont pas contents du service d' un de mes confrères ils peuvent venir me consulter dans les huit jours ou même le lendemain de cette première consultation euh su- sur le plan sur le plan des des honoraires voyez- vous bon ben les médec- les malades me payent leur consultation et ils en sont remboursés à soixante-quinze pour cent et ces honoraires sont des honoraires qui sont des honoraires fixés par décret et que je n' ai pas le droit de de dépasser sauf euh lorsque le malade pose des exigences qui ne sont pas les exigences habituelles si vous voulez.
	 hm hm.
	 ou s' il s' agit d' une urgence.
	 ah oui.
	 euh on peut également euh si on le veut mais enfin ceci ne peut pas se pratiquer euh demander des honoraires supérieurs lorsque la situation de fortune du malade est est une situation aisée mais ceci me paraît extrêmement difficile à appliquer enfin quant à moi je ne le pratique pas.
	 ah bon ? enfin pour un cas extrême par exemple du moment que Onassis viendrait amarrer dans la Loire ?.
	 oui mais enfin je pense qu' Onassis ne doit pas avoir la sécurité sociale et puis la Loire n' est pas navigable.
	 c' était le genre d' éventualité auquel je pensais.
	 oui.
	 est -ce que vous avez toujours eu l' intention de de devenir médecin ?.
	 non non je c' est peut-être une histoire un peu curieuse je pense que le des rai- les raisons profondes que je n- j' ai débrouillées au bout de d' assez longues années finalement je voulais être officier de marine et comme je suis myope je suis pas horriblement myope mais enfin je suis myope suffisamment pour que on m' ait refusé au concours de l' Ecole Navale que je n' ai pas présenté parce que je savais que j' étais myope et j' ai fait ma médecine parce que mon grand-père maternel était médecin que il y a pas mal de médecins dans ma famille qu' **[un de mes cousins]** **[que]** j' aimais beaucoup m' a traîné dans sa vieille Rosengart sur les les chemins euh euh de pavés du département du Nord voir un malade voir l' autre et que finalement ça m' a paru être un un métier qui comportait euh des contacts humains enrichissants et ça m' a tenté et puis alors ma spécialisation d' ophtalmologie je vous dis que c' était peut-être une revanche contre l' impossibilité de faire la Marine c' est possible et puis en fait c' est une euh c' est une spécialité qui est assez équilibrée parce que elle permet de de connaître pas mal de choses qui touchent à la médecine générale euh elle permet des satisfactions opératoires qui sont qui ne sont pas désagréables et euh un domaine propre qui est précis euh qui est euh euh vraiment très objectif où on peut examiner le malade euh d' une façon rigoureuse voyez- vous c' est en ça que je j' aime mon métier.
	 est -ce que dans votre profession il y a beaucoup de femmes qui exercent ?.
	 actuellement énormément actuellement énormément enfin si vous voulez la nouvelle génération des ophtalmologistes euh est j' ai l' impression a largement plus de cinquante pour cent féminine.
	 ah bon ?.
	 c' est environ soixante pour cent féminine dans parmi les étudiants actuels parmi les étudiants actuels c' est très très important euh ça a toujours été la si vous voulez la fraction féminine des ophtalmologistes depuis quelques années est importante mais j' ai l' impression qu' elle tend à le devenir de plus en plus et pour vous citer un exemple euh je suis attaché dans le service de d' ophtalmologie des enfants malades où je vais deux matinées par semaine eh bien parmi les externes que nous avons il y a euh deux garçons pour sept filles actuellement vous me direz que c' est un cas particulier de duque l on ne peut pas inférer une loi générale mais enfin euh c' est quand même sensible.
	 quand même un indice.
	 oui oui.
	 est -ce que vous voyez une explication à cela ?.
	 oui bien sûr y a une explication qui est très simple c' est que c' est un métier qui comporte fort peu d' urgences.
	 ah bon ?.
	 c' est un métier où pratiquement toute l' activité se fait facilement sur rendez-vous c' est un métier qui ne comporte pas de visites moi je fais en une visite en ville ou en campagne tous les quinze jours peut-être toutes les trois semaines ça ne dépasse pas ça voyez- vous donc euh une femme qui est mariée qui a qui a des enfants peut parfaitement euh travailler euh euh trois quatre cinq demi-journées par semaine comme elle l' entend et se réserver facilement euh le reste de son temps pour s' occuper de sa maison et de ses enfants et de son mari euh ce qui me semble difficile dans beaucoup d' autres euh spécialités il est évident que par exemple euh euh des professions comme la pédiatrie la gynéco-obstétrique pourraient être euh euh des spécialités féminines voyez -vous mais elles comportent beaucoup d' urgences qui sont euh peu compatibles avec une vie équilibrée de femme mariée.
	 hm oui c' est d' ailleurs une chose frappante pour un Anglais qui vient en France la proportion des femmes mariées qui travaillent.
	 et vous trouvez qu' elle est beaucoup plus importante en France qu' en Angleterre ?.
	 d' après la statistique.
	 oh je sais pas moi oui oui oui.
	 euh est -ce que d' une façon générale vous êtes pour ou contre ou.
	 le le travail des des femmes mariées ? à partir du moment je crois que à partir du moment où on peut trouver un un système où ce travail n' est pas un travail exclusif hein est un travail qui est aménagé pour la femme je crois que c' est sûrement très très intéressant et très équilibrant pour elle.
	 oui.
	 mais que euh le le travail de de huit heures par jour pour une femme mariée ayant des enfants pose d' énormes questions on en a parlé j' ai lu une série d' articles euh je ne sais plus dans quel journal il y a il y a un an où y avait -il eu ce projet de euh d' une loi sociale sur des de le travail à mi-temps des femmes je crois que ça ce serait une euh une chose qui serait sûrement très intéressante et très payante pour le pour les pour les femmes parce que ça les ça les sort de leur euh de leur vie de la maison qui n' est sûrement pas très euh très payant pour euh pour l' esprit enfin euh qui ne leur donne que peu d' aspirations intellectuelles si vous voulez et je je crois que ce serait très positif ça sûrement très positif maintenant ça se heurte euh aux entreprises et il est facile de concevoir que qu' un patron euh apprécie sûrement peu de ne pas avoir la même secrétaire le matin et l' après-midi parce qu' elles sont euh l' une et l' autre ça met deux fois plus de temps à former et je me rends fort bien compte que j' ai une secrétaire dont je suis parfaitement satisfait et s' il fallait que ce soit une différente que j' aie l' après-midi ça ne me plairait pas ou moins du moins.
	
 * s-CHAIN-156: ['u-MENTION-jmuzerelle_1296479882592', 'u-MENTION-jmuzerelle_1296479995430', 'u-MENTION-jmuzerelle_1296480005050']
	par exemple euh est -ce que chez vous vous possédez des dictionnaires ?.
	 nous sommes en train d' acheter un dictionnaire et c' est ma mère qui me l' offre elle m' a offert le premier tome d' une dictionnaire en trois volumes voyez- vous j' ai un tiers de dictionnaire valable mais j' ai des petits dictionnaires de poche.
	 oui euh le dictionnaire en trois volumes c' est lequel ?.
	 c' est le Larousse.
	 ah bon ? et du côté encyclopédie ?.
	 non enfin si ce n' est des encyclopédies professionnelles mais enfin ça c' est autre chose.
	 et en général dans **[votre famille]** **[qui]** est -ce **[qui]** se sert le plus souvent du dictionnaire ou des dictionnaires ?.
	 bon serait pas euh oui enfin euh je crois c' est à parité voyez- vous enfin et en général d' ailleurs c' est sur une euh euh c' est lors d' une discussion c' était un élément de référence donc c' est le plus souvent lors d' une discussion entre ma femme et moi par exemple ou s' il y a des amis que on se porte vers ce dictionnaire.
	 point d' interrogation.
	 est -ce que vous avez tendance à chercher un genre euh de renseignements plutôt qu' un autre ?.
	 est -ce qu' il s' agit ?.
	 c' est plus souvent c' est le plus souvent des des renseignements d' ordre historique.
	 oui et évidemment vous possédez vous devez posséder toute une collection d' ouvrages médicaux.
	 oui.
	 de référence et autres.
	 oui.
	 et pour le reste est -ce que vous avez des ouvrages de référence je ne sais pas du genre euh par exemple du genre le Larousse gastronomique ou ?.
	 non.
	 bon.
	 non quelques livres euh quelques livres de décoration.
	 oui.
	 et du côté du français est -ce que vous avez des ouvrages sur le français par exemple Grevisse Le Bon Usage ou des ?.
	 non mais je regrette de ne pas en avoir et j' ai souvent pensé à en acheter mais je ne l' ai pas fait je voulais en particulier acheter une grammaire mais je ne l' ai pas achetée c' est en projet d' acheter la grammaire de le Bidois tiens faut que je le note.
	 le Bidois oui.
	
 * s-CHAIN-243: ['u-MENTION-jmuzerelle_1297096353345', 'u-MENTION-jmuzerelle_1297096208310', 'u-MENTION-jmuzerelle_1297096392350', 'u-MENTION-jmuzerelle_1297096246893', 'u-MENTION-jmuzerelle_1297096741966']
	oui oui comme.
	 oui oui.
	 est -ce que ça peut se résumer en deux trois mots ou en ?.
	 oh ben euh j' aime tous les musiciens je crois sauf Massenet.
	 enfin avec le chant.
	 oui.
	 et le théâtre ?.
	 oui enfin ça fait fait bien bien longtemps que j' ai pas été au théâtre mais enfin j' aime bien le théâtre.
	 du côté classique du côté moderne expérimental ?.
	 bah euh le théâtre expérimental euh oui si il y a des bonnes choses il y a des bonnes choses qu' est -ce que j' ai **[quelle]** était **[cette pièce]** **[que]** j' ai vu ? **[cette pièce]** euh oui et euh au T N P là sur les euh c' est deux gars qui étaient exécutés là je me souv- je me souviens plus du titre de **[la pièce]** parce que j' ai une mémoire assez défaillante de temps en temps enfin c' est pas la peine je me souviens plus.
	 euh qu' on a fait.
	 si c' est ça c' est ça.
	 je vais trouver le titre.
	 et alors les périodiques le périodique médical.
	 hm hm.
	 le Monde vous m' avez dit.
	 oui République du Centre oui.
	 d' autres euh d' autres journaux.
	 que je reçois ?.
	 oui.
	 toute la pêche voyez- vous ah que je reçois.
	 oui oui.
	 ah qu- auquel je suis abonné ou que j' achète ? le Nouvel Observateur et le Canard Enchaîné.
	 et vous lisez vous lisez surtout l' histoire ?.
	 oui.
	 et de pendant ?.
	 oui oui mais pas tellement ça dépend c' est parfois vieux.
	 une dernière question c' est vraiment la dernière.
	 oui oui.
	 ne répondez pas si vous ne voulez pas enfin d' abord ce serait une réponse oui ou non est -ce qu' il y a un parti politique qui corresponde à vos opinions ?.
	
