 * r-COREFERENCE-jmuzerelle_1301944647797: ['u-MENTION-aboyer_1297616156013', 'u-MENTION-jmuzerelle_1301343967051']
	Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui les pièces horribles les pièces noires euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous **[une pièce horrible]** ?.
	 oh **[où]** y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir quelque chose de valable bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	 ah bon alors le le cimetière de voitures ce serait peut-être pas.
	 voilà.
	 le spectacle à regarder bon vous savez à peu près combien de fois dans l' année ? ou est -ce que c' est comme pour le cinéma ?.
	 oui c' est un peu ça oui comme le cinéma oui.
	 oui.
	 et du côté de la presse est -ce que vous prenez habituellement un journal ?.
	
 * r-COREFERENCE-jmuzerelle_1301944860138: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616662623']
	ah bon et est -ce que vous allez au concert ?.
	 non.
	 au théâtre ?.
	 oui.
	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?.
	 Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui les pièces horribles les pièces noires euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous une pièce horrible ?.
	 oh où y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir **[quelque chose de valable]** bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	 ah bon alors le le cimetière de voitures ce serait peut-être pas.
	 voilà.
	 le spectacle à regarder bon vous savez à peu près combien de fois dans l' année ? ou est -ce que c' est comme pour le cinéma ?.
	 oui c' est un peu ça oui comme le cinéma oui.
	 oui.
	 et du côté de la presse est -ce que vous prenez habituellement un journal ?.
	 oui je prends le journal local.
	 c' est lequel ?.
	 La République du Centre.
	
 * r-COREFERENCE-jmuzerelle_1304018318398: ['u-MENTION-aboyer_1300122506270', 'u-MENTION-aboyer_1299066255179']
	y a des choses euh il y a des choses pas mal mais il y en a d' autres.
	 enfin d' un côté Beauchamps de l' autre côté le campus parce que je crois qu' il faudra séparer.
	 euh vous savez je connais pas on on circule pas tellement facilement là-dedans puis ça fait ça fait bien six mois que j' y suis pas allé hein ?.
	 faudrait y aller moi aussi ça fait six mois que je suis pas allé y a des changements.
	 il faut que j' y retourne.
	 oui certainement.
	 très importants enfin du côté côté cité pas tellement c' est la même chose mais.
	 je crois que je crois que ça ne peut être que bénéfique pour un pour la ville.
	 hm.
	 aussi bien au point de vue euh comment dirais- je ? moi logement pur euh ambiance de vie et puis même au point de vue artistique ça ça habituera les gens à voir autre chose que des petites maisons comme dans **[ces rues -là]** **[où]**.
	 oui.
	 ça va créer une autre un autre état d' esprit je pense.
	 hm.
	 je pense si on arrive pas trop à le à le rendre uniforme et et impersonnel comme beaucoup de villes mais enfin.
	 j' ai également vu la Maison de Culture enfin la maison provisoire.
	 oui.
	 est -ce que est -ce que ça a produit des remous ?.
	 non non.
	 enfin euh c' est récent est -ce que vous croyez que y a des possibilités de ce côté -là ?.
	 toujours pas dans le local où ils sont actuellement.
	 oui.
	 déjà puis vous savez moi je connais bien celle de gauche qui est assez assez renommée finalement y a eu un es- une espèce de flambée au au départ et puis je sais pas je pense pas que ce soit le meilleur moyen de toucher les gens.
	 comment les Maisons de Culture en général ?.
	 oui.
	 hm.
	 je crois que je suis un petit peu sceptique euh j' ai j' espère me tromper remarquez hein ? je franchement euh mais j' ai pas l' impression que ça touche beaucoup les même les jeunes euh ils y vont là-bas pour s' asseoir dans un fauteuil profond fumer une cigarette rencontrer une petite copine euh mais vraiment la culture en elle-même je sais pas j' ai peur que non c' est dommage d' ailleurs.
	
 * r-ASSOCIATIVE-jmuzerelle_1301513126905: ['u-MENTION-aboyer_1295380400537', 'u-MENTION-aboyer_1295380490690']
	alors comme j' ai dit tout à l' heure je crois qu' on va commencer par le questionnaire fermé hum ?.
	 allez -y c' est vous le patron.
	 d' accord.
	 bon première question est -ce que chez vous il y a des dictionnaires ou un dictionnaire euh.
	 euh ici ? euh dans mon entrepôt ? oui oui bien sûr.
	 **[la maison]**.
	 je peux demander lequel ?.
	 Larousse.
	 Larousse nouveau petit ou énorme ou.
	 non non euh une bonne moyenne.
	 en combien de volumes ?.
	 un un euh assez épais mais enfin un volume.
	 j' y suis et euh où est -ce que vous le gardez à la maison dans **[quelle pièce]** ?.
	 euh dans la bibliothèque.
	 et vous l' avez depuis quand ?.
	 ça vous savez euh oui enfin oh depuis une dizaine d' années certainement oui.
	 euh c' était un cadeau vous l' avez acheté.
	 non j' ai dû l' acheter pour l' étude de mes enfants certainement en.
	 et qui est -ce qui s' en sert le plus souvent ?.
	 mes enfants.
	 hum hum et vous-même ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301513533773: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466660861']
	mes enfants.
	 hum hum et vous-même ?.
	 de temps en temps oui bien sûr.
	 est -ce que vous vous rappelez la la dernière fois que vous l' avez consulté ?.
	 euh non aucune idée alors là franchement non.
	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?.
	 un **[un mot]** ou quelquefois un mot peu usuel alors on cherche l' orthographe ou le sens exact pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça.
	 et du côté des encyclopédies ?.
	 non.
	 non euh.
	 par exemple les ouvrages de référence sur le français sur euh l' art d' écrire les difficultés du français l' usage ?.
	 non.
	 non ?.
	 c' est un tort d' ailleurs.
	 ah bon ? comment ça ?.
	 oui je je devr- c' est toujours utile ah oui d' en posséder.
	 est -ce que vous faites des mots-croisés ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301513586664: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466677163']
	mes enfants.
	 hum hum et vous-même ?.
	 de temps en temps oui bien sûr.
	 est -ce que vous vous rappelez la la dernière fois que vous l' avez consulté ?.
	 euh non aucune idée alors là franchement non.
	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?.
	 un un mot ou quelquefois un mot peu usuel alors on cherche **[l' orthographe]** ou le sens exact pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça.
	 et du côté des encyclopédies ?.
	 non.
	 non euh.
	 par exemple les ouvrages de référence sur le français sur euh l' art d' écrire les difficultés du français l' usage ?.
	 non.
	 non ?.
	 c' est un tort d' ailleurs.
	 ah bon ? comment ça ?.
	 oui je je devr- c' est toujours utile ah oui d' en posséder.
	 est -ce que vous faites des mots-croisés ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301513621135: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466684373']
	mes enfants.
	 hum hum et vous-même ?.
	 de temps en temps oui bien sûr.
	 est -ce que vous vous rappelez la la dernière fois que vous l' avez consulté ?.
	 euh non aucune idée alors là franchement non.
	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?.
	 un un mot ou quelquefois un mot peu usuel alors on cherche l' orthographe ou **[le sens exact]** pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça.
	 et du côté des encyclopédies ?.
	 non.
	 non euh.
	 par exemple les ouvrages de référence sur le français sur euh l' art d' écrire les difficultés du français l' usage ?.
	 non.
	 non ?.
	 c' est un tort d' ailleurs.
	 ah bon ? comment ça ?.
	 oui je je devr- c' est toujours utile ah oui d' en posséder.
	 est -ce que vous faites des mots-croisés ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301513638614: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466691834']
	mes enfants.
	 hum hum et vous-même ?.
	 de temps en temps oui bien sûr.
	 est -ce que vous vous rappelez la la dernière fois que vous l' avez consulté ?.
	 euh non aucune idée alors là franchement non.
	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?.
	 un un mot ou quelquefois un mot peu usuel alors on cherche l' orthographe ou le sens exact pour avoir vraiment **[tous les sens d' un mot]** ou quelque chose comme ça.
	 et du côté des encyclopédies ?.
	 non.
	 non euh.
	 par exemple les ouvrages de référence sur le français sur euh l' art d' écrire les difficultés du français l' usage ?.
	 non.
	 non ?.
	 c' est un tort d' ailleurs.
	 ah bon ? comment ça ?.
	 oui je je devr- c' est toujours utile ah oui d' en posséder.
	 est -ce que vous faites des mots-croisés ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301515545623: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296393376469']
	oui.
	 et l' orthographe est -ce que c' est important ?.
	 oui.
	 hm.
	 hélas et en français c' est très difficile.
	 ah **[quel genre de difficultés]** ?.
	 euh c' est nous avons des **[des complications]** des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir le genre des règles de grammaire étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme qui est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh c' est elle qui écrit et en France c' est moi.
	 ah bon donc répartition des tâches selon la langue.
	
 * r-ASSOCIATIVE-jmuzerelle_1301515588735: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296393380119']
	oui.
	 et l' orthographe est -ce que c' est important ?.
	 oui.
	 hm.
	 hélas et en français c' est très difficile.
	 ah **[quel genre de difficultés]** ?.
	 euh c' est nous avons des des complications **[des mots]** qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir le genre des règles de grammaire étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme qui est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh c' est elle qui écrit et en France c' est moi.
	 ah bon donc répartition des tâches selon la langue.
	
 * r-ASSOCIATIVE-jmuzerelle_1301515618634: ['u-MENTION-aboyer_1296393276504', 'u-MENTION-jmuzerelle_1300741204698']
	hm hm.
	 oui oui.
	 hum pourquoi ?.
	 pour le plaisir de l' oeil.
	 oui.
	 et **[l' orthographe]** est -ce que c' est important ?.
	 oui.
	 hm.
	 hélas et en français c' est très difficile.
	 ah **[quel genre de difficultés]** ?.
	 euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir le genre des règles de grammaire étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme qui est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh c' est elle qui écrit et en France c' est moi.
	
 * r-ASSOCIATIVE-jmuzerelle_1301515727614: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296913066845']
	oui.
	 et l' orthographe est -ce que c' est important ?.
	 oui.
	 hm.
	 hélas et en français c' est très difficile.
	 ah **[quel genre de difficultés]** ?.
	 euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir **[le genre]** des règles de grammaire étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme qui est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh c' est elle qui écrit et en France c' est moi.
	 ah bon donc répartition des tâches selon la langue.
	 oui.
	
 * r-ASSOCIATIVE-jmuzerelle_1301515738992: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296912939709']
	oui.
	 et l' orthographe est -ce que c' est important ?.
	 oui.
	 hm.
	 hélas et en français c' est très difficile.
	 ah **[quel genre de difficultés]** ?.
	 euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir le genre **[des règles de grammaire]** étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme qui est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh c' est elle qui écrit et en France c' est moi.
	 ah bon donc répartition des tâches selon la langue.
	 oui.
	
 * r-ASSOCIATIVE-jmuzerelle_1301773139320: ['u-MENTION-jmuzerelle_1300914259562', 'u-MENTION-aboyer_1296394421203']
	assez répandue par le milieu professoral aussi.
	 ah bon ? oh c' est t- c' est très pratique ça enfin j' ai pas d' actions dans la maison mais c' est très très bien ah oui.
	 mais suis tout.
	 et vous utilisez **[quel genre de papier]** ?.
	 pour mes brouillons ou pour euh ?.
	 enfin si il y a une différence qu' est -ce que vous utilisez pour les brouillons ?.
	 tout ce qui me tombe sous la main.
	 oui et pour la lettre euh elle-même ?.
	 **[du papier à lettres]** euh enfin à lettres correct euh à lettres blanc en général.
	 hm hm et hum.
	 est -ce qu' il vous arrive d' avoir à écri- à écrire un mot d' excuse à l' école euh de votre enfant ?.
	 oui.
	 de vos enfants pardon est -ce que qu' est -ce que vous envoyez ? vous envoyez une lettre normale ou une carte de visite quoi.
	 oui une lettre normale euh très courte évidemment.
	 oui évidemment euh les lettres officielles ?.
	 non non non.
	 bon pas de problème.
	 et euh est -ce que il y a des choses qui vous agacent dans la façon de parler de votre femme ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301777225904: ['u-MENTION-jmuzerelle_1301001274816', 'u-MENTION-aboyer_1297335287032']
	vous regardez ou écoutez je sais jamais quel verbe employer.
	 euh les deux.
	 euh eh bien euh pas souvent non hm j' essaie de trier un peu les programmes qui sont pas toujours intéressants hélas.
	 enfin **[quel genre d' émissions]** est -ce que vous choisissez ?.
	 quand il y a **[un bon film]** euh quelques variétés mais faut pas en abuser.
	 et le cinéma vous y allez ?.
	 c' est très bizarre.
	 hum ?.
	 je peux rester un an sans aller au cinéma puis nous irons trois semaines de suite.
	 hm euh quel genre de films ?.
	 je suis l' homme très très pacifique mais je vais voir des films de guerre.
	 faut maintenir l' équilibre.
	 sans doute oui.
	
 * r-ASSOCIATIVE-jmuzerelle_1301777242760: ['u-MENTION-jmuzerelle_1301001274816', 'u-MENTION-aboyer_1297335312044']
	vous regardez ou écoutez je sais jamais quel verbe employer.
	 euh les deux.
	 euh eh bien euh pas souvent non hm j' essaie de trier un peu les programmes qui sont pas toujours intéressants hélas.
	 enfin **[quel genre d' émissions]** est -ce que vous choisissez ?.
	 quand il y a un bon film euh **[quelques variétés]** mais faut pas en abuser.
	 et le cinéma vous y allez ?.
	 c' est très bizarre.
	 hum ?.
	 je peux rester un an sans aller au cinéma puis nous irons trois semaines de suite.
	 hm euh quel genre de films ?.
	 je suis l' homme très très pacifique mais je vais voir des films de guerre.
	 faut maintenir l' équilibre.
	 sans doute oui.
	
 * r-ASSOCIATIVE-jmuzerelle_1301777441352: ['u-MENTION-jmuzerelle_1301001798443', 'u-MENTION-aboyer_1297337634861']
	et le cinéma vous y allez ?.
	 c' est très bizarre.
	 hum ?.
	 je peux rester un an sans aller au cinéma puis nous irons trois semaines de suite.
	 hm euh **[quel genre de films]** ?.
	 je suis l' homme très très pacifique mais je vais voir **[des films de guerre]**.
	 faut maintenir l' équilibre.
	 sans doute oui.
	 est -ce que à votre avis la radio la télévision le cinéma ce sont des instruments de culture ?.
	 oui je pense si c' est bien employé oui.
	 et la photo est -ce que vous faites de la photo ?.
	 pas du tout.
	 or en ce qu- ce qui concerne la peinture évidemment c' est une question un peu ennuyeuse à vous poser étant donné que c' est votre métier c' est votre métier bien bon mais en dehors de votre travail euh quelles sont vos préférences du côté de la peinture ? soit des noms propres ou des des écoles des mouvements ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301943842608: ['u-MENTION-jmuzerelle_1301342395604', 'u-MENTION-aboyer_1297614594288']
	oui.
	 à un poste indéterminé.
	 oui.
	 où y a de la musique ?.
	 oui.
	 euh **[quel genre de musique]** surtout ?.
	 bah de **[la grande musique]** c' est un grand mot mais enfin euh mettons de la bonne musique.
	 hm oui euh par exemple ?.
	 je sais pas moi ça peut être du Bach du Mozart ou ce qui m' empêche que ce qui m' empêche pas du tout de d' apprécier certaines chansons actuelles hein ?.
	 euh est -ce que vous pratiquez un instrument ?.
	 pas du tout.
	 hm euh vous possédez des disques ?.
	 oui bien sûr mais enfin c' est surtout mes enfants.
	 ah bon et est -ce que vous allez au concert ?.
	 non.
	 au théâtre ?.
	
 * r-ASSOCIATIVE-jmuzerelle_1301944402213: ['u-MENTION-aboyer_1297615688277', 'u-MENTION-aboyer_1297615848193']
	hm euh vous possédez des disques ?.
	 oui bien sûr mais enfin c' est surtout mes enfants.
	 ah bon et est -ce que vous allez au concert ?.
	 non.
	 **[au théâtre]** ?.
	 oui.
	 ici ou à Paris ? Paris toujours la même suite dans les questions quel genre de pièces ou **[quels auteurs]** ?.
	 Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui les pièces horribles les pièces noires euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous une pièce horrible ?.
	 oh où y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir quelque chose de valable bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	
 * r-ASSOCIATIVE-jmuzerelle_1301944527687: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616088605']
	ah bon et est -ce que vous allez au concert ?.
	 non.
	 au théâtre ?.
	 oui.
	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?.
	 Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui **[les pièces horribles]** les pièces noires euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous une pièce horrible ?.
	 oh où y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir quelque chose de valable bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	 ah bon alors le le cimetière de voitures ce serait peut-être pas.
	 voilà.
	
 * r-ASSOCIATIVE-jmuzerelle_1305058983987: ['u-MENTION-aboyer_1299104642878', 'u-MENTION-aboyer_1299106639547']
	donc ces ces groupes ces clans c' est constitué un peu en fonction des des parents ?.
	 des conditions sociales oui.
	 hm.
	 mais enfin ça t- ça tend à disparaître je crois encore grâce au à l' apport de de beaucoup de gens de l' extérieur.
	 hm oui.
	 mais enfin la souche orléanaise orléanaise euh on est encore en dix-huit cent quatre-vingts hein ?.
	 ah bon.
	 ah oui oui un peu.
	 cette souche orléanaise qu' est -ce qu' elle fait de façon générale ? parce que la ville euh.
	 elle se croit beaucoup.
	 enfin lesquelles sont **[ses activités]** ? **[quels genres de professions]** ?.
	 oh c' est très variable vous savez.
	 hm hm.
	 vous savez euh cette bourgeoisie euh y avait d' abord beaucoup de de fermiers de Beauce qui s' enrichissaient et qui venaient se retirer à Orléans bon puis après il y a eu au dix-neuvième à la fin du dix-neuvième vous avez eu des fabriques des choses comme ça qui a créé une bourgeoisie euh donc il s' est il s' est créé une espèce de de de couche comme ça de gens ayant certains moyens financiers quoi euh.
	 oui oui.
	 sans ça au point de vue activités même euh oh y a des commerçants aussi des choses comme ça toutes les grandes activités qui se développent maintenant si vous voulez c' est plutôt des des apports de l' extérieur hein ?.
	 ah oui.
	 oui je pense.
	 enfin les commerçants étaient admissibles.
	 les commerçants oui enfin déjà le commerçant euh enfin sérieux posé.
	 oui oui je crois oui.
	 euh là la comparaison devient intéressante parce que si on regarde euh le système de barrières mettons.
	 oui oui.
	 dans les deux pays euh côté dix-huit cent quatre-vingts comme vous dites côté anglais le commerce euh non.
	 ah bon ?.
	 ah non par définition le commerce pour pour la pratiquer pour pour le pratiquer je suis vraiment pour l' abolition du genre grammatical on s' aba- on s' abaissait.
	 oui.
	 au commerce.
	 ben oui enfin.
	
 * r-ASSOCIATIVE-jmuzerelle_1358629200972: ['u-MENTION-aboyer_1297115324666', 'u-MENTION-jmuzerelle_1300999217920']
	les deux.
	 les deux et pour quel genre de choses ?.
	 à peu près pour la même raison mais seulement c' était moins développé dans mon temps enfin c' était une impression à moi j' ai l' impression que c' était moins développé que maintenant.
	 ah bon.
	 hm hm ce laisser-aller.
	 euh est -ce qu' on prenait **[des sanctions]** ?.
	 oh oui.
	 **[quel genre]** ?.
	 je sais pas selon l' âge euh quand j' étais très jeune ça on vous privait de dessert euh euh évidemment quand on est plus âgé euh ça euh c- c' est surtout des réprimandes mais enfin y avait une réaction très nette.
	 bien bien bien alors maintenant ah oui euh italienne.
	 euh vous avez combien d' enfants ?.
	 quatre.
	 quatre enfants.
	 et euh votre profession ça s' appelle comment ?.
	 ah c' est compliqué je fais des vitraux.
	 oui.
	 je suis peintre-verrier.
	 c' est le mot que je cherchais.
	
 * s-CHAIN-53: ['u-MENTION-aboyer_1297616088605', 'u-MENTION-aboyer_1297616094236', 'u-MENTION-aboyer_1297616156013', 'u-MENTION-jmuzerelle_1301343967051']
	au théâtre ?.
	 oui.
	 ici ou à Paris ? Paris toujours la même suite dans les questions quel genre de pièces ou quels auteurs ?.
	 Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui **[les pièces horribles]** **[les pièces noires]** euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous **[une pièce horrible]** ?.
	 oh **[où]** y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir quelque chose de valable bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	 ah bon alors le le cimetière de voitures ce serait peut-être pas.
	 voilà.
	 le spectacle à regarder bon vous savez à peu près combien de fois dans l' année ? ou est -ce que c' est comme pour le cinéma ?.
	 oui c' est un peu ça oui comme le cinéma oui.
	 oui.
	 et du côté de la presse est -ce que vous prenez habituellement un journal ?.
	
 * s-CHAIN-55: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616662623']
	ah bon et est -ce que vous allez au concert ?.
	 non.
	 au théâtre ?.
	 oui.
	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?.
	 Paris oui Paris.
	 hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui les pièces horribles les pièces noires euh truc euh.
	 où est qu' il y a des.
	 hm.
	 qu' est -ce que c' est pour vous une pièce horrible ?.
	 oh où y a énormément de morts énormément de des situations dramatiques euh des choses comme ça euh moi je vais au théâtre c' est pour passer une soirée agréable euh.
	 oui.
	 essayer de voir **[quelque chose de valable]** bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi.
	 ah bon alors le le cimetière de voitures ce serait peut-être pas.
	 voilà.
	 le spectacle à regarder bon vous savez à peu près combien de fois dans l' année ? ou est -ce que c' est comme pour le cinéma ?.
	 oui c' est un peu ça oui comme le cinéma oui.
	 oui.
	 et du côté de la presse est -ce que vous prenez habituellement un journal ?.
	 oui je prends le journal local.
	 c' est lequel ?.
	 La République du Centre.
	
 * s-CHAIN-259: ['u-MENTION-aboyer_1300122506270', 'u-MENTION-aboyer_1299066255179']
	y a des choses euh il y a des choses pas mal mais il y en a d' autres.
	 enfin d' un côté Beauchamps de l' autre côté le campus parce que je crois qu' il faudra séparer.
	 euh vous savez je connais pas on on circule pas tellement facilement là-dedans puis ça fait ça fait bien six mois que j' y suis pas allé hein ?.
	 faudrait y aller moi aussi ça fait six mois que je suis pas allé y a des changements.
	 il faut que j' y retourne.
	 oui certainement.
	 très importants enfin du côté côté cité pas tellement c' est la même chose mais.
	 je crois que je crois que ça ne peut être que bénéfique pour un pour la ville.
	 hm.
	 aussi bien au point de vue euh comment dirais- je ? moi logement pur euh ambiance de vie et puis même au point de vue artistique ça ça habituera les gens à voir autre chose que des petites maisons comme dans **[ces rues -là]** **[où]**.
	 oui.
	 ça va créer une autre un autre état d' esprit je pense.
	 hm.
	 je pense si on arrive pas trop à le à le rendre uniforme et et impersonnel comme beaucoup de villes mais enfin.
	 j' ai également vu la Maison de Culture enfin la maison provisoire.
	 oui.
	 est -ce que est -ce que ça a produit des remous ?.
	 non non.
	 enfin euh c' est récent est -ce que vous croyez que y a des possibilités de ce côté -là ?.
	 toujours pas dans le local où ils sont actuellement.
	 oui.
	 déjà puis vous savez moi je connais bien celle de gauche qui est assez assez renommée finalement y a eu un es- une espèce de flambée au au départ et puis je sais pas je pense pas que ce soit le meilleur moyen de toucher les gens.
	 comment les Maisons de Culture en général ?.
	 oui.
	 hm.
	 je crois que je suis un petit peu sceptique euh j' ai j' espère me tromper remarquez hein ? je franchement euh mais j' ai pas l' impression que ça touche beaucoup les même les jeunes euh ils y vont là-bas pour s' asseoir dans un fauteuil profond fumer une cigarette rencontrer une petite copine euh mais vraiment la culture en elle-même je sais pas j' ai peur que non c' est dommage d' ailleurs.
	
