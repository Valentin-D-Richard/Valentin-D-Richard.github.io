### File: 010_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1354641991448: ['u-MENTION-jmuzerelle_1354618051093', 'u-MENTION-jmuzerelle_1354625626583'] 

	 hm et quels sont les les **[quel genre de clients]** est -ce vous avez ? euh les clientes est -ce que. avant avant euh euh **[une clientèle assez chi- assez chic]** et assez sélectionnée oui. 

 * s-CHAIN-83: ['u-MENTION-jmuzerelle_1354618051093', 'u-MENTION-jmuzerelle_1354625645744'] 

	 hm et quels sont les les **[quel genre de clients]** est -ce vous avez ? euh les clientes est -ce que. avant avant euh euh une clientèle assez chi- assez chic et assez sélectionnée oui. [...]. pourriez un petit peu m' en parler ? enfin me donner un petit peu **[le genre de personnes]** que vous aviez ?. 

### File: 026_C-5.tei

 * r-ASSOCIATIVE-jmuzerelle_1357825366307: ['u-MENTION-jmuzerelle_1357743586894', 'u-MENTION-jmuzerelle_1357743608953'] 

	 et **[quel type de papier]** utilisez- vous madame **[carreaux]** ou blanc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357825378044: ['u-MENTION-jmuzerelle_1357743586894', 'u-MENTION-jmuzerelle_1357743635520'] 

	 et **[quel type de papier]** utilisez- vous madame carreaux ou blanc ?. non blanc euh d' **[une qualité enfin acceptable]** pas pas trop pas trop basse qualité moyenne des cartes des cartes euh va voir des cartes toilées va voir chercher et tout est tu vas pas trouver non. 

 * r-ASSOCIATIVE-jmuzerelle_1357825430457: ['u-MENTION-jmuzerelle_1357743586894', 'u-MENTION-jmuzerelle_1357743677078'] 

	 et **[quel type de papier]** utilisez- vous madame carreaux ou blanc ?. non blanc euh d' une qualité enfin acceptable pas pas trop pas trop basse qualité moyenne des cartes **[des cartes]** euh va voir des cartes toilées va voir chercher et tout est tu vas pas trouver non. 

 * r-ASSOCIATIVE-jmuzerelle_1357825518720: ['u-MENTION-jmuzerelle_1357743586894', 'u-MENTION-jmuzerelle_1376483004851'] 

	 et **[quel type de papier]** utilisez- vous madame carreaux ou blanc ?. non blanc euh d' une qualité enfin acceptable pas pas trop pas trop basse qualité moyenne des cartes des cartes euh va voir des cartes toilées va voir chercher et tout est tu vas pas trouver non. [...] et c' est des vous avez. **[un format normal]** par contre j' aime bien un format classique. 

 * r-ASSOCIATIVE-jmuzerelle_1357828186379: ['u-MENTION-jmuzerelle_1357747110473', 'u-MENTION-jmuzerelle_1357747121732'] 

	 scheisse vous êtes d' où en Allemagne ? vous êtes où de **[quelle ville]** ?. euh près de **[Düsseldorf]**. 

 * r-ASSOCIATIVE-jmuzerelle_1357828846760: ['u-MENTION-jmuzerelle_1357748870201', 'u-MENTION-jmuzerelle_1357748901698'] 

	 et pour **[quel genre de choses]** surtout ?. ouh là là je sais pas je. **[correction]** de correction de la phrase ou. 

 * r-ASSOCIATIVE-jmuzerelle_1357832492043: ['u-MENTION-jmuzerelle_1357740465147', 'u-MENTION-jmuzerelle_1357753538860'] 

	 et qui de vous euh ou de votre mari possède **[la meilleure orthographe]** ?. oh c' est pareil. [...] hm. et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou des renseignements l' histoire euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357832506988: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753573929'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et **[le sens]** ou des renseignements l' histoire euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357832523243: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753582150'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou **[des renseignements]** l' histoire euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357832537720: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753594303'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou des renseignements **[l' histoire]** euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357832554209: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753631696'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou des renseignements l' histoire euh ?. n' importe quoi au fond. n' importe quoi. si on parle d' un événement si on parle ça peut aussi bien être **[géographie]** que vous comprenez euh pour situer quelque chose sur une carte moi ça serait peut-être ça serait le plus plus souvent moi ça pour ça pour des choses de géographie ou on situe mal quelquefois quand on parle d' événements ou quand on parle de je crois que ça serait surtout ben oui. 

 * s-CHAIN-109: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753898769', 'u-MENTION-jmuzerelle_1357753907505', 'u-MENTION-jmuzerelle_1357753994849', 'u-MENTION-jmuzerelle_1357753973851', 'u-MENTION-jmuzerelle_1357754007267', 'u-MENTION-jmuzerelle_1357754046485', 'u-MENTION-jmuzerelle_1357754033256', 'u-MENTION-jmuzerelle_1357753696779', 'u-MENTION-jmuzerelle_1357753706108'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou des renseignements l' histoire euh ?. **[n' importe quoi]** au fond. **[n' importe quoi]**. si on parle d' un événement si on parle **[ça]** peut aussi bien être géographie que vous comprenez euh pour situer quelque chose sur une carte moi **[ça]** serait peut-être **[ça]** serait le plus plus souvent moi **[ça]** pour **[ça]** pour des choses de géographie ou on situe mal quelquefois quand on parle d' événements ou quand on parle de je crois que ça serait surtout ben oui. des **[des dates]**. **[des dates]** ou des dates d' auteurs ou des. 

### File: 004_-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1353938094458: ['u-MENTION-jmuzerelle_1353675695859', 'u-MENTION-jmuzerelle_1353675924961'] 

	 par exemple dévier le circuit de car qui passe et qui abîme les routes et puis qui ne doit pas qui passe provisoirement enfin pour le moment moi je me réfère à des décisions supérieures c' est à dire **[le recteur]** ou bien le doyen de la fac des sciences **[qui]** préfèrent ne pas faire dévier les cars pour éviter euh des des enfin non pas des explosions mais enfin des petites manifestations ou des pour éviter de donner aux étudiants des raisons de de s' exciter alors euh on laisse faire on changera peut-être ça pendant le pendant les vacances. 

 * r-ASSOCIATIVE-jmuzerelle_1353938103275: ['u-MENTION-jmuzerelle_1353675713799', 'u-MENTION-jmuzerelle_1353675924961'] 

	 par exemple dévier le circuit de car qui passe et qui abîme les routes et puis qui ne doit pas qui passe provisoirement enfin pour le moment moi je me réfère à des décisions supérieures c' est à dire le recteur ou bien **[le doyen de la fac des sciences]** **[qui]** préfèrent ne pas faire dévier les cars pour éviter euh des des enfin non pas des explosions mais enfin des petites manifestations ou des pour éviter de donner aux étudiants des raisons de de s' exciter alors euh on laisse faire on changera peut-être ça pendant le pendant les vacances. 

### File: 026_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1357661759509: ['u-MENTION-jmuzerelle_1357638301810', 'u-MENTION-jmuzerelle_1357638327971'] 

	 c' est assez difficile c' est exact hein je je vous dis moi j' ai l' exemple de **[ces petits]** que j' ai souvent à la maison et je sais plus **[lequel]** l' autre jour m' a dit grand-mère je sais pas faire ma boucle ou elle ne tient pas hein il y a la façon de le faire. 

 * r-ASSOCIATIVE-jmuzerelle_1357727745228: ['u-MENTION-jmuzerelle_1357653315661', 'u-MENTION-jmuzerelle_1357653542774'] 

	 et dans **[quelle matière]** étiez- vous le plus fort à l' école ?. qui moi ?. oui oui. qu' est -ce que ah je préférais je préférais quand même **[les mathématiques]** au français si quand même je crois je crois c' est loin vous savez mais enfin c' était pas les mathématiques actuelles. 

 * r-ASSOCIATIVE-jmuzerelle_1357728393555: ['u-MENTION-jmuzerelle_1357654206974', 'u-MENTION-jmuzerelle_1357654227244'] 

	 et vous aviez **[quel âge]** à cette époque -là à peu près ?. ça devait être oh là oh là là je vais retrouver ça devait être **[treize ans]**. 

 * s-CHAIN-63: ['u-MENTION-jmuzerelle_1357654206974', 'u-MENTION-jmuzerelle_1357654362564', 'u-MENTION-jmuzerelle_1357654375244'] 

	 et vous aviez **[quel âge]** à cette époque -là à peu près ?. **[ça]** devait être oh là oh là là je vais retrouver **[ça]** devait être treize ans. 

### File: 026_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1357148239000: ['u-MENTION-jmuzerelle_1357132486729', 'u-MENTION-jmuzerelle_1357133364994'] 

	 nés paraît- il de Français allemands enfin on nous avait ramené des enfants un avait six ans il a été mis en Maison de l' Enfance avec des en contact avec des petits Français comme ça et au bout de peut-être deux mois il parlait **[français]** impeccablement. hm hm oui oui. [...] hm hm. et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357148275317: ['u-MENTION-jmuzerelle_1357133364994', 'u-MENTION-jmuzerelle_1357133405024'] 

	 et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. ah en français je pense déjà quand même en français en **[orthographe]** grammaire on a l' air de beaucoup passer là-dessus maintenant moi je trouve ça horrible c' est vrai ça ça hein ça paraît impensable qu' on écrive pas correctement le français qu' on le parle mal. 

 * r-ASSOCIATIVE-jmuzerelle_1357148284334: ['u-MENTION-jmuzerelle_1357133364994', 'u-MENTION-jmuzerelle_1357133413963'] 

	 et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. ah en français je pense déjà quand même en français en orthographe **[grammaire]** on a l' air de beaucoup passer là-dessus maintenant moi je trouve ça horrible c' est vrai ça ça hein ça paraît impensable qu' on écrive pas correctement le français qu' on le parle mal. 

### File: 012_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1361973719597: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897052324'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire **[orthographe]** ou sens ou des détails historiques géographiques ?. 

 * r-ASSOCIATIVE-jmuzerelle_1361973727086: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897058798'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire orthographe ou **[sens]** ou des détails historiques géographiques ?. 

 * r-ASSOCIATIVE-jmuzerelle_1361973735775: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897082885'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire orthographe ou sens ou **[des détails]** historiques géographiques ?. 

 * r-ASSOCIATIVE-jmuzerelle_1361973741765: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897088532'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire orthographe ou sens ou **[des détails historiques géographiques]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1361973832105: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897190386'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire orthographe ou sens ou des détails historiques géographiques ?. oh le plus souvent le plus souvent orthographe non en principe nous considérons que nous avons une bonne orthographe et on n' a pas besoin d' y recourir je parle pour mon foyer hein et non pas du bureau euh mais nous recherchons souvent euh le le sens exact des mots vous savez. [...] hm hm. l' étymologie vérifier que que nous prenons bien le mot dans le sens exact euh dans lequel on veut l' employer et euh bien sûr aussi **[des renseignements techniques]** scientifiques euh peu d' histoire nous ne sommes dans la famille nous sommes pas pas du tout intéressés par l' histoire. 

 * r-ASSOCIATIVE-jmuzerelle_1361973838579: ['u-MENTION-jmuzerelle_1361896938460', 'u-MENTION-jmuzerelle_1361897207437'] 

	 quand **[quel genre de chose]** est -ce que vous y cherchez le plus souvent ? je veux dire orthographe ou sens ou des détails historiques géographiques ?. oh le plus souvent le plus souvent orthographe non en principe nous considérons que nous avons une bonne orthographe et on n' a pas besoin d' y recourir je parle pour mon foyer hein et non pas du bureau euh mais nous recherchons souvent euh le le sens exact des mots vous savez. [...] hm hm. l' étymologie vérifier que que nous prenons bien le mot dans le sens exact euh dans lequel on veut l' employer et euh bien sûr aussi **[des renseignements techniques scientifiques]** euh peu d' histoire nous ne sommes dans la famille nous sommes pas pas du tout intéressés par l' histoire. 

 * r-ASSOCIATIVE-jmuzerelle_1361974452906: ['u-MENTION-jmuzerelle_1361898544809', 'u-MENTION-jmuzerelle_1361898570471'] 

	 lesquels dans **[quel journal]** dans quel journal ?. oui. oh n' importe lequel et de préférence dans **[le Canard Enchaîné]** vous connaissez le Canard Enchaîné ?. 

 * r-ASSOCIATIVE-jmuzerelle_1361976970379: ['u-MENTION-jmuzerelle_1361958135283', 'u-MENTION-jmuzerelle_1361958241956'] 

	 dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. ah voilà une question eh bien j' ai je pense que je pense que j- j' étais assez équilibré si vous voulez en ce sens que j' étais aussi enfin mes résultats étaient équivalents en lettres qu' en sciences euh j' avais beaucoup de goût pour **[la philosophie]** j' aimais beaucoup la philosophie enfin disons que finalement c' est en physique que j' étais le meilleur sûrement ce qui correspond d' ailleurs à mon activité. 

 * r-ASSOCIATIVE-jmuzerelle_1361977001376: ['u-MENTION-jmuzerelle_1361958135283', 'u-MENTION-jmuzerelle_1361958274763'] 

	 dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. ah voilà une question eh bien j' ai je pense que je pense que j- j' étais assez équilibré si vous voulez en ce sens que j' étais aussi enfin mes résultats étaient équivalents en lettres qu' en sciences euh j' avais beaucoup de goût pour la philosophie j' aimais beaucoup la philosophie enfin disons que finalement c' est en **[physique]** que j' étais le meilleur sûrement ce qui correspond d' ailleurs à mon activité. 

 * r-ASSOCIATIVE-jmuzerelle_1361978616418: ['u-MENTION-jmuzerelle_1361961781260', 'u-MENTION-jmuzerelle_1361961819419'] 

	 et **[quel type de papier]** est -ce que vous utilisez ? **[du papier]** blanc ou à lignes ou. 

 * r-ASSOCIATIVE-jmuzerelle_1361978623001: ['u-MENTION-jmuzerelle_1361961781260', 'u-MENTION-jmuzerelle_1361961825019'] 

	 et **[quel type de papier]** est -ce que vous utilisez ? **[du papier blanc ou à lignes]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1361978632845: ['u-MENTION-jmuzerelle_1361961781260', 'u-MENTION-jmuzerelle_1361961910461'] 

	 et **[quel type de papier]** est -ce que vous utilisez ? du papier blanc ou à lignes ou. ah du papier blanc. [...] parfaitement blanc. oui est -ce que vous avez occasion de vous servir **[de papier à carreaux]** quelquefois de d' utiliser. 

 * r-ASSOCIATIVE-jmuzerelle_1361980397259: ['u-MENTION-jmuzerelle_1361958135283', 'u-MENTION-jmuzerelle_1361972591114'] 

	 dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. ah voilà une question eh bien j' ai je pense que je pense que j- j' étais assez équilibré si vous voulez en ce sens que j' étais aussi enfin mes résultats étaient équivalents en lettres qu' en sciences euh j' avais beaucoup de goût pour la philosophie j' aimais beaucoup la philosophie enfin disons que finalement c' est en physique que j' étais le meilleur sûrement ce qui correspond d' ailleurs à mon activité. [...] oui et est -ce que est -ce qu' on prenait des sanctions quelquefois ?. ah non jamais jamais je je dirais qu' on n' a jamais eu besoin euh est entendu que lorsque j' étais enfant si vous voulez **[l' une de mes matières euh fortes]** c' était le français justement si vous voulez j' aimais bien ça donc je pense que je méritais pas de sanctions. 

 * s-CHAIN-21: ['u-MENTION-jmuzerelle_1361898544809', 'u-MENTION-jmuzerelle_1361898552234', 'u-MENTION-jmuzerelle_1361898692116'] 

	 lesquels dans **[quel journal]** dans **[quel journal]** ?. oui. oh **[n' importe lequel]** et de préférence dans le Canard Enchaîné vous connaissez le Canard Enchaîné ?. 

 * s-CHAIN-111: ['u-MENTION-jmuzerelle_1361962347214', 'u-MENTION-jmuzerelle_1361962368306'] 

	 oui **[quel type]** de. **[quel type d' expression]** qui m' agace ?. 

 * s-CHAIN-132: ['u-MENTION-jmuzerelle_1361958135283', 'u-MENTION-jmuzerelle_1361972486485'] 

	 dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. ah voilà une question eh bien j' ai je pense que je pense que j- j' étais assez équilibré si vous voulez en ce sens que j' étais aussi enfin mes résultats étaient équivalents en lettres qu' en sciences euh j' avais beaucoup de goût pour la philosophie j' aimais beaucoup la philosophie enfin disons que finalement c' est en physique que j' étais le meilleur sûrement ce qui correspond d' ailleurs à mon activité. [...] oui et est -ce que est -ce qu' on prenait des sanctions quelquefois ?. ah non jamais jamais je je dirais qu' on n' a jamais eu besoin euh est entendu que lorsque j' étais enfant si vous voulez l' une de **[mes matières euh fortes]** c' était le français justement si vous voulez j' aimais bien ça donc je pense que je méritais pas de sanctions. 

### File: 021_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1355927788752: ['u-MENTION-jmuzerelle_1355905135196', 'u-MENTION-jmuzerelle_1355905413599'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ? oh. un avion c' est un avion qui. [...] oui. eh bien écoutez s- ça dépend de les de de l' intelligence de l' enfant je crois moi je crois que **[seize ans]** comme on fait faire en France c' est bien. 

 * r-ASSOCIATIVE-jmuzerelle_1355927961488: ['u-MENTION-jmuzerelle_1355905135196', 'u-MENTION-jmuzerelle_1355905716099'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ? oh. un avion c' est un avion qui. [...]. euh jusqu' à **[quinze ans]** mais jusqu' à seize ans je crois cette année ou l' an qui vient je suis pas sûr oui oui. 

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1355905135196', 'u-MENTION-jmuzerelle_1355905380230', 'u-MENTION-jmuzerelle_1355905701497'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ? oh. un avion c' est un avion qui. [...] oh. oui vous dites jusque **[quel âge]** ?. oui. [...] hm. plus si on peut chez vous c' est jusque **[quel âge]** ?. 

### File: 029_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1363627516889: ['u-MENTION-jmuzerelle_1363618002446', 'u-MENTION-jmuzerelle_1363618196605'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études enfin est -ce qu' il y a un âge euh limite est -ce que vous voyez un âge limite ou enfin un âge idéal ?. mais je crois que c' est pas tellement l' âge enfin si bien sûr je pense que la loi euh oblige l' enfant à aller jusqu' à **[seize ans]** maintenant je crois en France. 

 * s-CHAIN-34: ['u-MENTION-jmuzerelle_1363615773941', 'u-MENTION-jmuzerelle_1363615801341', 'u-MENTION-jmuzerelle_1363616242412', 'u-MENTION-jmuzerelle_1363615959151', 'u-MENTION-jmuzerelle_1363615983691', 'u-MENTION-jmuzerelle_1363616067992', 'u-MENTION-jmuzerelle_1363616080562'] 

	 euh dans **[quelles matières]** est- il bon qu' un enfant soit fort à l' école est -ce qu' il y a **[des matières]** **[qui]** vous semblent plus importantes que les autres ou non. certainement pas non certainement pas moi j' apprécie beaucoup l' élève qui est doué en français je me dis qu' il est fin mais en fait c' est un tort c' est un tort parce que je pense que chaque euh chaque enfant ou peut être bon dans **[n' importe quelle matière]** peu importe à partir du moment où il est bon dans **[une matière]** je pense qu' il y a beaucoup plus d' espoir que lorsqu' il est moyen euh dans **[toutes les matières]**.. **[toutes les matières]** hum hum oui d' accord. 

 * s-CHAIN-53: ['u-MENTION-jmuzerelle_1363618002446', 'u-MENTION-jmuzerelle_1363618029777', 'u-MENTION-jmuzerelle_1363618037218', 'u-MENTION-jmuzerelle_1363618044238', 'u-MENTION-jmuzerelle_1363618052397', 'u-MENTION-jmuzerelle_1363618371666', 'u-MENTION-jmuzerelle_1363618411976', 'u-MENTION-jmuzerelle_1363618542608', 'u-MENTION-jmuzerelle_1363619147765', 'u-MENTION-jmuzerelle_1363619244610'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études enfin est -ce qu' il y a **[un âge euh limite]** est -ce que vous voyez **[un âge limite]** ou enfin **[un âge idéal]** ?. mais je crois que c' est pas tellement **[l' âge]** enfin si bien sûr je pense que la loi euh oblige l' enfant à aller jusqu' à seize ans maintenant je crois en France. je crois oui. à seize ans mais il y a des enfants qui n' aiment pas les études et à partir de ce moment -là il n' est pas question d' **[âge]** qu' on les fasse aller jusqu' à seize ans et qu' après on leur fasse faire autre chose puisque mais enfin je sais pas si c' est une question d' **[âge]** joue tellement enfin je sais que j' aurais des enfants personnellement je ferais n' importe quoi pour qu' ils fassent des études euh le plus longtemps possible à la condition que ça les intéresse s' ils ont envie de faire de la danse qu' ils fassent de la danse s' ils sont heureux en faisant de la danse.. [...] hum oui d' accord oui bien sûr. alors c' est pas tellement une question d' **[âge]** c' est une question de de goût de goût et d' aptitudes probablement d' aptitudes probablement avant le goût.. [...] oui enfin oui. oui bien à seize ans **[c']** est très bien. seize ans. seize ans **[c']** est bien non pas dix-huit ans quatorze ans non plus seize ans je trouve que c' est une bonne limite. 

### File: 009_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1364311882098: ['u-MENTION-jmuzerelle_1364291710598', 'u-MENTION-jmuzerelle_1364291727758'] 

	 enfin euh je vais vous parler un peu de votre voiture euh c' est **[quel modèle]** ?. ah bah c' est une Renault **[une 4 L]**. 

 * r-ASSOCIATIVE-jmuzerelle_1364312317995: ['u-MENTION-jmuzerelle_1364293260402', 'u-MENTION-jmuzerelle_1364293288310'] 

	 c' est parti enfin vos vos petits neveux et vos nièces euh ils sont de **[quel âge]** environ ?. ah bah maintenant vous savez c' est qu' ils sont tous euh le plus jeune quel âge il a ? hum il a **[dix-sept ans]** maintenant voyez- vous mais alors ce sont les petites nièces même si vous voulez ça. 

 * r-ASSOCIATIVE-jmuzerelle_1364313329503: ['u-MENTION-jmuzerelle_1364293260402', 'u-MENTION-jmuzerelle_1364294701295'] 

	 c' est parti enfin vos vos petits neveux et vos nièces euh ils sont de **[quel âge]** environ ?. ah bah maintenant vous savez c' est qu' ils sont tous euh le plus jeune quel âge il a ? hum il a dix-sept ans maintenant voyez- vous mais alors ce sont les petites nièces même si vous voulez ça. [...] ah bon ?. alors euh elle elle dit que il y a des choses euh vraiment qu' en cours de d' études on s' aperçoit on a fait deux ans on s' aperçoit que ça va pas aller alors c' est fini faut s' arrêter là avec les nouveaux principes on a faut reprendre à nouveau une autre branche et ça dépend suivant l' âge et tout alors elle bon elle a **[vingt-trois ans]** bah vous savez je suppose que. 

 * r-ASSOCIATIVE-jmuzerelle_1364314025656: ['u-MENTION-jmuzerelle_1364293260402', 'u-MENTION-jmuzerelle_1364295604462'] 

	 c' est parti enfin vos vos petits neveux et vos nièces euh ils sont de **[quel âge]** environ ?. ah bah maintenant vous savez c' est qu' ils sont tous euh le plus jeune quel âge il a ? hum il a dix-sept ans maintenant voyez- vous mais alors ce sont les petites nièces même si vous voulez ça. [...] oui. alors elle dit alors elles s' y prenaient à **[quatorze ans]** bon elles disaient bé tiens faudrait bien prendre le latin alors elles prétendaient que c' était un peu tard pour se reprendre dans le latin mais moi je crois le latin serait valable parce que ce je comprends pas ils le suppriment à l' église m' enfin ils disent tout en français alors dans le fond aller à l' étranger c' était bien le latin bon alors on tombait dans la c' était je ne sais pas pourquoi. 

 * r-ASSOCIATIVE-jmuzerelle_1364317172461: ['u-MENTION-jmuzerelle_1364293260402', 'u-MENTION-jmuzerelle_1364305986060'] 

	 c' est parti enfin vos vos petits neveux et vos nièces euh ils sont de **[quel âge]** environ ?. ah bah maintenant vous savez c' est qu' ils sont tous euh le plus jeune quel âge il a ? hum il a dix-sept ans maintenant voyez- vous mais alors ce sont les petites nièces même si vous voulez ça. [...] oh justement ces histoires de redoubler on trouve assez souvent qu' il y a dans ces salles dans dans la même classe par exemple il y a deux enfants qui au fond sont de la même intelligence mais il y a un qui réussit l' autre qui réussit moins bien euh est -ce que vous voyez des explications à cela ? enfin cette différence entre eux ?. oui d' accord je comprends bien je vous dis moi j' ai une nièce je vous cache pas elle a **[neuf ans]** mais alors elle était exceptionnelle formidable eh bien elle est en pension ici à Orléans eh ben cette année elle est obligée de redoubler. 

 * s-CHAIN-44: ['u-MENTION-jmuzerelle_1364293260402', 'u-MENTION-jmuzerelle_1364293281384'] 

	 c' est parti enfin vos vos petits neveux et vos nièces euh ils sont de **[quel âge]** environ ?. ah bah maintenant vous savez c' est qu' ils sont tous euh le plus jeune **[quel âge]** il a ? hum il a dix-sept ans maintenant voyez- vous mais alors ce sont les petites nièces même si vous voulez ça. 

### File: 021_C-6.tei

 * r-ASSOCIATIVE-jmuzerelle_1356881870087: ['u-MENTION-jmuzerelle_1356685731608', 'u-MENTION-jmuzerelle_1356685748159'] 

	 madame lorsque vous étiez encore à l' école dans **[quelle matière]** étiez vous le plus fort ?. ah c' était **[littérature]**. 

 * r-ASSOCIATIVE-jmuzerelle_1356881876951: ['u-MENTION-jmuzerelle_1356685731608', 'u-MENTION-jmuzerelle_1356685759828'] 

	 madame lorsque vous étiez encore à l' école dans **[quelle matière]** étiez vous le plus fort ?. ah c' était littérature. ah oui. **[le français]**. 

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1356685731608', 'u-MENTION-jmuzerelle_1356685841556'] 

	 madame lorsque vous étiez encore à l' école dans **[quelle matière]** étiez vous le plus fort ?. ah **[c']** était littérature. 

### File: 025_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1353347427438: ['u-MENTION-jmuzerelle_1353341132659', 'u-MENTION-jmuzerelle_1353341154480'] 

	 dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh là c' est tellement vieux ah c' était **[la géographie]** puis la science. 

 * r-ASSOCIATIVE-jmuzerelle_1353347432862: ['u-MENTION-jmuzerelle_1353341132659', 'u-MENTION-jmuzerelle_1353341162953'] 

	 dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh là c' est tellement vieux ah c' était la géographie puis **[la science]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353347439428: ['u-MENTION-jmuzerelle_1353341132659', 'u-MENTION-jmuzerelle_1353341421470'] 

	 dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh là c' est tellement vieux ah c' était la géographie puis la science. [...] français tu étais bon aussi. **[calcul]** euh. 

 * r-ASSOCIATIVE-jmuzerelle_1353347451262: ['u-MENTION-jmuzerelle_1353339779643', 'u-MENTION-jmuzerelle_1353341132659'] 

	 au point de vue **[français]** ?.. [...] oui aussi bien alors et oui. dans **[quelle matière]** étiez- vous le plus fort à l' école ?. 

 * r-ASSOCIATIVE-jmuzerelle_1353347840936: ['u-MENTION-jmuzerelle_1353342806921', 'u-MENTION-jmuzerelle_1353342830091'] 

	 et pour **[quel genre de choses]** ?. ah bah pour les **[des bons de commande]** les bulletins de commande et puis les la statistique de personnel et euh des travail euh statistiques travail des des employés hein. 

 * r-ASSOCIATIVE-jmuzerelle_1353347862296: ['u-MENTION-jmuzerelle_1353342806921', 'u-MENTION-jmuzerelle_1353342891072'] 

	 et pour **[quel genre de choses]** ?. ah bah pour les des bons de commande les bulletins de commande et puis les **[la statistique de personnel]** et euh des travail euh statistiques travail des des employés hein. 

 * s-CHAIN-41: ['u-MENTION-jmuzerelle_1353341132659', 'u-MENTION-jmuzerelle_1353341386339'] 

	 dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh là c' est tellement vieux ah **[c']** était la géographie puis la science. 

### File: 007_C-3.tei

 * r-ASSOCIATIVE-gpascault_1358526199459: ['u-MENTION-gpascault_1358525912985', 'u-MENTION-gpascault_1358526178953'] 

	 et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. **[mathématiques]**. 

 * r-ASSOCIATIVE-gpascault_1358527027066: ['u-MENTION-gpascault_1358526965236', 'u-MENTION-gpascault_1358526998140'] 

	 hm hm et **[quel instrument]** ?. **[un crayon]** crayon papier et un stylo plume. 

 * r-ASSOCIATIVE-gpascault_1358871173630: ['u-MENTION-gpascault_1358526965236', 'u-MENTION-gpascault_1358871123073'] 

	 hm hm et **[quel instrument]** ?. un crayon crayon papier et **[un stylo plume]**. 

 * r-ASSOCIATIVE-gpascault_1359224878715: ['u-MENTION-gpascault_1359224723944', 'u-MENTION-gpascault_1359224861071'] 

	 stylo plume et **[quel type de papier]** utilisez- vous ?. oh du papier que j' achète en librairie **[papier courant]** papier euh non rayé papier blanc. 

 * r-ASSOCIATIVE-gpascault_1359226232585: ['u-MENTION-gpascault_1359224723944', 'u-MENTION-gpascault_1359226138292'] 

	 stylo plume et **[quel type de papier]** utilisez- vous ?. oh du papier que j' achète en librairie papier courant papier euh non rayé papier blanc. [...] hm et sur le même papier ?. je prends **[papier grand format]**. 

 * r-ASSOCIATIVE-gpascault_1359226498331: ['u-MENTION-gpascault_1359224723944', 'u-MENTION-gpascault_1359226481332'] 

	 stylo plume et **[quel type de papier]** utilisez- vous ?. oh du papier que j' achète en librairie papier courant papier euh non rayé papier blanc. [...] grand format. pour ma famille mes amis je prends souvent **[papier petit format]**. 

 * r-ASSOCIATIVE-jmuzerelle_1372422639886: ['u-MENTION-jmuzerelle_1372422373468', 'u-MENTION-gpascault_1358196840520'] 

	 et **[quel genre de choses]** euh y cherchez- vous le plus souvent ?. euh dans celui-ci qui est un dictionnaire euh pas du tout le Larousse Larousse c' est le dictionnaire classique. hm hm. où on trouve euh **[toute l' étymologie des mots]** si vous voulez. 

 * r-ASSOCIATIVE-jmuzerelle_1372422902575: ['u-MENTION-jmuzerelle_1372422373468', 'u-MENTION-gpascault_1358240364783'] 

	 et **[quel genre de choses]** euh y cherchez- vous le plus souvent ?. euh dans celui-ci qui est un dictionnaire euh pas du tout le Larousse Larousse c' est le dictionnaire classique. [...] hm. euh il y a je regarde euh quelques fois **[les noms et les oeuvres euh des écrivains]**. 

 * r-ASSOCIATIVE-jmuzerelle_1372422975583: ['u-MENTION-jmuzerelle_1372422373468', 'u-MENTION-gpascault_1358241128885'] 

	 et **[quel genre de choses]** euh y cherchez- vous le plus souvent ?. euh dans celui-ci qui est un dictionnaire euh pas du tout le Larousse Larousse c' est le dictionnaire classique. [...] j' entends quelque chose à la télévision ou à la radio euh. c' est **[le sens]** alors que vous cherchez. 

 * r-ASSOCIATIVE-jmuzerelle_1372431745781: ['u-MENTION-gpascault_1359224723944', 'u-MENTION-jmuzerelle_1372431710781'] 

	 stylo plume et **[quel type de papier]** utilisez- vous ?. oh du papier que j' achète en librairie papier courant **[papier euh non rayé]** papier blanc. 

### File: 006_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1353509033528: ['u-MENTION-jmuzerelle_1353491245895', 'u-MENTION-jmuzerelle_1353491308262'] 

	 oui enfin dans **[quelle matière français]** étiez- vous le plus fort vous même à l' école monsieur ?. **[géographie]** histoire géographie. 

 * r-ASSOCIATIVE-jmuzerelle_1353509040958: ['u-MENTION-jmuzerelle_1353491245895', 'u-MENTION-jmuzerelle_1353491316049'] 

	 oui enfin dans **[quelle matière français]** étiez- vous le plus fort vous même à l' école monsieur ?. géographie **[histoire]** géographie. 

 * r-ASSOCIATIVE-jmuzerelle_1353511143949: ['u-MENTION-jmuzerelle_1353494780640', 'u-MENTION-jmuzerelle_1353494794009'] 

	 stylo plume oui oh et quel euh **[quel type de papier]** utilisez- vous en général ?. **[un bloc]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353511248012: ['u-MENTION-jmuzerelle_1353494780640', 'u-MENTION-jmuzerelle_1372262405436'] 

	 stylo plume oui oh et quel euh **[quel type de papier]** utilisez- vous en général ?. un bloc. [...] faut laisser ça pour les enfants. que pensez- vous alors des gens qui se servent par exemple de des **[du papier carreaux à carreaux]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1353511970059: ['u-MENTION-jmuzerelle_1353494780640', 'u-MENTION-jmuzerelle_1353503760591'] 

	 stylo plume oui oh et quel euh **[quel type de papier]** utilisez- vous en général ?. un bloc. [...] ils ont gardé ça de dans le temps. vous ne glissez pas **[un papier à lignes]** au-dessous du feuille blanc de la feuille blanc ? non il y a des gens qui ont. 

 * r-ASSOCIATIVE-jmuzerelle_1353513392219: ['u-MENTION-jmuzerelle_1353505420015', 'u-MENTION-jmuzerelle_1353505455334'] 

	 oui et pour **[quel genre de choses]** surtout ?. oh le français en général. ah oui. hm hm et **[la politesse]** oui. 

 * r-ASSOCIATIVE-jmuzerelle_1372257416924: ['u-MENTION-jmuzerelle_1353491798373', 'u-MENTION-jmuzerelle_1353491856748'] 

	 oui est -ce que vous pourriez vous rappeler monsieur à la suite de de **[quelles circonstances]** vous avez pour la première fois possédé un stylo à plume ou un stylo à encre ?. pour **[ma première communion]**. 

 * r-ASSOCIATIVE-jmuzerelle_1372264933607: ['u-MENTION-jmuzerelle_1353486471818', 'u-MENTION-jmuzerelle_1353505420015'] 

	 c' est le parler **[français]** anglais ? les mélangés les mots de de racines euh anglo-saxonnes ben c' est c' est normal que voulez- vous euh je trouve par exemple qu' il est plus facile de dire parking que parking ou parc même ou parquage. parquage ?. [...] ah oui à l' époque ça comptait. oui et pour **[quel genre de choses]** surtout ?. 

 * s-CHAIN-49: ['u-MENTION-jmuzerelle_1353491245895', 'u-MENTION-jmuzerelle_1353491510917'] 

	 oui enfin dans **[quelle matière français]** étiez- vous le plus fort vous même à l' école monsieur ?. géographie histoire géographie. [...] oui. mais à l' époque **[c']** était pas poussé comme maintenant. 

### File: 132_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1360247277587: ['u-MENTION-jmuzerelle_1360227027547', 'u-MENTION-jmuzerelle_1360227070968'] 

	 et que- **[quel genre de mos-croisés]** vous faites d' habitude ?. quand j' en vois sur des journaux euh sur des hebdomadaires **[des trucs]** comme ça euh je les découpe et puis quand j' ai un moment je les fais. 

 * r-ASSOCIATIVE-jmuzerelle_1360249911812: ['u-MENTION-jmuzerelle_1360231599117', 'u-MENTION-jmuzerelle_1360231609912'] 

	 oui à l' école dans **[quelle matière]** vous étiez la plus forte ?. ah j' aimais beaucoup **[les mathématiques]**. 

### File: 020_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1360940454518: ['u-MENTION-jmuzerelle_1360919393675', 'u-MENTION-jmuzerelle_1360919425764'] 

	 est -ce et **[quel genre de choses]** vous regardez dans le dictionnaire euh ? je veux dire des le **[l' orthographe]** le sens des mots. 

 * r-ASSOCIATIVE-jmuzerelle_1360940463556: ['u-MENTION-jmuzerelle_1360919393675', 'u-MENTION-jmuzerelle_1360919434874'] 

	 est -ce et **[quel genre de choses]** vous regardez dans le dictionnaire euh ? je veux dire des le l' orthographe **[le sens des mots]**. 

 * r-ASSOCIATIVE-jmuzerelle_1360940510030: ['u-MENTION-jmuzerelle_1360919393675', 'u-MENTION-jmuzerelle_1360919484982'] 

	 est -ce et **[quel genre de choses]** vous regardez dans le dictionnaire euh ? je veux dire des le l' orthographe le sens des mots. l' orthographe l' orthographe ou le sens des mots oui c' est ça. le sens et **[des renseignements d' histoire]** de géographie aussi ? oui est -ce que. 

 * r-ASSOCIATIVE-jmuzerelle_1360940516750: ['u-MENTION-jmuzerelle_1360919393675', 'u-MENTION-jmuzerelle_1375384882280'] 

	 est -ce et **[quel genre de choses]** vous regardez dans le dictionnaire euh ? je veux dire des le l' orthographe le sens des mots. l' orthographe l' orthographe ou le sens des mots oui c' est ça. le sens et **[des renseignements d' histoire de géographie]** aussi ? oui est -ce que. 

 * r-ASSOCIATIVE-jmuzerelle_1360943689772: ['u-MENTION-jmuzerelle_1360923783649', 'u-MENTION-jmuzerelle_1360924065058'] 

	 et vous de p- euh de dans **[quelles matières]** est -ce que vous étiez fort à l' école ?. ah ça remonte loin ça vous me f- ça re- ça remonte loin euh ben moi je j' aimais bien le comment vous l' appelez euh on appelait ça **[la composition française]** la rédaction la rédaction j' étais assez doué puis l' histoire de France c' était. 

 * r-ASSOCIATIVE-jmuzerelle_1360943753126: ['u-MENTION-jmuzerelle_1360919425764', 'u-MENTION-jmuzerelle_1360923783649'] 

	 est -ce et quel genre de choses vous regardez dans le dictionnaire euh ? je veux dire des le **[l' orthographe]** le sens des mots. l' orthographe l' orthographe ou le sens des mots oui c' est ça. [...] oui. et vous de p- euh de dans **[quelles matières]** est -ce que vous étiez fort à l' école ?. 

 * r-ASSOCIATIVE-jmuzerelle_1360943764465: ['u-MENTION-jmuzerelle_1360923783649', 'u-MENTION-jmuzerelle_1360924106929'] 

	 et vous de p- euh de dans **[quelles matières]** est -ce que vous étiez fort à l' école ?. ah ça remonte loin ça vous me f- ça re- ça remonte loin euh ben moi je j' aimais bien le comment vous l' appelez euh on appelait ça la composition française la rédaction la rédaction j' étais assez doué puis **[l' histoire de France]** c' était. 

 * r-ASSOCIATIVE-jmuzerelle_1360945917464: ['u-MENTION-jmuzerelle_1360936321646', 'u-MENTION-jmuzerelle_1360936353642'] 

	 oui et sur **[quel genre de papier]** vous vous vous écrivez pour les amis qu' est -ce que vous employez ?. **[papier à lettres]** euh blanc ou de couleur qu' on achète vous savez en boîte là. 

 * r-ASSOCIATIVE-jmuzerelle_1360946103712: ['u-MENTION-jmuzerelle_1360936321646', 'u-MENTION-jmuzerelle_1360937240271'] 

	 oui et sur **[quel genre de papier]** vous vous vous écrivez pour les amis qu' est -ce que vous employez ?. papier à lettres euh blanc ou de couleur qu' on achète vous savez en boîte là. [...] vous faisiez ça sur euh. sur **[un pa- un papier quadrillé]** un. 

 * r-ASSOCIATIVE-jmuzerelle_1360946223097: ['u-MENTION-jmuzerelle_1360936321646', 'u-MENTION-jmuzerelle_1360937310502'] 

	 oui et sur **[quel genre de papier]** vous vous vous écrivez pour les amis qu' est -ce que vous employez ?. papier à lettres euh blanc ou de couleur qu' on achète vous savez en boîte là. [...] et pour écrire une lettre par exemple à à une personne importante dans le travail quelque chose comme ça ?. alors là il faut **[le papier]** avec double feuille là vous savez le papier ce qu' on appelle papier ministre là papier ministre. 

 * r-ASSOCIATIVE-jmuzerelle_1360947230505: ['u-MENTION-jmuzerelle_1360938445519', 'u-MENTION-jmuzerelle_1360938466288'] 

	 **[quel genre de choses]** par exemple ?. bah si on dit si on dit **[des grossièretés]** par exemple enfin vous savez. 

 * r-ASSOCIATIVE-jmuzerelle_1360947838469: ['u-MENTION-jmuzerelle_1360938445519', 'u-MENTION-jmuzerelle_1360939242839'] 

	 **[quel genre de choses]** par exemple ?. bah si on dit si on dit des grossièretés par exemple enfin vous savez. [...] oui et elle vous reprenait pour quel genre de choses des. oh ben c' est des petites ch- des **[des mots de travers]** vous savez des mots mal prononcés ou des des p- des petites grossièretés enfin pas. 

 * s-CHAIN-102: ['u-MENTION-jmuzerelle_1360938445519', 'u-MENTION-jmuzerelle_1360939209625'] 

	 **[quel genre de choses]** par exemple ?. bah si on dit si on dit des grossièretés par exemple enfin vous savez. [...]. oui et elle vous reprenait pour **[quel genre de choses]** des. 

### File: 013_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1366986538342: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366964834718'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci c' est **[trois heures moins le quart]** deux heures et demie trois heures moins lequart de nuit. 

 * r-ASSOCIATIVE-jmuzerelle_1366986546719: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366964844016'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci c' est trois heures moins le quart **[deux heures et demie]** trois heures moins lequart de nuit. 

 * r-ASSOCIATIVE-jmuzerelle_1366986682782: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366965109809'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci c' est trois heures moins le quart deux heures et demie trois heures moins lequart de nuit. hm hm. ma femme c' est plus tard elle se lève à **[six heures]** six heures et quart mais enfin euh la plupart du temps je fais en moyenne seize heures par jour au moins. 

 * r-ASSOCIATIVE-jmuzerelle_1366986732281: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366965118171'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci c' est trois heures moins le quart deux heures et demie trois heures moins lequart de nuit. hm hm. ma femme c' est plus tard elle se lève à six heures **[six heures et quart]** mais enfin euh la plupart du temps je fais en moyenne seize heures par jour au moins. 

 * r-ASSOCIATIVE-jmuzerelle_1366989110804: ['u-MENTION-jmuzerelle_1366968557654', 'u-MENTION-jmuzerelle_1366968573514'] 

	 et votre vous avez l' aîné a **[quel âge]** ?. il a **[quatre ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1366992061895: ['u-MENTION-jmuzerelle_1366979433032', 'u-MENTION-jmuzerelle_1366979516401'] 

	 personnellement vous trouvez que qu' un enfant enfin devrait être à l' école jusqu' à **[quel âge]** ? enfin en général. je crois qu' on n' en sait jamais assez. hm qu' est -ce qui vous paraît euh enfin un âge normal de fin de scolarité ?. je crois que maintenant dans n' importe quel métier le Certificat d' Etudes est insuffisant je pense que **[le niveau de troisième]** ce serait un. 

 * r-ASSOCIATIVE-jmuzerelle_1366992614167: ['u-MENTION-jmuzerelle_1366979433032', 'u-MENTION-jmuzerelle_1366980247404'] 

	 personnellement vous trouvez que qu' un enfant enfin devrait être à l' école jusqu' à **[quel âge]** ? enfin en général. je crois qu' on n' en sait jamais assez. [...] évidemment mais en dehors des questions euh financières et caetera vous pensez quand même qu' il serait bon qu' un enfant aille davantage à l' école qu' avant ? vous verriez quoi comme comme âge minimum enfin ? auquel. **[seize ans]** c' est bien. 

 * s-CHAIN-32: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366965088999', 'u-MENTION-jmuzerelle_1366965449670'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci **[c']** est trois heures moins le quart deux heures et demie trois heures moins lequart de nuit. hm hm. ma femme **[c']** est plus tard elle se lève à six heures six heures et quart mais enfin euh la plupart du temps je fais en moyenne seize heures par jour au moins. 

 * s-CHAIN-91: ['u-MENTION-jmuzerelle_1366979433032', 'u-MENTION-jmuzerelle_1366979448335', 'u-MENTION-jmuzerelle_1366980239588', 'u-MENTION-jmuzerelle_1366980395542', 'u-MENTION-jmuzerelle_1366980492324'] 

	 personnellement vous trouvez que qu' un enfant enfin devrait être à l' école jusqu' à **[quel âge]** ? enfin en général. je crois qu' on n' en sait jamais assez. hm qu' est -ce qui vous paraît euh enfin **[un âge normal de fin de scolarité]** ?. je crois que maintenant dans n' importe quel métier le Certificat d' Etudes est insuffisant je pense que le niveau de troisième ce serait un. [...] par contre il y en a d' autres qui pourraient et puis qui peuvent pas qui peuvent pas y arriver parce que les parents ne peuvent pas les pousser aux études maintenant je sais pas il y a il y a certainement une euh des professeurs qui devraient peut-être plus je sais bien qu' il y a de plus en plus d' élèves dans la classe chaque cas particulier c' est très difficile. évidemment mais en dehors des questions euh financières et caetera vous pensez quand même qu' il serait bon qu' un enfant aille davantage à l' école qu' avant ? vous verriez quoi comme comme **[âge minimum]** enfin ? **[auquel]**. seize ans c' est bien. [...] même chose enfin. je parle de **[l' âge minimum]** euh je ne dis pas que ce serait bien pour tout le monde. 

 * s-CHAIN-103: ['u-MENTION-jmuzerelle_1366981045863', 'u-MENTION-jmuzerelle_1366981058234'] 

	 à **[quel point de vue]** ?. je sais euh. à **[quel point de vue]** ?. 

### File: 010_C-5.tei

 * r-ASSOCIATIVE-jmuzerelle_1355475694771: ['u-MENTION-jmuzerelle_1355405603937', 'u-MENTION-jmuzerelle_1355405766887'] 

	 oui pour **[quel genre de choses]** surtout ?. **[les conversations]** tout ça pour tout euh oui. 

 * r-ASSOCIATIVE-jmuzerelle_1355477959653: ['u-MENTION-jmuzerelle_1355409176404', 'u-MENTION-jmuzerelle_1355409164205'] 

	 oui oui oui oh jusqu' à **[seize ans]** à peu près oui seize ans. **[quel âge]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1355478358631: ['u-MENTION-jmuzerelle_1355409487501', 'u-MENTION-jmuzerelle_1355409505035'] 

	 il a **[quel âge]** s' il vous plaît euh votre mari ?. mon mari il a **[cinquante ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1355478776213: ['u-MENTION-jmuzerelle_1355409652125', 'u-MENTION-jmuzerelle_1355409662359'] 

	 l' autre ? ah bon ? votre votre euh fils aîné alors il a **[quel âge]** ?. eh bien Yves a **[vingt-cinq ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1355479479258: ['u-MENTION-jmuzerelle_1355409936841', 'u-MENTION-jmuzerelle_1355409999397'] 

	 euh jusqu' à **[quel âge]** quinze seize ?. ben il a été à l' école oh Yves a été à l' école euh il a bien été à l' école jusqu' à **[dix-huit ans]** oh oui oh oui. 

 * r-ASSOCIATIVE-jmuzerelle_1355479751318: ['u-MENTION-jmuzerelle_1355410141607', 'u-MENTION-jmuzerelle_1355410132435'] 

	 alors Michel c' est il a il vient de prendre **[vingt-deux ans]**. il a **[quel âge]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1355480665974: ['u-MENTION-jmuzerelle_1355410827058', 'u-MENTION-jmuzerelle_1355410840224'] 

	 et vous vous avez fait des études jusqu' à **[quel âge]** vous m' avez dit euh ?. **[seize ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1355490408331: ['u-MENTION-jmuzerelle_1355414906360', 'u-MENTION-jmuzerelle_1355415227191'] 

	 **[quel genre]** ?. et bien c' est un un instamatic Kodak. oui euh quel genre de de photos est -ce que vous faites ? **[des photos de personnes]** de groupes euh. 

 * r-ASSOCIATIVE-jmuzerelle_1355490445583: ['u-MENTION-jmuzerelle_1355414906360', 'u-MENTION-jmuzerelle_1355415298343'] 

	 **[quel genre]** ?. et bien c' est un un instamatic Kodak. oui euh quel genre de de photos est -ce que vous faites ? des photos de personnes de groupes euh. **[paysages]** ou ?. 

 * s-CHAIN-83: ['u-MENTION-jmuzerelle_1355414906360', 'u-MENTION-jmuzerelle_1355415197177'] 

	 **[quel genre]** ?. et bien c' est un un instamatic Kodak. oui euh **[quel genre de de photos]** est -ce que vous faites ? des photos de personnes de groupes euh. 

### File: 019_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1365433135762: ['u-MENTION-jmuzerelle_1365425016609', 'u-MENTION-jmuzerelle_1365425146589'] 

	 oui et à **[quelle heure]** est -ce que vous avez commencé le travail le matin ?. à quelle heure je commençais ?. [...] oh en effet. le soir je en principe on sortait sur **[les sept heures]** mais on avait pas d' heure mais alors après quand je les euh quand les lois euh s- ont été votées les lois de en trente-cinq trente-six alors euh là euh on a eu un horaire fixe. 

 * r-ASSOCIATIVE-jmuzerelle_1365433154046: ['u-MENTION-jmuzerelle_1365425016609', 'u-MENTION-jmuzerelle_1365425110475'] 

	 oui et à **[quelle heure]** est -ce que vous avez commencé le travail le matin ?. à quelle heure je commençais ?. oui. dans les temps je suis arrivée à la maison je commençais à **[sept heures et demi]**. 

 * r-ASSOCIATIVE-jmuzerelle_1365433180597: ['u-MENTION-jmuzerelle_1365425016609', 'u-MENTION-jmuzerelle_1365425245505'] 

	 oui et à **[quelle heure]** est -ce que vous avez commencé le travail le matin ?. à quelle heure je commençais ?. [...] oh en effet. le soir je en principe on sortait sur les sept heures mais on avait pas d' heure mais alors après quand je les euh quand les lois euh s- ont été votées les lois de en trente-cinq trente-six alors euh là euh on a eu **[un horaire fixe]**. 

 * r-ASSOCIATIVE-jmuzerelle_1365434594447: ['u-MENTION-jmuzerelle_1365429327932', 'u-MENTION-jmuzerelle_1365429560107'] 

	 alors dans **[quelle matière]** aimeriez- vous que les enfants soient forts ? est -ce que vous avez des des z- des avis là-dessus ?. non. [...] enfin. aujourd'hui c' est peut-être **[la chimie et la physique]** peut-être. 

 * r-ASSOCIATIVE-jmuzerelle_1365434663945: ['u-MENTION-jmuzerelle_1365429327932', 'u-MENTION-jmuzerelle_1365429736590'] 

	 alors dans **[quelle matière]** aimeriez- vous que les enfants soient forts ? est -ce que vous avez des des z- des avis là-dessus ?. non. [...]. et **[les maths]** sans doute. 

 * r-ASSOCIATIVE-jmuzerelle_1365434877478: ['u-MENTION-jmuzerelle_1365430107247', 'u-MENTION-jmuzerelle_1365430144391'] 

	 et est -ce que vous avez des des opinions euh jusqu' à jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études parce que je sais pas si vous pensez que au-dessus de di- de **[seize ans]** par exemple euh c'est-à-dire évidemment ça dépend de l' intelligence. 

 * s-CHAIN-5: ['u-MENTION-jmuzerelle_1365425016609', 'u-MENTION-jmuzerelle_1365425060960', 'u-MENTION-jmuzerelle_1365425173577'] 

	 oui et à **[quelle heure]** est -ce que vous avez commencé le travail le matin ?. à **[quelle heure]** je commençais ?. oui. [...] oh en effet. le soir je en principe on sortait sur les sept heures mais on avait pas **[d' heure]** mais alors après quand je les euh quand les lois euh s- ont été votées les lois de en trente-cinq trente-six alors euh là euh on a eu un horaire fixe. 

 * s-CHAIN-42: ['u-MENTION-jmuzerelle_1365429327932', 'u-MENTION-jmuzerelle_1365429551839', 'u-MENTION-jmuzerelle_1365429701256'] 

	 alors dans **[quelle matière]** aimeriez- vous que les enfants soient forts ? est -ce que vous avez des des z- des avis là-dessus ?. non. [...] enfin. aujourd'hui **[c']** est peut-être la chimie et la physique peut-être. peut-être oui. [...] oui avec les avances techniques n' est -ce pas ?. ça oui tout ça **[c']** est peut-être ça qui serait. 

### File: 133_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1365083569060: ['u-MENTION-jmuzerelle_1365065881099', 'u-MENTION-jmuzerelle_1365065921612'] 

	 alors **[quel genre de choses]** y cherchez- vous le plus souvent ce ce sont ? **[questions d' orthographe]** ou sens ou ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365083588810: ['u-MENTION-jmuzerelle_1365065881099', 'u-MENTION-jmuzerelle_1365065942953'] 

	 alors **[quel genre de choses]** y cherchez- vous le plus souvent ce ce sont ? questions d' orthographe ou **[sens]** ou ?. 

 * s-CHAIN-43: ['u-MENTION-jmuzerelle_1365064877673', 'u-MENTION-jmuzerelle_1365064903819'] 

	 à **[quelle occasion]** est -ce que vous les avez eus à **[quelle occasion]** depuis quand c'est-à-dire ? depuis des années ?. 

### File: 021_C-5.tei

 * r-ASSOCIATIVE-jmuzerelle_1356367690031: ['u-MENTION-jmuzerelle_1356105995578', 'u-MENTION-jmuzerelle_1356106235101'] 

	 et **[quels genres de choses]** y cherchez vous le plus souvent ? c'est-à-dire le.. bah euh n' imp- n' importe euh les **[les pays]** les les les villes pour savoir euh le nombre d' habitants euh les mots mal orthographiés. 

 * r-ASSOCIATIVE-jmuzerelle_1356367698517: ['u-MENTION-jmuzerelle_1356105995578', 'u-MENTION-jmuzerelle_1356106249395'] 

	 et **[quels genres de choses]** y cherchez vous le plus souvent ? c'est-à-dire le.. bah euh n' imp- n' importe euh les les pays les les **[les villes]** pour savoir euh le nombre d' habitants euh les mots mal orthographiés. 

 * r-ASSOCIATIVE-jmuzerelle_1356367717830: ['u-MENTION-jmuzerelle_1356105995578', 'u-MENTION-jmuzerelle_1375868902017'] 

	 et **[quels genres de choses]** y cherchez vous le plus souvent ? c'est-à-dire le.. bah euh n' imp- n' importe euh les les pays les les les villes pour savoir euh le nombre d' habitants euh **[les mots mal orthographiés]**. 

 * r-ASSOCIATIVE-jmuzerelle_1356367982422: ['u-MENTION-jmuzerelle_1356105995578', 'u-MENTION-jmuzerelle_1356106972280'] 

	 et **[quels genres de choses]** y cherchez vous le plus souvent ? c'est-à-dire le.. [...]. oui mais je je l' emploie pour pour tout pour savoir euh pour **[les cartes euh de géographie]** pour les pays pour pou- pour tout pour. 

 * r-ASSOCIATIVE-jmuzerelle_1356371862110: ['u-MENTION-jmuzerelle_1356361987561', 'u-MENTION-jmuzerelle_1356362977181'] 

	 mais madame parmi vos connaissances quelle est la personnes qui parle le mieux le français c'est-à-dire **[quelle profession]** ? pensez- vous ?. bah écoutez- moi c' est difficile à dire hein parce que je je j' appartiens au milieu médical. [...]. hm **[les professions libérales]** en général. 

### File: 079_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1350046647034: ['u-MENTION-jmuzerelle_1350030937895', 'u-MENTION-jmuzerelle_1350031024303'] 

	 dans **[quelles matières]** est -ce est- il bon qu' un enfant soit fort à l' école est -ce que y a des matières ? euh. ben actuellement le la la vie devient de plus en plus technique alors vaut mieux qu' il soit fort en **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1350046979798: ['u-MENTION-jmuzerelle_1350031933739', 'u-MENTION-jmuzerelle_1350032055981'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent les en- leurs études ?. actuellement la la scolarité est obligatoire jusqu' à **[seize ans]** ou dix-huit ans je sais pas. 

 * r-ASSOCIATIVE-jmuzerelle_1350046985336: ['u-MENTION-jmuzerelle_1350031933739', 'u-MENTION-jmuzerelle_1350032067572'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent les en- leurs études ?. actuellement la la scolarité est obligatoire jusqu' à seize ans ou **[dix-huit ans]** je sais pas. 

 * s-CHAIN-42: ['u-MENTION-jmuzerelle_1350030937895', 'u-MENTION-jmuzerelle_1350030992729'] 

	 dans **[quelles matières]** est -ce est- il bon qu' un enfant soit fort à l' école est -ce que y a **[des matières]** ? euh. 

### File: 013_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1367245932575: ['u-MENTION-jmuzerelle_1367236561193', 'u-MENTION-jmuzerelle_1367236570803'] 

	 à l' école vous vous étiez le le plus fort en **[quelle matière]** ?. ben c' est en **[français]** justement. 

 * r-ASSOCIATIVE-jmuzerelle_1367250765845: ['u-MENTION-jmuzerelle_1367242982745', 'u-MENTION-jmuzerelle_1367243071845'] 

	 ah bon pour **[quel genre de mots]** par exemple ? vous pouvez me donner un exemple de toute façon ce sont des gosses il y a pas. ah ben uniquement uniquement **[des gros mots]** quoi des. 

 * s-CHAIN-10: ['u-MENTION-jmuzerelle_1367236992253', 'u-MENTION-jmuzerelle_1367237054778'] 

	 c' est à **[quelle occasion]** c' était ?. je sais pas j' avais peut-être huit neuf ans quand j' en ai eu un. huit neuf ans et vous savez pas à **[quelle circonstance]** c' était ?. 

### File: 005_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1359019655175: ['u-MENTION-jmuzerelle_1358938304441', 'u-MENTION-jmuzerelle_1358938383682'] 

	 pareil oui dans **[quelle matière]** est -ce ?. j' ai pas réfléchi à toutes ces questions. [...] dans quelles matières est -ce que vous étiez le plus fort à l' école ?. en **[mathématiques]**. 

 * r-ASSOCIATIVE-jmuzerelle_1359022513242: ['u-MENTION-jmuzerelle_1358960332397', 'u-MENTION-jmuzerelle_1358960350333'] 

	 non **[quel type de papier]** est -ce que vous utilisez ?. qu' est -ce que vous appelez des euh. euh **[papier à carreaux]** papiers à lignes ?. 

 * r-ASSOCIATIVE-jmuzerelle_1359022522477: ['u-MENTION-jmuzerelle_1358960332397', 'u-MENTION-jmuzerelle_1358960369956'] 

	 non **[quel type de papier]** est -ce que vous utilisez ?. qu' est -ce que vous appelez des euh. euh papier à carreaux **[papiers à lignes]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1359022533179: ['u-MENTION-jmuzerelle_1358960332397', 'u-MENTION-jmuzerelle_1358960396133'] 

	 non **[quel type de papier]** est -ce que vous utilisez ?. qu' est -ce que vous appelez des euh. euh papier à carreaux papiers à lignes ?. ah non non **[papier lisse]** papier blanc bien sûr. 

 * r-ASSOCIATIVE-jmuzerelle_1359022569714: ['u-MENTION-jmuzerelle_1358960332397', 'u-MENTION-jmuzerelle_1358960498357'] 

	 non **[quel type de papier]** est -ce que vous utilisez ?. qu' est -ce que vous appelez des euh. [...] ah non non papier lisse papier blanc bien sûr. papier lisse papier blanc oui **[couleur]** ?. 

 * s-CHAIN-24: ['u-MENTION-jmuzerelle_1358938304441', 'u-MENTION-jmuzerelle_1358938352177'] 

	 pareil oui dans **[quelle matière]** est -ce ?. j' ai pas réfléchi à toutes ces questions. [...] alors ça surprend. dans **[quelles matières]** est -ce que vous étiez le plus fort à l' école ?. 

 * s-CHAIN-78: ['u-MENTION-jmuzerelle_1358962858905', 'u-MENTION-jmuzerelle_1358963130298'] 

	 oui pour **[quel genre de choses]** ?. ben surtout une question de je vous dis de mots à dire ou ne pas dire. [...] oui. oui pour **[quel genre de choses]** surtout l' institutrice. 

### File: 096_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1363079424536: ['u-MENTION-jmuzerelle_1363013165111', 'u-MENTION-jmuzerelle_1363013507235'] 

	 et vous personnellement dans **[quelle matière]** vous aimeriez que vos enfants soient forts à l' école ?. c' est **[les mathématiques]** euh je crois n- oui. 

 * r-ASSOCIATIVE-jmuzerelle_1363080011222: ['u-MENTION-jmuzerelle_1363014422165', 'u-MENTION-jmuzerelle_1363014457016'] 

	 et vous pensez que enfin d' après vous il faudrait ? jusqu' à **[quel âge]** enfin il faudrait que les enfants aillent à l' école ? tous les enfants ? qu' est -ce que vous pensez ?. eh bien vous savez euh jusqu' à **[quatorze ans]** c' est déjà la limite je trouve. 

 * r-ASSOCIATIVE-jmuzerelle_1363080035886: ['u-MENTION-jmuzerelle_1363014422165', 'u-MENTION-jmuzerelle_1363014474051'] 

	 et vous pensez que enfin d' après vous il faudrait ? jusqu' à **[quel âge]** enfin il faudrait que les enfants aillent à l' école ? tous les enfants ? qu' est -ce que vous pensez ?. eh bien vous savez euh jusqu' à quatorze ans c' est déjà la limite je trouve. hm hm. à **[seize ans]** un enfant un enfant doit savoir déjà ce qu' il veut faire hein ?. 

 * r-ASSOCIATIVE-jmuzerelle_1363084807978: ['u-MENTION-jmuzerelle_1363018718915', 'u-MENTION-jmuzerelle_1363018740178'] 

	 en général c' est pour **[quel genre de choses]** ?. euh c' est pour **[les animaux]** des choses comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1363085072711: ['u-MENTION-jmuzerelle_1363019088350', 'u-MENTION-jmuzerelle_1363019156756'] 

	 pour les chiens et on a des beaucoup de tourterelles euh des machins comme ça alors on regarde pour **[les couvées]** et tout ça. et c' est un dictionnaire ou une encyclopédie ?. [...] ce sont les. qu' est -ce que vous regardez exactement ? à **[quelle époque]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1363085255668: ['u-MENTION-jmuzerelle_1363018718915', 'u-MENTION-jmuzerelle_1363019439834'] 

	 en général c' est pour **[quel genre de choses]** ?. euh c' est pour les animaux des choses comme ça. [...] non non. est -ce que vous le regardez quelquefois pour euh **[des questions d' orthographe]** par exemple ?. 

 * s-CHAIN-37: ['u-MENTION-jmuzerelle_1363013165111', 'u-MENTION-jmuzerelle_1363013771020'] 

	 et vous personnellement dans **[quelle matière]** vous aimeriez que vos enfants soient forts à l' école ?. **[c']** est les mathématiques euh je crois n- oui. 

 * s-CHAIN-96: ['u-MENTION-jmuzerelle_1363019869583', 'u-MENTION-jmuzerelle_1363019929550', 'u-MENTION-jmuzerelle_1363019946881', 'u-MENTION-jmuzerelle_1363020143021'] 

	 c' est **[quel genre de choses]** ?. c' est quelque ch- je m' **[en]** souviens. vous vous souvenez plus pour **[quel genre de choses]** ? je m' **[en]** rappelle plus moi Ici Paris. 

### File: 014_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1350918165910: ['u-MENTION-jmuzerelle_1350890781105', 'u-MENTION-jmuzerelle_1350891033747'] 

	 euh dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ? dans quel dans quel sujet dans quelle matière ?. oh je m' en rappelle pas j' en sais rien vous savez l' école hein ?. mais enfin vous deviez être bon en quelque chose quoi mathé- en **[maths]** ou en en calcul ou en or- ou en orthographe ?. 

 * r-ASSOCIATIVE-jmuzerelle_1350918280617: ['u-MENTION-jmuzerelle_1350890781105', 'u-MENTION-jmuzerelle_1350891126786'] 

	 euh dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ? dans quel dans quel sujet dans quelle matière ?. oh je m' en rappelle pas j' en sais rien vous savez l' école hein ?. [...] oh c' était plutôt dans le calcul. calcul oui et puis après le calcul qu' est -ce que c' était **[l' histoire]** la géographie ou. 

 * r-ASSOCIATIVE-jmuzerelle_1350918289260: ['u-MENTION-jmuzerelle_1350890781105', 'u-MENTION-jmuzerelle_1350891136723'] 

	 euh dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ? dans quel dans quel sujet dans quelle matière ?. oh je m' en rappelle pas j' en sais rien vous savez l' école hein ?. [...] oh c' était plutôt dans le calcul. calcul oui et puis après le calcul qu' est -ce que c' était l' histoire **[la géographie]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1351005381464: ['u-MENTION-jmuzerelle_1350913132763', 'u-MENTION-jmuzerelle_1350913159595'] 

	 d' accord oui oui oui avec quoi est -ce que vous écrivez euh vous m' avez déjà dit un en général un stylo à bille mais vous essayez de réécrire avec un s- un stylo à plume un stylo à encre oui quand vous avez le temps oui d' accord oui oui oui oui d' accord **[quel type de papier]** est -ce que vous utilisez ?.. [...] il faut. oh **[papier normal]** vingt et un vingt-sept là. 

 * r-ASSOCIATIVE-jmuzerelle_1351005619801: ['u-MENTION-jmuzerelle_1350913132763', 'u-MENTION-jmuzerelle_1350913243508'] 

	 d' accord oui oui oui avec quoi est -ce que vous écrivez euh vous m' avez déjà dit un en général un stylo à bille mais vous essayez de réécrire avec un s- un stylo à plume un stylo à encre oui quand vous avez le temps oui d' accord oui oui oui oui d' accord **[quel type de papier]** est -ce que vous utilisez ?.. [...] comme ça oui ? ah oui. puis y a **[le papier à lettre]** le papier le beau papier là. 

 * r-ASSOCIATIVE-jmuzerelle_1351006570763: ['u-MENTION-jmuzerelle_1350913132763', 'u-MENTION-jmuzerelle_1350913796752'] 

	 d' accord oui oui oui avec quoi est -ce que vous écrivez euh vous m' avez déjà dit un en général un stylo à bille mais vous essayez de réécrire avec un s- un stylo à plume un stylo à encre oui quand vous avez le temps oui d' accord oui oui oui oui d' accord **[quel type de papier]** est -ce que vous utilisez ?.. [...]. de lignes dessous pour euh écrire droit enfin non non non oui d' accord bon vous essayez quelque fois enfin vous écrivez quelque fois au crayon ou bien à la machine à écrire euh ? non bon oui bon qu' est -ce que vous pensez des gens qui euh qui emploient **[du papier à carreaux]** par exemple ou papier en couleur ? ah bon ?. 

 * r-ASSOCIATIVE-jmuzerelle_1351006629887: ['u-MENTION-jmuzerelle_1350913132763', 'u-MENTION-jmuzerelle_1350913825659'] 

	 d' accord oui oui oui avec quoi est -ce que vous écrivez euh vous m' avez déjà dit un en général un stylo à bille mais vous essayez de réécrire avec un s- un stylo à plume un stylo à encre oui quand vous avez le temps oui d' accord oui oui oui oui d' accord **[quel type de papier]** est -ce que vous utilisez ?.. [...]. de lignes dessous pour euh écrire droit enfin non non non oui d' accord bon vous essayez quelque fois enfin vous écrivez quelque fois au crayon ou bien à la machine à écrire euh ? non bon oui bon qu' est -ce que vous pensez des gens qui euh qui emploient du papier à carreaux par exemple ou **[papier en couleur]** ? ah bon ?. 

 * r-ASSOCIATIVE-jmuzerelle_1351007049450: ['u-MENTION-jmuzerelle_1350913132763', 'u-MENTION-jmuzerelle_1350913926763'] 

	 d' accord oui oui oui avec quoi est -ce que vous écrivez euh vous m' avez déjà dit un en général un stylo à bille mais vous essayez de réécrire avec un s- un stylo à plume un stylo à encre oui quand vous avez le temps oui d' accord oui oui oui oui d' accord **[quel type de papier]** est -ce que vous utilisez ?.. [...] parce que ça fait mieux ou parce que ça fait bien. non parce que je vois pas moi **[papier à lignes]** et puis j' écris je dis ben si ça se trouve il faut suivre bien les lettres et là rien que j' écris droit la même chose. 

 * s-CHAIN-5: ['u-MENTION-jmuzerelle_1350890781105', 'u-MENTION-jmuzerelle_1350890803522', 'u-MENTION-jmuzerelle_1350890823194'] 

	 euh dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ? dans quel dans **[quel sujet]** dans **[quelle matière]** ?. 

### File: 024_C-4.tei

 * r-ASSOCIATIVE-agoudjo_1340866942322: ['u-MENTION-agoudjo_1337776303085', 'u-MENTION-agoudjo_1337776435657'] 

	 et vous à l' école vous étiez le plus fort à **[quelle matière]** ?. ah c' était l' ort- euh **[l' orthographe]**. 

 * s-CHAIN-21: ['u-MENTION-agoudjo_1337776303085', 'u-MENTION-agoudjo_1337776424029'] 

	 et vous à l' école vous étiez le plus fort à **[quelle matière]** ?. ah **[c']** était l' ort- euh l' orthographe. 

### File: 006_C-1.tei

 * r-ASSOCIATIVE-sduchon_1341308011806: ['u-MENTION-sduchon_1338742815647', 'u-MENTION-sduchon_1338742877875'] 

	 alors dans dans **[quelle matière]** aimeriez- vous que vos enfants soient fortes ?. ben en **[langues étrangères]**. 

 * r-ASSOCIATIVE-sduchon_1341482309373: ['u-MENTION-sduchon_1338745182396', 'u-MENTION-sduchon_1338745669808'] 

	 ah oui jusqu' à **[quel âge]** alors est -ce qu' il faudrait que les enfants continuent le leurs études ?. eh ben je vais vous dire une chose moi pour celui qui est capable qui peut arriver à faire quelque chose c' est normal de continuer les études. oui. maintenant euh **[l' âge scolaire à seize dix huit ans]** c' est pas bien parce que il va se passer une chose c' est que quand un enfant aura été à l' école jusqu' à quinze seize ans si c' est un loupé ça sera un loupé manuel et un loupé intellectuel quand il aura été à l' école jusqu' à seize ans il ne pourra plus apprendre un métier c' est pas possible alors qu' on fasse un tri que ceux qui vraiment sont capables continuent disons leurs études mais alors qu' on donne des débouchés de ah des métiers à ceux qui vraiment sont manuels celui qui ne peut pas être intellectuel bientôt il va falloir pour être balayeur de rues faudra le brevet on demande le brevet pour des vendeuses c' est pas nécessaire à mon avis pour s' occuper de jardins d' enfants dans pourquoi avoir fait des études jusqu' à vingt-deux ans pour s' occuper des tout petits la maternelle les jardins d' enfants on n' a pas besoin pour moi de pendant qu' il y a tant de bonnes volontés qui n' ont pas le de baccalauréat et qui se croient capables de de s' occuper de ces petits enfants maintenant c' est notre point de vue. 

 * r-ASSOCIATIVE-jmuzerelle_1353424359908: ['u-MENTION-sduchon_1338742815647', 'u-MENTION-sduchon_1338743514962'] 

	 alors dans dans **[quelle matière]** aimeriez- vous que vos enfants soient fortes ?. ben en langues étrangères. [...] oui et et quoi encore ?. la petite euh en sciences **[sciences]** et maths. 

 * r-ASSOCIATIVE-jmuzerelle_1353424369986: ['u-MENTION-sduchon_1338742815647', 'u-MENTION-sduchon_1338743439302'] 

	 alors dans dans **[quelle matière]** aimeriez- vous que vos enfants soient fortes ?. ben en langues étrangères. [...] oui et et quoi encore ?. la petite euh en sciences sciences et **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353424419718: ['u-MENTION-sduchon_1338742525487', 'u-MENTION-sduchon_1338742815647'] 

	 sûr ah oui pour **[le français]** c' est nettement bien. alors dans dans **[quelle matière]** aimeriez- vous que vos enfants soient fortes ?. 

 * s-CHAIN-80: ['u-MENTION-sduchon_1339057114734', 'u-MENTION-sduchon_1339057535325', 'u-MENTION-sduchon_1339057601030'] 

	 euh à **[quel point de vue]** ?. au **[au coin de vue]** euh **[au point de vue de la direction de la ville]**. 

### File: 019_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1365686642606: ['u-MENTION-jmuzerelle_1365673839114', 'u-MENTION-jmuzerelle_1365673858984'] 

	 et madame ah mademoiselle parmi vos connaissances euh quelle est **[la personne]** qui parle le mieux le français c'est-à-dire de **[quelle profession]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365687311984: ['u-MENTION-jmuzerelle_1365681255608', 'u-MENTION-jmuzerelle_1365681300435'] 

	 et dans **[quelle matière]** étiez- vous le plus fort à l' école ?. euh moi c' était dans le euh **[l' orthographe]** les oui. 

 * r-ASSOCIATIVE-jmuzerelle_1365687641883: ['u-MENTION-jmuzerelle_1365681691305', 'u-MENTION-jmuzerelle_1365681762899'] 

	 oui oui c' est comme presque tout le monde vous ne pouvez pas me dire à **[quelle occasion]** vous avez possédé pour la première fois un stylo à encre ?. ah non ça je me rappelle pas. [...] sûrement pas j' ai commencé comme tout le monde je sais pas de quand ça date j' en sais rien. oui oui évidemment il y a des des gens qui se rappellent que c' était pour **[leur première communion]** ou des choses comme ça oui oui oui. 

 * r-ASSOCIATIVE-jmuzerelle_1365687925500: ['u-MENTION-jmuzerelle_1365682261664', 'u-MENTION-jmuzerelle_1365682281349'] 

	 oui et c' était pour **[quel genre de choses]** alors c' était pour faire les **[les comptes]** euh ? oui oui oui oui comptabilité. 

 * r-ASSOCIATIVE-jmuzerelle_1365688875969: ['u-MENTION-jmuzerelle_1365683774467', 'u-MENTION-jmuzerelle_1365683820961'] 

	 oui et **[quel type de papier]** employez- vous préférez- vous oh je prends **[des blocs]** moi. 

 * r-ASSOCIATIVE-jmuzerelle_1365688924867: ['u-MENTION-jmuzerelle_1365683774467', 'u-MENTION-jmuzerelle_1365683977771'] 

	 oui et **[quel type de papier]** employez- vous préférez- vous oh je prends des blocs moi.. [...] oui c' est ça papier blanc. toujours blanc vous n' aimez pas **[les papiers en couleur]** ou ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365688958112: ['u-MENTION-jmuzerelle_1365683774467', 'u-MENTION-jmuzerelle_1365684105949'] 

	 oui et **[quel type de papier]** employez- vous préférez- vous oh je prends des blocs moi.. [...] oui oui oui et. vous vous vous n' utilisez jamais **[le papier à carreaux]** par exemple. 

 * s-CHAIN-30: ['u-MENTION-jmuzerelle_1365681255608', 'u-MENTION-jmuzerelle_1365681289855'] 

	 et dans **[quelle matière]** étiez- vous le plus fort à l' école ?. euh moi **[c']** était dans le euh l' orthographe les oui. 

### File: 004_-3.tei

 * s-CHAIN-3: ['u-MENTION-jmuzerelle_1354180986355', 'u-MENTION-jmuzerelle_1354181147940'] 

	 **[quel genre d' aristocratie]** **[quel genre]** ?. 

### File: 030_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1367595684641: ['u-MENTION-jmuzerelle_1367574052844', 'u-MENTION-jmuzerelle_1367574109174'] 

	 et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. en **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1367595710755: ['u-MENTION-jmuzerelle_1367574052844', 'u-MENTION-jmuzerelle_1367574163464'] 

	 et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. en maths. en maths ? tiens tiens maths en **[français]** euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367595896645: ['u-MENTION-jmuzerelle_1367574843645', 'u-MENTION-jmuzerelle_1367574927205'] 

	 et à **[la suite de quelle circonstance]** avez- vous possédé un stylo à encre pour la première fois ?. oui un stylo c' est quand j' étais à **[l' école primaire]** jusqu' en troisième et c' est quand je suis rentrée en seconde en pension euh dans le cycle secondaire à ce moment là j' ai eu un stylo à plume. 

 * r-ASSOCIATIVE-jmuzerelle_1367595989730: ['u-MENTION-jmuzerelle_1367582984236', 'u-MENTION-jmuzerelle_1367583048836'] 

	 c' était pour euh faire **[un rapport]** sur un enfant que j' avais vu en rééducation. et vous avez besoin d' écrire pour votre travail ?. oui beaucoup. et pour **[quels genres de choses]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367596021336: ['u-MENTION-jmuzerelle_1367583048836', 'u-MENTION-jmuzerelle_1367583129346'] 

	 et pour **[quels genres de choses]** ?. en plus du tra- non dans le travail ?. oui pour le travail. bon pour euh je m' o- comme je m' occupe hein de dyslexies dysorthographies je fais beaucoup **[de tableaux]** aux enfants c'est-à-dire je leur montre euh le enfin on étudie les sons mais sous une forme très très imagée c'est-à-dire qu' on fait des des on écrit plus gros avec des couleurs enfin y a certains symboles qu' ils connaissent à force de de travailler et des couleurs significatives euh mon- beaucoup donc pour montrer aux enfants et ensuite pour euh pour prendre des notes moi-même sur ce sur euh leur évolution et. 

 * r-ASSOCIATIVE-jmuzerelle_1367596097885: ['u-MENTION-jmuzerelle_1367583048836', 'u-MENTION-jmuzerelle_1367583262646'] 

	 et pour **[quels genres de choses]** ?. en plus du tra- non dans le travail ?. oui pour le travail. bon pour euh je m' o- comme je m' occupe hein de dyslexies dysorthographies je fais beaucoup de tableaux aux enfants c'est-à-dire je leur montre euh le enfin on étudie les sons mais sous une forme très très imagée c'est-à-dire qu' on fait des des on écrit plus gros avec des couleurs enfin y a certains symboles qu' ils connaissent à force de de travailler et des couleurs significatives euh mon- beaucoup donc pour montrer aux enfants et ensuite pour euh pour prendre **[des notes]** moi-même sur ce sur euh leur évolution et. 

 * r-ASSOCIATIVE-jmuzerelle_1367596438902: ['u-MENTION-jmuzerelle_1367584073527', 'u-MENTION-jmuzerelle_1367584079707'] 

	 alors je peux venir enfin je je viendrai voir Annie soit de enfin on est **[quel jour]** aujourd'hui **[mercredi]** enfin d' ici la fin de la sem- de la de la semaine et puis euh peut-être qu' on pourrait arranger quelque chose. 

 * r-ASSOCIATIVE-jmuzerelle_1367598260147: ['u-MENTION-jmuzerelle_1367588254593', 'u-MENTION-jmuzerelle_1367588282883'] 

	 et **[quel type de papier]** utilisez- vous ?. ah **[des grands formats]** feuilles blanches grand format. 

 * r-ASSOCIATIVE-jmuzerelle_1367598269379: ['u-MENTION-jmuzerelle_1367588254593', 'u-MENTION-jmuzerelle_1367588291753'] 

	 et **[quel type de papier]** utilisez- vous ?. ah des grands formats **[feuilles blanches grand format]**. 

 * r-ASSOCIATIVE-jmuzerelle_1367599994567: ['u-MENTION-jmuzerelle_1367591692331', 'u-MENTION-jmuzerelle_1367591715279'] 

	 enfin c' est c' est une édition de **[quelle année]** alors ?. celui-là il doit être de **[soixante-huit]** peut-être. 

 * r-ASSOCIATIVE-jmuzerelle_1367600257692: ['u-MENTION-jmuzerelle_1367584551349', 'u-MENTION-jmuzerelle_1367591891699'] 

	 et est- il important selon vous d' avoir de **[l' orthographe]** ?. oui enfin j' ai envie de dire oui puisque je m' occupe de rééducation de l' orthographe ça me choque toujours un petit peu enfin je pense que bon faut pas exagérer l' importance de l' orthographe. [...] c' est toujours à peu près. et vous y cherchez **[quel genre de choses]** surtout euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367600282871: ['u-MENTION-jmuzerelle_1367591891699', 'u-MENTION-jmuzerelle_1367591929670'] 

	 et vous y cherchez **[quel genre de choses]** surtout euh ?. qu' est -ce que je cherchais ?. l' orthographe ? **[le sens]** ou ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367600291336: ['u-MENTION-jmuzerelle_1367591891699', 'u-MENTION-jmuzerelle_1367591939451'] 

	 et vous y cherchez **[quel genre de choses]** surtout euh ?. qu' est -ce que je cherchais ?. l' orthographe ? le sens ou ?. non euh de des **[des connaissances]** enfin je comme je pars au Maroc je cherchais un petit peu. 

 * s-CHAIN-98: ['u-MENTION-jmuzerelle_1367594345784', 'u-MENTION-jmuzerelle_1376656402890'] 

	 ah oui et dans **[quelles matières]** est- il bon qu' un enfant soit fort ?. moi **[ça]** m' est égal enfin. 

### File: 079_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1350145541351: ['u-MENTION-jmuzerelle_1350133570751', 'u-MENTION-jmuzerelle_1350133600345'] 

	 et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. hm **[français]**. 

 * r-ASSOCIATIVE-jmuzerelle_1350145571081: ['u-MENTION-jmuzerelle_1350133570751', 'u-MENTION-jmuzerelle_1350133616900'] 

	 et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. hm français. en français. et **[grec]** parce que j' ai fait du grec aussi. 

 * r-ASSOCIATIVE-jmuzerelle_1350147097920: ['u-MENTION-jmuzerelle_1350137173446', 'u-MENTION-jmuzerelle_1350137193816'] 

	 et **[quel type de papier]** ? euh à **[carreaux]** à lignes blanc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1350147109171: ['u-MENTION-jmuzerelle_1350137173446', 'u-MENTION-jmuzerelle_1350137204976'] 

	 et **[quel type de papier]** ? euh à carreaux à **[lignes]** blanc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1350148280497: ['u-MENTION-jmuzerelle_1350138610000', 'u-MENTION-jmuzerelle_1350138639140'] 

	 et pour **[quel genre de choses]** ?. boh pour **[les expressions d' argot]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1350149099759: ['u-MENTION-jmuzerelle_1350139985752', 'u-MENTION-jmuzerelle_1350140020212'] 

	 trois jours et **[quel genre de choses]** y cherchez- vous le plus souvent c' est surtout pour **[le sens]** ?. 

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1350049921389', 'u-MENTION-jmuzerelle_1350049934072'] 

	 on va passer à un questionnaire un peu différent maintenant euh un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que est -ce qu' il doit aller à d' après vous ? quelle est **[la région de la France]** ?. 

 * s-CHAIN-6: ['u-MENTION-jmuzerelle_1350050047250', 'u-MENTION-jmuzerelle_1350050059028', 'u-MENTION-jmuzerelle_1350050219303', 'u-MENTION-jmuzerelle_1350050288676', 'u-MENTION-jmuzerelle_1350050365522', 'u-MENTION-jmuzerelle_1350050556310'] 

	 non ? et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ? y a **[des gens]** **[qu']** il devrait fréquenter d' autres qu' il devrait éviter par exemple ?. non je pense pas qu' y ait des personnes à éviter spécialement.. et **[des personnes]** à côtoyer ? pour bien apprendre. je crois qu' il vaut mieux côtoyer **[les personnes]** **[qui]** aient des des connaissances tout de même suffisantes pour leur apprendre quelque chose de d' intelligent. 

### File: 015_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1368086582253: ['u-MENTION-jmuzerelle_1368020169054', 'u-MENTION-jmuzerelle_1368021288178'] 

	 et vous utilisez **[quel type de papier]** ? carreaux ? papier à lignes ? papier blanc ? papier de couleur ? papier- bloc ?. papier blanc oui sans lignes sans carreaux sans rien enfin j' ai des lignes en dessous pour tout vous dire. [...] peut-être pas toujours ça m' est peut-être arrivé d' envoyer une lettre euh sans la recommencer. ah bon est -ce qu' il vous arrive d' utiliser **[du papier à carreaux]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1368086594251: ['u-MENTION-jmuzerelle_1368020169054', 'u-MENTION-jmuzerelle_1368020213942'] 

	 et vous utilisez **[quel type de papier]** ? carreaux ? **[papier à lignes]** ? papier blanc ? papier de couleur ? papier- bloc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1368086611825: ['u-MENTION-jmuzerelle_1368020169054', 'u-MENTION-jmuzerelle_1368020238269'] 

	 et vous utilisez **[quel type de papier]** ? carreaux ? papier à lignes ? **[papier blanc]** ? papier de couleur ? papier- bloc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1368086623821: ['u-MENTION-jmuzerelle_1368020169054', 'u-MENTION-jmuzerelle_1368020245957'] 

	 et vous utilisez **[quel type de papier]** ? carreaux ? papier à lignes ? papier blanc ? **[papier de couleur]** ? papier- bloc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1368086635303: ['u-MENTION-jmuzerelle_1368020169054', 'u-MENTION-jmuzerelle_1368020270896'] 

	 et vous utilisez **[quel type de papier]** ? carreaux ? papier à lignes ? papier blanc ? papier de couleur ? **[papier- bloc]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1368087637519: ['u-MENTION-jmuzerelle_1368021904395', 'u-MENTION-jmuzerelle_1368021952215'] 

	 oui euh est -ce que c' était pour **[quel genre de choses]** ?. quand enfin dans la langue si on veut quand je disais plutôt **[des mots grossiers]**. 

 * r-ASSOCIATIVE-jmuzerelle_1368088018338: ['u-MENTION-jmuzerelle_1368002840407', 'u-MENTION-jmuzerelle_1368021904395'] 

	 enfin je crois je crois moi je ne sais pas mais enfin on mélange quand même beaucoup **[mots]** beaucoup de mots d' argot ou enfin ça dépend quand même dans les dans les conversations où l' on se trouve ou dans les comment on est disposé à ce moment -là mais enfin euh on parle pas mieux moi je trouve enfin je trouve que l' on parle pas mieux plus mal peut-être pas mais mieux euh je trouve pas. quel sens ?. [...] oh les enfin les deux de mes de mes parents. oui euh est -ce que c' était pour **[quel genre de choses]** ?. 

 * s-CHAIN-124: ['u-MENTION-jmuzerelle_1368021904395', 'u-MENTION-jmuzerelle_1368022579742'] 

	 oui euh est -ce que c' était pour **[quel genre de choses]** ?. quand enfin dans la langue si on veut quand je disais plutôt des mots grossiers. [...] ah oui. hm hm et est -ce que **[quel genre de choses]** ? mêmes choses ?. 

 * s-CHAIN-138: ['u-MENTION-jmuzerelle_1368024158835', 'u-MENTION-jmuzerelle_1368024241048', 'u-MENTION-jmuzerelle_1368024293624'] 

	 hm hm et est -ce que euh enfin pour bien apprendre **[quels gens]** est -ce qu' il faudrait fréquenter ? qui est -ce qu' il faudrait voir ?. **[tout]**. tout **[tout]** ? oui il y a il y a des. 

### File: 029_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1363872602275: ['u-MENTION-jmuzerelle_1363854650458', 'u-MENTION-jmuzerelle_1363854661378'] 

	 bon alors euh un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous lui conseillez d' aller ?. mais **[Tours]** bien sûr c' est là qu' on parle le mieux français non réellement. 

 * r-ASSOCIATIVE-jmuzerelle_1363872638295: ['u-MENTION-jmuzerelle_1363854650458', 'u-MENTION-jmuzerelle_1363854731142'] 

	 bon alors euh un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous lui conseillez d' aller ?. mais Tours bien sûr c' est là qu' on parle le mieux français non réellement. [...] oui d' accord. accent c' est incontestablement que **[la région de Tours]** et l' Orléanais l' accent est plus. 

 * r-ASSOCIATIVE-jmuzerelle_1363872657592: ['u-MENTION-jmuzerelle_1363854650458', 'u-MENTION-jmuzerelle_1363854750002'] 

	 bon alors euh un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous lui conseillez d' aller ?. mais Tours bien sûr c' est là qu' on parle le mieux français non réellement. [...] oui d' accord. accent c' est incontestablement que la région de Tours et **[l' Orléanais]** l' accent est plus. 

 * r-ASSOCIATIVE-jmuzerelle_1363873721163: ['u-MENTION-jmuzerelle_1363856216890', 'u-MENTION-jmuzerelle_1363856276576'] 

	 et pour bien apprendre le français **[quels gens]** devrait- il fréquenter et pourquoi ?. bah moi je je n' hésiterais pas hein à dire qu' il y a presque sans problème un certain milieu à fréquenter. hum hum. oh le mieux c' est la fac la fac de lettres alors là vous parlerez bien français **[les professeurs]** en France parlent un français extraordinaire. 

 * r-ASSOCIATIVE-jmuzerelle_1363873795294: ['u-MENTION-jmuzerelle_1363856216890', 'u-MENTION-jmuzerelle_1363856346308'] 

	 et pour bien apprendre le français **[quels gens]** devrait- il fréquenter et pourquoi ?. bah moi je je n' hésiterais pas hein à dire qu' il y a presque sans problème un certain milieu à fréquenter. [...] oui. mais au niveau des familles je pense qu' il vaut mieux quand même aller pour parler un bon français euh je sais pas dans dans un milieu d' **[industriels]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1363873820863: ['u-MENTION-jmuzerelle_1363856216890', 'u-MENTION-jmuzerelle_1363856358211'] 

	 et pour bien apprendre le français **[quels gens]** devrait- il fréquenter et pourquoi ?. bah moi je je n' hésiterais pas hein à dire qu' il y a presque sans problème un certain milieu à fréquenter. [...] hum hum. **[des gens]** qui ont fait des études y a quand même en France un certain nombre de gens par la parmi la génération de mes parents qui ne parlent pas un très bon français hein. 

### File: 010_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1355222324422: ['u-MENTION-jmuzerelle_1355156909134', 'u-MENTION-jmuzerelle_1355156945094'] 

	 ça mais alors vous pouvez me citer **[quel genre de mots]** euh ?. je ne sais pas quand on se promène dans les rues on voit **[snack-bar]** par exemple c' est pas un mot français quoi snack-bar euh. 

 * r-ASSOCIATIVE-jmuzerelle_1355222501461: ['u-MENTION-jmuzerelle_1355156909134', 'u-MENTION-jmuzerelle_1355156981685'] 

	 ça mais alors vous pouvez me citer **[quel genre de mots]** euh ?. je ne sais pas quand on se promène dans les rues on voit snack-bar par exemple c' est pas un mot français quoi snack-bar euh. ça choque pas on y est habitué maintenant non ça ça ne choque pas pas du tout **[parking]** euh euh parking des choses comme ça non non moi je trouve pas ça non. 

### File: 025_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1353080677524: ['u-MENTION-agoudjo_1337864293781', 'u-MENTION-agoudjo_1337864333562'] 

	 oui et vous vous aviez **[quels horaires]** vous ? commenciez à ?. ah bah je faisais **[un service alterné]** la nuit la journée euh. 

 * r-ASSOCIATIVE-jmuzerelle_1353081897680: ['u-MENTION-agoudjo_1337872204421', 'u-MENTION-agoudjo_1337872240171'] 

	 **[quelle matière]** aimeriez- vous que vos enfants soient forts ?.. **[les mathématiques]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353081906634: ['u-MENTION-agoudjo_1337872204421', 'u-MENTION-agoudjo_1337872299671'] 

	 **[quelle matière]** aimeriez- vous que vos enfants soient forts ?.. [...] les mathématiques oui. et **[les sciences]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353082625674: ['u-MENTION-agoudjo_1337873156671', 'u-MENTION-agoudjo_1337873344234'] 

	 jusqu' à **[quel âge]** faudrait- il que les enfants restent à l' école à votre avis ?. oh à l' heure actuelle ils vont jusqu' à **[seize ans]** je crois que c' est déjà c' est largement suffisant. 

 * r-ASSOCIATIVE-jmuzerelle_1353082738166: ['u-MENTION-agoudjo_1337873156671', 'u-MENTION-agoudjo_1337873619843'] 

	 jusqu' à **[quel âge]** faudrait- il que les enfants restent à l' école à votre avis ?. oh à l' heure actuelle ils vont jusqu' à seize ans je crois que c' est déjà c' est largement suffisant. c' est suffisant oui vous croyez que c' est bon pour ces ?. bah oui parce que après euh quand ils sortent de l' école de à quel âge et alors si ils sortent à l' école à **[vingt ans]** euh ils sortent de l' école avec rien dans les mains ils ont pas de métier rien du tout hein alors je vois pas c' est euh. 

 * r-ASSOCIATIVE-jmuzerelle_1353084005251: ['u-MENTION-agoudjo_1337890168796', 'u-MENTION-agoudjo_1337890439703'] 

	 euh un étranger un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est- il bon qu' il aille d' après vous ?. pour apprendre le français ?. oui. bah c' est vrai on dit toujours que la **[l' Orléanais et la Touraine]** c' est des hein le coin où qu' on parle le mieux le français mais. 

 * r-ASSOCIATIVE-jmuzerelle_1376383350036: ['u-MENTION-agoudjo_1337891022484', 'u-MENTION-agoudjo_1337891173046'] 

	 nan euh et pour bien apprendre le français **[quelles gens]** devrait- il fréquenter ?. bah là je peux pas vous je peux pas vous dire parce que il me semble que c' est **[tout le monde]** le tout le monde parle le français comme il faut. 

 * s-CHAIN-46: ['u-MENTION-agoudjo_1337873156671', 'u-MENTION-agoudjo_1337873565531'] 

	 jusqu' à **[quel âge]** faudrait- il que les enfants restent à l' école à votre avis ?. oh à l' heure actuelle ils vont jusqu' à seize ans je crois que c' est déjà c' est largement suffisant. c' est suffisant oui vous croyez que c' est bon pour ces ?. bah oui parce que après euh quand ils sortent de l' école de à **[quel âge]** et alors si ils sortent à l' école à vingt ans euh ils sortent de l' école avec rien dans les mains ils ont pas de métier rien du tout hein alors je vois pas c' est euh. 

 * s-CHAIN-71: ['u-MENTION-agoudjo_1337890168796', 'u-MENTION-agoudjo_1337890804296', 'u-MENTION-agoudjo_1337890857234'] 

	 euh un étranger un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est- il bon qu' il aille d' après vous ?. pour apprendre le français ?. [...] maintenant ça reste à le prouver je sais pas. oui alors Orléans hein pourquoi ? vous croyez qu' il y a vous voyez **[une région]** euh ?. non moi j' **[en]** vois pas. 

### File: 542_C-3.tei

 * s-CHAIN-103: ['u-MENTION-jmuzerelle_1362503664355', 'u-MENTION-jmuzerelle_1362503674765'] 

	 et d' après vous ça va prendre **[quelle forme]** ce ?. oh ça prendra **[la forme]** que ça a prit au mois de mai et au mois de juin euh grèves euh occupations d' usines. 

### File: 004_-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1354554167612: ['u-MENTION-jmuzerelle_1354543914143', 'u-MENTION-jmuzerelle_1354543949373'] 

	 et enfin dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. en sport c' est malheureux euh enfin **[ma véritable matière]** ben c' était c' était surtout l' histoire je crois parce que l' histoire m' intéressait ensuite on peut mettre les maths parce que j' avais des facilités mais comme je travaillais pas beaucoup eh bien ma foi euh mes résultats étaient pas formidables quand même. 

 * r-ASSOCIATIVE-jmuzerelle_1354554233023: ['u-MENTION-jmuzerelle_1354543914143', 'u-MENTION-jmuzerelle_1354543978883'] 

	 et enfin dans **[quelle matière]** est -ce que vous étiez le plus fort à l' école ?. en sport c' est malheureux euh enfin ma véritable matière ben c' était c' était surtout l' histoire je crois parce que l' histoire m' intéressait ensuite on peut mettre **[les maths]** parce que j' avais des facilités mais comme je travaillais pas beaucoup eh bien ma foi euh mes résultats étaient pas formidables quand même. 

 * r-ASSOCIATIVE-jmuzerelle_1354555171126: ['u-MENTION-jmuzerelle_1354544079813', 'u-MENTION-jmuzerelle_1354544241664'] 

	 **[quel genre]** ? stylo crayon stylo **[stylo- bille]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1354555192576: ['u-MENTION-jmuzerelle_1354544079813', 'u-MENTION-jmuzerelle_1354544250904'] 

	 **[quel genre]** ? stylo crayon stylo stylo- bille ?. j' ai eu **[un stylo à plume]** et maintenant j' ai presque toujours un stylo à bille. 

 * r-ASSOCIATIVE-jmuzerelle_1354557221944: ['u-MENTION-jmuzerelle_1354548758502', 'u-MENTION-jmuzerelle_1371737237566'] 

	 hm hm et **[quel type de papier]** pour euh votre correspondance personnelle ?. ah bah j' ai du papier euh vous voulez que je vous montre ?. oh. un papier non c' est **[un format euh format lettre]** une euh non une une enveloppe allongée. 

### File: 018_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1366128604432: ['u-MENTION-jmuzerelle_1366099541807', 'u-MENTION-jmuzerelle_1366099557688'] 

	 oh les différences sociales sont je crois les mêmes partout en France vous savez euh il y a ça dépend d' ailleurs quelle couche euh **[quel critère]** sur quel critère on veut se baser mais si c' est **[l' argent]** si c' est la situation c' est je crois que c' est un peu semblable partout en France. 

 * r-ASSOCIATIVE-jmuzerelle_1366128614042: ['u-MENTION-jmuzerelle_1366099541807', 'u-MENTION-jmuzerelle_1375285508863'] 

	 oh les différences sociales sont je crois les mêmes partout en France vous savez euh il y a ça dépend d' ailleurs quelle couche euh **[quel critère]** sur quel critère on veut se baser mais si c' est l' argent si c' est **[la situation]** c' est je crois que c' est un peu semblable partout en France. 

 * s-CHAIN-15: ['u-MENTION-jmuzerelle_1366099541807', 'u-MENTION-jmuzerelle_1366099549763', 'u-MENTION-jmuzerelle_1366099708602', 'u-MENTION-jmuzerelle_1366099714655'] 

	 oh les différences sociales sont je crois les mêmes partout en France vous savez euh il y a ça dépend d' ailleurs quelle couche euh **[quel critère]** sur **[quel critère]** on veut se baser mais si **[c']** est l' argent si **[c']** est la situation c' est je crois que c' est un peu semblable partout en France. 

### File: 078_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1358272597134: ['u-MENTION-jmuzerelle_1358258584612', 'u-MENTION-jmuzerelle_1358258605402'] 

	 hm hm oui justement c' est bien et dans **[quelle matière]** aimeriez- vous que vos enfants soient forts ?. eh bien j' aurais aimé qu' ils soient forts en en **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1358278871210: ['u-MENTION-jmuzerelle_1358261228124', 'u-MENTION-jmuzerelle_1358261715393'] 

	 hm hm hm hm mais euh oui et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. c' est encore variable ça dépend euh de des des des aptitudes des enfants si un enfant est très doué moi j' estime qu' il ne faut pas hésiter il faut le pousser gratuitement très loin. [...] hm hm. alors c' est pour ça que euh c' est très variable euh je pense que le système français qui était à **[quatorze ans]** pas mal maintenant on a mis seize ans. 

 * r-ASSOCIATIVE-jmuzerelle_1358278888598: ['u-MENTION-jmuzerelle_1358261228124', 'u-MENTION-jmuzerelle_1358261727884'] 

	 hm hm hm hm mais euh oui et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. c' est encore variable ça dépend euh de des des des aptitudes des enfants si un enfant est très doué moi j' estime qu' il ne faut pas hésiter il faut le pousser gratuitement très loin. [...] hm hm. alors c' est pour ça que euh c' est très variable euh je pense que le système français qui était à quatorze ans pas mal maintenant on a mis **[seize ans]**. 

 * s-CHAIN-127: ['u-MENTION-jmuzerelle_1358261228124', 'u-MENTION-jmuzerelle_1358261322834', 'u-MENTION-jmuzerelle_1358261331804'] 

	 hm hm hm hm mais euh oui et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. **[c']** est encore variable **[ça]** dépend euh de des des des aptitudes des enfants si un enfant est très doué moi j' estime qu' il ne faut pas hésiter il faut le pousser gratuitement très loin. 

### File: 009_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1364563745826: ['u-MENTION-jmuzerelle_1364468166856', 'u-MENTION-jmuzerelle_1364468436916'] 

	 et vous euh quand vous étiez à l' école dans **[quelle matière]** est -ce que vous étiez la plus forte ?. ah moi j' étais une petite une petite fille euh bien calme. [...] ah bon ?. moyenne j' avais rien de préféré parce que rien de ah si j' étais bonne en **[sport]**. 

 * r-ASSOCIATIVE-jmuzerelle_1364568680249: ['u-MENTION-jmuzerelle_1364483308661', 'u-MENTION-jmuzerelle_1364483350797'] 

	 et est -ce que vous avez des préférences du côté papier ? **[quel genre de papier]** ?. c'est-à-dire euh c' est comme toujours maintenant bon je prends **[le papier ordinaire]** mais avant j' aimais bien avoir un papier personnel papier à moi et puis alors euh j' étais quand même euh sans être rayé quoi je le prenais assez bien mais maintenant non je prends le papier ordinaire rayé. 

 * r-ASSOCIATIVE-jmuzerelle_1364568815766: ['u-MENTION-jmuzerelle_1364483308661', 'u-MENTION-jmuzerelle_1364483567846'] 

	 et est -ce que vous avez des préférences du côté papier ? **[quel genre de papier]** ?. c'est-à-dire euh c' est comme toujours maintenant bon je prends le papier ordinaire mais avant j' aimais bien avoir un papier personnel papier à moi et puis alors euh j' étais quand même euh sans être rayé quoi je le prenais assez bien mais maintenant non je prends le papier ordinaire rayé. [...] toujours je crois par esprit d' économie alors peut-être que ça restera. est -ce qu' il vous arrive d' utiliser **[du papier à carreaux]** ?. 

 * s-CHAIN-69: ['u-MENTION-jmuzerelle_1364468166856', 'u-MENTION-jmuzerelle_1364468378746'] 

	 et vous euh quand vous étiez à l' école dans **[quelle matière]** est -ce que vous étiez la plus forte ?. ah moi j' étais une petite une petite fille euh bien calme. [...] je m' embrouillais ah oui. est -ce que enfin est -ce que vous aviez **[des matières préférées]** ?. 

### File: 014_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1373469825934: ['u-MENTION-jmuzerelle_1350309421810', 'u-MENTION-jmuzerelle_1350309539655'] 

	 alors à votre avis jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants euh continuent euh à l' école ?. ah ça ça dépend de l' enfant moi je sais pas hein ça cette question. [...] oui. y a des gosses on va les laisser aller à l' école jusqu' à **[seize ans]** et puis s' ils font rien je sais pas si ça avance beaucoup. 

### File: 131_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1360408077555: ['u-MENTION-jmuzerelle_1360319889990', 'u-MENTION-jmuzerelle_1360319963670'] 

	 dans **[quelles matières]** aimeriez- vous que les enfants soient forts ?. en maths. [...] pourquoi spécialement les maths ?. ben parce que je sais pas moi euh il paraît que c' est c' est ça qui dirige un peu tout les maths et le français évidemment **[ces deux choses -là]**. 

### File: 217_C.tei

 * r-ASSOCIATIVE-jmuzerelle_1349537970650: ['u-MENTION-jmuzerelle_1349263952667', 'u-MENTION-jmuzerelle_1349264036820'] 

	 ah oui à **[quelle heure]** ?. si ça vous intéresse euh. c'est-à-dire nous on avait projeté de faire ça vers **[huit heures et demie]** mais. 

 * r-ASSOCIATIVE-jmuzerelle_1349538058151: ['u-MENTION-jmuzerelle_1349263952667', 'u-MENTION-jmuzerelle_1349264135329'] 

	 ah oui à **[quelle heure]** ?. si ça vous intéresse euh. [...] oui oui. si ça vous dirait euh je sais pas si si vous voyez **[une autre heure]** qui. 

 * r-ASSOCIATIVE-jmuzerelle_1349538124326: ['u-MENTION-jmuzerelle_1349263952667', 'u-MENTION-jmuzerelle_1349264274371'] 

	 ah oui à **[quelle heure]** ?. si ça vous intéresse euh. [...]. et ils auraient dé- ils auront déjà soupé ou est -ce que vous croyez que **[neuf heures]**. 

 * r-ASSOCIATIVE-jmuzerelle_1349699793993: ['u-MENTION-jmuzerelle_1349263952667', 'u-MENTION-jmuzerelle_1349355473681'] 

	 ah oui à **[quelle heure]** ?. si ça vous intéresse euh. [...] hm. oui alors si ça vous va euh mademoiselle Biggs viendra vous chercher vers euh **[huit heures dix]** huit heures et quart. 

 * r-ASSOCIATIVE-jmuzerelle_1349699812542: ['u-MENTION-jmuzerelle_1349263952667', 'u-MENTION-jmuzerelle_1377684135160'] 

	 ah oui à **[quelle heure]** ?. si ça vous intéresse euh. [...] hm. oui alors si ça vous va euh mademoiselle Biggs viendra vous chercher vers euh huit heures dix **[huit heures et quart]**. 

 * s-CHAIN-18: ['u-MENTION-jmuzerelle_1349352941466', 'u-MENTION-jmuzerelle_1349352978734'] 

	 alors en même temps j' ai dit faut m' écrire pour savoir euh quand est -ce **[quel jour]** vous viendrez et **[quel jour]** je pourrais voir ce jeune ménage jeune jeune ménage il y a un an. 

### File: 007_C-1.tei

 * r-ASSOCIATIVE-gpascault_1357898507778: ['u-MENTION-gpascault_1354807796650', 'u-MENTION-gpascault_1354807900663'] 

	 et dans et dans **[quelles matières]** aimeriez- vous que vos enfants soient forts ?. en mathématiques premièrement euh **[physique chimie]** je pense que c' est l' avenir. 

 * r-ASSOCIATIVE-jmuzerelle_1372341468808: ['u-MENTION-gpascault_1354703933371', 'u-MENTION-gpascault_1354807796650'] 

	 l' enseignement c' est pour leur apprendre un tas de choses l' histoire la géographie **[les mathématiques]** euh l' orthographe enfin toutes sortes de matières euh l' éducation c' est tout à fait différent à mon avis c' est c' est pousser un enfant dans le droit chemin. hm hm. [...] le latin j' ai eu bien des déboires avec le latin pas moi personnellement mais pour mon fils aîné il a maintenant treize ans en sortant du cours moyen deuxième année au moment d' entrer euh en sixième on leur a fait passer des tests et le proviseur du lycée m' a dit euh vous avez fait une demande pour qu' il ait moderne qu' il suive une classe moderne je ne vous conseille pas mettez- le en classique il fera un très bon classique nous avons essayé une sixième sixième pas brillante nous avons essayé une cinquième déplorable il avait des moins cinquante-cinq en latin vous dire un peu à quel point ces tests euh tout ça fichait la moyenne en l' air faut dire le mot il a pas pu continuer il est passé en moderne je l' ai retiré du lycée où il était il est dans un autre établissement en moderne et ça marche très très bien euh je crois qu' il faut que les enfants aient vraiment des dispositions pour euh pour bien réussir en latin et avoir une idée quand même de l' avenir euh le latin je sais pas si il y a tellement de débouchés mis à part les bibliothécaires. et dans et dans **[quelles matières]** aimeriez- vous que vos enfants soient forts ?. 

 * s-CHAIN-83: ['u-MENTION-gpascault_1354809163062', 'u-MENTION-gpascault_1354809389458'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. **[tout ça]** dépend si ils réussissent ou non si ils ne réussissent pas je pense que c' est vraiment du temps perdu de vouloir à toute force qu' ils restent en classe pour dire euh ils sont étudiants ou ils sont lycéens d' autre part si ils sont des enfants doués si les parents ont les moyens ce qui est aussi. 

### File: 096_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1363105952511: ['u-MENTION-jmuzerelle_1363094687923', 'u-MENTION-jmuzerelle_1363094697174'] 

	 un peu et dans dans **[quelle matière]** vous étiez la plus forte ?. euh **[les calculs]** un peu. 

 * r-ASSOCIATIVE-jmuzerelle_1363106036907: ['u-MENTION-jmuzerelle_1363095053541', 'u-MENTION-jmuzerelle_1363095063790'] 

	 on vous l' avait offert ? ou on à **[quelle occasion]** ?.. oh c' était pour **[un Noël]** ou le Jour de l' an comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1363106042617: ['u-MENTION-jmuzerelle_1363095053541', 'u-MENTION-jmuzerelle_1363095075303'] 

	 on vous l' avait offert ? ou on à **[quelle occasion]** ?.. oh c' était pour un Noël ou **[le Jour de l' an]** comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1363109142611: ['u-MENTION-jmuzerelle_1363100788822', 'u-MENTION-jmuzerelle_1363100816418'] 

	 pour **[quel genre de choses]** ?. pour **[des âneries]**. 

 * r-ASSOCIATIVE-jmuzerelle_1363109366877: ['u-MENTION-jmuzerelle_1363100788822', 'u-MENTION-jmuzerelle_1363100885526'] 

	 pour **[quel genre de choses]** ?. pour des âneries. [...] des âneries il faisait que s' énerver alors euh. c' était plutôt pour des questions de langue ou des questions **[de gros mots]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1363109393365: ['u-MENTION-jmuzerelle_1363101051479', 'u-MENTION-jmuzerelle_1363102360258'] 

	 **[quel genre de sanctions]** ?. on était on était collé comme on dit hm on restait euh **[les punitions]** ça se fait le soir. 

 * r-ASSOCIATIVE-jmuzerelle_1363110143415: ['u-MENTION-jmuzerelle_1363103955880', 'u-MENTION-jmuzerelle_1377265841643'] 

	 et ils avaient été à l' école dans une des dans quel euh dans **[quel type d' école]** c' était **[une école publique]** privée ?. 

 * r-ASSOCIATIVE-jmuzerelle_1377265946913: ['u-MENTION-jmuzerelle_1363103955880', 'u-MENTION-jmuzerelle_1377265931073'] 

	 et ils avaient été à l' école dans une des dans quel euh dans **[quel type d' école]** c' était **[une école publique privée]** ?. 

 * s-CHAIN-74: ['u-MENTION-jmuzerelle_1363095053541', 'u-MENTION-jmuzerelle_1377262766754'] 

	 on vous l' avait offert ? ou on à **[quelle occasion]** ?.. oh **[c']** était pour un Noël ou le Jour de l' an comme ça. 

 * s-CHAIN-75: ['u-MENTION-jmuzerelle_1363103955880', 'u-MENTION-jmuzerelle_1377266041386', 'u-MENTION-jmuzerelle_1377266162026'] 

	 et ils avaient été à l' école dans une des dans quel euh dans **[quel type d' école]** c' était une école publique privée ?. **[c']** était une petite école de campagne sûrement. oui. [...] une école publique oui. oh oui et vous **[c']** était une école publique oui oui oui. 

### File: 020_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1360853235719: ['u-MENTION-jmuzerelle_1360835340626', 'u-MENTION-jmuzerelle_1360835433070'] 

	 dans **[quelles matières]** est -ce que vous auriez aimé euh que vos enfants soient forts à l' école quelles sont les matières euh. ben je trouve les **[les mathématiques et les langues]** maths et les langues moi pour moi. 

 * r-ASSOCIATIVE-jmuzerelle_1360853984553: ['u-MENTION-jmuzerelle_1360836351016', 'u-MENTION-jmuzerelle_1360836393292'] 

	 et jusqu' à **[quel âge]** est -ce que vous pensez qu' il faudrait que les enfants continuent leurs études je veux dire l' âge euh minimum ?. alors je crois que maintenant c' est **[seize ans]** hein ? seize ans je crois que c' est c' est pas mal seize ans et parce que. 

 * s-CHAIN-32: ['u-MENTION-jmuzerelle_1360835340626', 'u-MENTION-jmuzerelle_1360835420526'] 

	 dans **[quelles matières]** est -ce que vous auriez aimé euh que vos enfants soient forts à l' école quelles sont **[les matières]** euh. 

 * s-CHAIN-49: ['u-MENTION-jmuzerelle_1360836351016', 'u-MENTION-jmuzerelle_1360836377954', 'u-MENTION-jmuzerelle_1360836649608', 'u-MENTION-jmuzerelle_1360836657141'] 

	 et jusqu' à **[quel âge]** est -ce que vous pensez qu' il faudrait que les enfants continuent leurs études je veux dire **[l' âge euh minimum]** ?. alors je crois que maintenant **[c']** est seize ans hein ? seize ans je crois que c' est c' est pas mal seize ans et parce que. **[c']** est seize ans oui voilà seize ans. 

### File: 030_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1367479197772: ['u-MENTION-jmuzerelle_1367333855146', 'u-MENTION-jmuzerelle_1367333869016'] 

	 hm hm elles ont **[quel âge]** ?. hm **[deux trois ans]** et quatre ans. 

 * r-ASSOCIATIVE-jmuzerelle_1367479204246: ['u-MENTION-jmuzerelle_1367333855146', 'u-MENTION-jmuzerelle_1367333878516'] 

	 hm hm elles ont **[quel âge]** ?. hm deux trois ans et **[quatre ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1367480363093: ['u-MENTION-jmuzerelle_1367336232114', 'u-MENTION-jmuzerelle_1367336607955'] 

	 jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. dans un cycle scolaire ?. [...] les insérant dans un vrai contexte enfin. hm hm est -ce que vous croyez que l' âge par exemple euh enfin oui euh **[l' âge de seize ans]** est -ce que c' est est -ce que ça vous ça vous parait parait un peu un peu tard oui pour commencer à à s' orienter est -ce que c' est ? assez. 

 * r-ASSOCIATIVE-jmuzerelle_1367482471237: ['u-MENTION-jmuzerelle_1367418172340', 'u-MENTION-jmuzerelle_1367418277740'] 

	 hm hm oui oui et sur **[d' autres plans]** à part le plan culturel est -ce que vous croyez qu' on fait assez pour les habitants ?. sur **[quel plan d' équipement]** euh. 

 * r-ASSOCIATIVE-jmuzerelle_1367484447372: ['u-MENTION-jmuzerelle_1367422156582', 'u-MENTION-jmuzerelle_1367422171702'] 

	 un étranger veut venir en **[France]** pour apprendre le français dans **[quelle région]** est -ce que vous est -ce qu' il doit aller d' après vous ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367484460512: ['u-MENTION-jmuzerelle_1367422171702', 'u-MENTION-jmuzerelle_1367422186462'] 

	 un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous est -ce qu' il doit aller d' après vous ?. je vais vous dire **[la région du Val-de-Loire]** parce qu' on soit disant l' accent est le meilleur enfin l' accent est le le français est le mieux parlé oui non je pense que à Paris quand même une ville assez idéale pour euh un étranger. 

 * r-ASSOCIATIVE-jmuzerelle_1367484642702: ['u-MENTION-jmuzerelle_1367333395885', 'u-MENTION-jmuzerelle_1367422171702'] 

	 qu' est -ce que je fais je vais souvent à **[Paris]** parce que j' ai gardé des amis euh à Paris. hm hm. [...] alors on va passer à un. un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous est -ce qu' il doit aller d' après vous ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367485766005: ['u-MENTION-jmuzerelle_1367422861156', 'u-MENTION-jmuzerelle_1367423762019'] 

	 hm et pour bien apprendre le français **[quels gens]** devraient- ils fréquenter ?. quels gens ?. [...] oui oui et pour bien apprendre le français donc quel gens devrait- il fréquenter ?. qu' est -ce que ça veut dire pour bien apprendre le français ? si c' est pour bien connaitre la langue elle-même je pense qu' il peut rencontrer **[n' importe qui]** mais si c' est pour avoir une connaissance une bonne connaissance linguistique enfin un bon langage évidemment il vaut mieux qu' il connaisse des gens euh soit des étudiants soit des milieux sociaux assez culturels assez élevés peut-être. 

 * r-ASSOCIATIVE-jmuzerelle_1367485843485: ['u-MENTION-jmuzerelle_1367422861156', 'u-MENTION-jmuzerelle_1367423837569'] 

	 hm et pour bien apprendre le français **[quels gens]** devraient- ils fréquenter ?. quels gens ?. [...] oui oui et pour bien apprendre le français donc quel gens devrait- il fréquenter ?. qu' est -ce que ça veut dire pour bien apprendre le français ? si c' est pour bien connaitre la langue elle-même je pense qu' il peut rencontrer n' importe qui mais si c' est pour avoir une connaissance une bonne connaissance linguistique enfin un bon langage évidemment il vaut mieux qu' il connaisse des gens euh soit **[des étudiants]** soit des milieux sociaux assez culturels assez élevés peut-être. 

 * r-ASSOCIATIVE-jmuzerelle_1367485899965: ['u-MENTION-jmuzerelle_1367403257937', 'u-MENTION-jmuzerelle_1367422861156'] 

	 moi je vois as- assez assez peu d' adolescents hein ? mais je pense qu' y a cette différence là que les enfants de de lycée viennent de de **[milieux plus aisés peut-être plus cultivés]** alors que ceux de CEG de CES viennent de milieux plus simples. hm hm. [...] peut-être oui. hm et pour bien apprendre le français **[quels gens]** devraient- ils fréquenter ?. 

 * s-CHAIN-31: ['u-MENTION-jmuzerelle_1367336232114', 'u-MENTION-jmuzerelle_1367336600285'] 

	 jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. dans un cycle scolaire ?. [...] les insérant dans un vrai contexte enfin. hm hm est -ce que vous croyez que **[l' âge]** par exemple euh enfin oui euh l' âge de seize ans est -ce que c' est est -ce que ça vous ça vous parait parait un peu un peu tard oui pour commencer à à s' orienter est -ce que c' est ? assez. 

 * s-CHAIN-36: ['u-MENTION-jmuzerelle_1367336954906', 'u-MENTION-jmuzerelle_1367336992806', 'u-MENTION-jmuzerelle_1367337230197'] 

	 enfin **[quelle différence]** y a -t -il entre les lycées les CEG les CES ? est -ce qu' il y a **[une différence]** ?. enfin je crois qu' au au départ les les lycées c' est les enfants mettaient les parents mettaient leurs enfants au lycée lorsqu' ils avaient l' intention de leur faire poursuivre leurs études tandis que les CEG c' était plutôt des histoires de quartier et mais enfin à vrai dire je sais pas tellement **[la différence]** hein ?. 

 * s-CHAIN-87: ['u-MENTION-jmuzerelle_1367422171702', 'u-MENTION-jmuzerelle_1367422833356', 'u-MENTION-jmuzerelle_1367423027307', 'u-MENTION-jmuzerelle_1367423044427', 'u-MENTION-jmuzerelle_1367423096757', 'u-MENTION-jmuzerelle_1367423191947'] 

	 un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous est -ce qu' il doit aller d' après vous ?. je vais vous dire la région du Val-de-Loire parce qu' on soit disant l' accent est le meilleur enfin l' accent est le le français est le mieux parlé oui non je pense que à Paris quand même une ville assez idéale pour euh un étranger. [...] oui. pourquoi ? non je trouve que tout est intéressant mais il faudrait mieux ne pas se limiter à **[une région de France]**. hm hm. [...] interview to be continued on the twenty-fourth of june the first part of the interview was on the twentieth of june. la dernière fois à enfin **[les endroits de France]** **[où]** devrait aller un étranger. oui. [...] oui. alors euh nous avions dit je crois vous aviez dit Paris comme **[ville]** euh. comme priorité oui. oui et j' avais dit enfin je vous avais demandé s' il y avait des endroits à éviter euh je ne sais pas si vous n' en voyez pas si. à éviter non pour moi non mais je pense qu' il vaut mieux ne pas se cantonner à **[un seul endroit de la France]** par exemple il vaut mieux pour avoir une meilleure idée puis si c' est pour l' accent ça dépend enfin si c' est pour l' accent il vaut mieux aussi euh peut-être être dans le centre de la France enfin. 

 * s-CHAIN-88: ['u-MENTION-jmuzerelle_1367422861156', 'u-MENTION-jmuzerelle_1367422956837', 'u-MENTION-jmuzerelle_1367423707749', 'u-MENTION-jmuzerelle_1367423821689'] 

	 hm et pour bien apprendre le français **[quels gens]** devraient- ils fréquenter ?. **[quels gens]** ?. hm. [...] possible. oui oui et pour bien apprendre le français donc **[quel gens]** devrait- il fréquenter ?. qu' est -ce que ça veut dire pour bien apprendre le français ? si c' est pour bien connaitre la langue elle-même je pense qu' il peut rencontrer n' importe qui mais si c' est pour avoir une connaissance une bonne connaissance linguistique enfin un bon langage évidemment il vaut mieux qu' il connaisse **[des gens]** euh soit des étudiants soit des milieux sociaux assez culturels assez élevés peut-être. 

### File: 107_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1359450463851: ['u-MENTION-jmuzerelle_1359381023796', 'u-MENTION-jmuzerelle_1359381036588'] 

	 **[quel âge]** ils ont ?. euh l' aîné a **[onze ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1359450800330: ['u-MENTION-jmuzerelle_1359381023796', 'u-MENTION-jmuzerelle_1359381061385'] 

	 **[quel âge]** ils ont ?. euh l' aîné a onze ans. ah ben alors ils sont. j' ai une fille de **[six ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1359450887222: ['u-MENTION-jmuzerelle_1359381023796', 'u-MENTION-jmuzerelle_1359381114315'] 

	 **[quel âge]** ils ont ?. euh l' aîné a onze ans. [...] oui. une petite de six ans et un petit garçon de quatre **[ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1359453413153: ['u-MENTION-jmuzerelle_1359382591355', 'u-MENTION-jmuzerelle_1359382677970'] 

	 je crois que il apprendra l' anglais euh **[le français]** l' anglais ça sera déjà bien lui mettre encore du latin par dessus je vois pas ce que ça donnerait parce que. hm. [...] ah ça je peux pas vous dire euh ça sert pas à grand chose dans la vie pa- euh moi je trouve euh à mon point de vue moi ça me sert à rien c' est c' est pas j' ai jamais appris le latin mais enfin personnellement peut-être que. et dans **[quelle matière]** est -ce que vous aimeriez que vos enfants soient forts en classe ?. 

 * r-ASSOCIATIVE-jmuzerelle_1359453470199: ['u-MENTION-jmuzerelle_1359382677970', 'u-MENTION-jmuzerelle_1359383611373'] 

	 et dans **[quelle matière]** est -ce que vous aimeriez que vos enfants soient forts en classe ?. oh le français. le français d- surtout le français. le français oui parce que on a toujours besoin de français **[de calcul]** enfin c' est le principal je crois. 

 * r-ASSOCIATIVE-jmuzerelle_1359453498108: ['u-MENTION-jmuzerelle_1359382677970', 'u-MENTION-jmuzerelle_1359383619641'] 

	 et dans **[quelle matière]** est -ce que vous aimeriez que vos enfants soient forts en classe ?. oh le français. le français d- surtout le français. le français oui parce que on a toujours besoin de français de calcul enfin c' est **[le principal]** je crois. 

 * r-ASSOCIATIVE-jmuzerelle_1359455137349: ['u-MENTION-jmuzerelle_1359384207645', 'u-MENTION-jmuzerelle_1359384630327'] 

	 hm hm et à votre avis jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. euh continuer avant d' aller travailler enfin euh ?. oui. comme ils faisaient autrefois avec le certificat d' études ? ben je trouve que **[quatorze ans]** c' était bien. 

 * s-CHAIN-55: ['u-MENTION-jmuzerelle_1359384207645', 'u-MENTION-jmuzerelle_1359384794697'] 

	 hm hm et à votre avis jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. euh continuer avant d' aller travailler enfin euh ?. [...] et à quatorze ans ils ont quand même la force de travailler c' est c' est quand même euh. oui hm hm donc euh à votre avis euh ça serait plutôt un bien de prendre comme **[âge]** quatorze ans ? comme âge de fin d' études vous trouvez que c' est un peu trop long. 

### File: 014_C-5.tei

 * r-ASSOCIATIVE-jmuzerelle_1351092119331: ['u-MENTION-jmuzerelle_1351071321505', 'u-MENTION-jmuzerelle_1351071342191'] 

	 vous êtes arrivé à Orléans vers **[quelle époque]** euh ?. oh **[soixante]** soixante. 

 * r-ASSOCIATIVE-jmuzerelle_1351092719277: ['u-MENTION-jmuzerelle_1351072007735', 'u-MENTION-jmuzerelle_1351072032243'] 

	 oui elle a **[quel âge]** s' il vous plaît ?. **[soixante et un]**. 

 * r-ASSOCIATIVE-jmuzerelle_1351092883155: ['u-MENTION-jmuzerelle_1351072331965', 'u-MENTION-jmuzerelle_1351072378328'] 

	 et vous jusqu' à **[quel âge]** est -ce que vous avez fait des études euh ?. oh jusqu' à **[onze ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1351092972777: ['u-MENTION-jmuzerelle_1351068944642', 'u-MENTION-jmuzerelle_1351072593140'] 

	 et votre instituteur à **[l' école]** est -ce qu' il vous faisait attention à la façon dont vous parliez ?. oh si ça ça ouais ça hein. [...] d' accord oui oui oui oui hm hm. et vous étiez dans **[quelle école primaire]** euh ? privée ? publique ?. 

 * r-ASSOCIATIVE-jmuzerelle_1351092983058: ['u-MENTION-jmuzerelle_1351072593140', 'u-MENTION-jmuzerelle_1351072620175'] 

	 et vous étiez dans **[quelle école primaire]** euh ? privée ? publique ?. publique. publique oui dans une **[une école en Algérie]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1351093092211: ['u-MENTION-jmuzerelle_1351072700515', 'u-MENTION-jmuzerelle_1351072720218'] 

	 école communale hein ? d' accord oui oui oui d' accord en Algérie alors à **[quel endroit]** où ça ?. oh on était bon la l' école c' était à **[Oran]**. 

 * r-ASSOCIATIVE-jmuzerelle_1351093120619: ['u-MENTION-jmuzerelle_1351071156629', 'u-MENTION-jmuzerelle_1351072700515'] 

	 euh en **[Algérie]**. Algérie oui. [...] non non c' était l' école communale. école communale hein ? d' accord oui oui oui d' accord en Algérie alors à **[quel endroit]** où ça ?. 

### File: 008_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1366033710086: ['u-MENTION-jmuzerelle_1366026677113', 'u-MENTION-jmuzerelle_1366026689133'] 

	 parmi vos connaissances quelle est **[la personne]** qui parle le mieux le français ? euh c'est-à-dire **[quelle profession]** ? par exemple. 

 * r-ASSOCIATIVE-jmuzerelle_1366034407877: ['u-MENTION-jmuzerelle_1366027742125', 'u-MENTION-jmuzerelle_1366027778725'] 

	 et dans **[quelle matière]** éti- étiez- vous le plus fort à à à l' é- à l' école ?. en **[mathématiques]** en dessin. 

 * r-ASSOCIATIVE-jmuzerelle_1366034413507: ['u-MENTION-jmuzerelle_1366027742125', 'u-MENTION-jmuzerelle_1366027786396'] 

	 et dans **[quelle matière]** éti- étiez- vous le plus fort à à à l' é- à l' école ?. en mathématiques en **[dessin]**. 

 * r-ASSOCIATIVE-jmuzerelle_1366034420117: ['u-MENTION-jmuzerelle_1366027742125', 'u-MENTION-jmuzerelle_1366027796326'] 

	 et dans **[quelle matière]** éti- étiez- vous le plus fort à à à l' é- à l' école ?. en mathématiques en dessin. hm. et en **[allemand]** parce que dans l' Est on apprend surtout l' allemand là-bas comme deuxième langue. 

 * r-ASSOCIATIVE-jmuzerelle_1366034504987: ['u-MENTION-jmuzerelle_1366028558725', 'u-MENTION-jmuzerelle_1366028574675'] 

	 hm hm et à la suite de quelles circonstances avez- vous possédé pour la première fois un stylo à encre ? à **[quel âge]** ?. à l' école euh primaire supérieure alors j' avais **[quinze ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1366034511187: ['u-MENTION-jmuzerelle_1366028513895', 'u-MENTION-jmuzerelle_1366028567645'] 

	 hm hm et à **[la suite de quelles circonstances]** avez- vous possédé pour la première fois un stylo à encre ? à quel âge ?. à **[l' école euh primaire supérieure]** alors j' avais quinze ans. 

 * r-ASSOCIATIVE-jmuzerelle_1366036591184: ['u-MENTION-jmuzerelle_1366031609241', 'u-MENTION-jmuzerelle_1366031651351'] 

	 hm hm et **[quel type de papier]** utilisez- vous ?. euh **[papier ministre]** toujours. 

 * r-ASSOCIATIVE-jmuzerelle_1366037022764: ['u-MENTION-jmuzerelle_1366031609241', 'u-MENTION-jmuzerelle_1366032364343'] 

	 hm hm et **[quel type de papier]** utilisez- vous ?. euh papier ministre toujours. [...] ah oui. alors euh quand j' ai une petite lettre je prends le petit bloc quand j' ai une grande lettre je prends celui-là toujours le même mais on a pas de **[papier fantaisie]**. 

 * r-ASSOCIATIVE-jmuzerelle_1366037380566: ['u-MENTION-jmuzerelle_1366033217524', 'u-MENTION-jmuzerelle_1366033305965'] 

	 et pour **[quel genre de choses]** surtout ?. oh euh la tendance **[aux mots vulgaires]** par exemple. 

### File: 019_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1365599049648: ['u-MENTION-jmuzerelle_1365578640686', 'u-MENTION-jmuzerelle_1365578667565'] 

	 madame on vous savez on a beaucoup parlé ailleurs également qu' en France des événements des des fameux fameux événements **[du mai dernier]** n' est -ce pas et moi moi je n' étais pas en France à cette époque j' étais déjà rentré j' allais vous demander est -ce que vous pourriez m' expliquer un peu ce qui s' est passé ?. à **[quel moment]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365601492109: ['u-MENTION-jmuzerelle_1365598083929', 'u-MENTION-jmuzerelle_1365598124738'] 

	 ah bon ? et alors **[quel genre de choses]** y cherchez- vous le plus souvent ? c' est **[l' orthographe]** le sens du mot s- ou quoi ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365601500455: ['u-MENTION-jmuzerelle_1365598083929', 'u-MENTION-jmuzerelle_1365598132601'] 

	 ah bon ? et alors **[quel genre de choses]** y cherchez- vous le plus souvent ? c' est l' orthographe **[le sens du mot]** s- ou quoi ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365601508317: ['u-MENTION-jmuzerelle_1365598083929', 'u-MENTION-jmuzerelle_1365598171320'] 

	 ah bon ? et alors **[quel genre de choses]** y cherchez- vous le plus souvent ? c' est l' orthographe le sens du mot s- ou quoi ?. oui le sens du mot ou bien des **[des indications]** sur les les pays les des choses comme ça. 

 * s-CHAIN-50: ['u-MENTION-jmuzerelle_1365597836590', 'u-MENTION-jmuzerelle_1365597859132'] 

	 oui oui oui et depuis depuis quand est -ce que vous l' avez eu ? à **[quelle occasion]** est -ce que vous vous souvenez ?. oh ma foi non je m' **[en]** souviens pas oh non il date de vingt-trois ou vingt-quatre je crois. 

 * s-CHAIN-52: ['u-MENTION-jmuzerelle_1365598083929', 'u-MENTION-jmuzerelle_1365598117126'] 

	 ah bon ? et alors **[quel genre de choses]** y cherchez- vous le plus souvent ? **[c']** est l' orthographe le sens du mot s- ou quoi ?. 

### File: 026_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1357580796398: ['u-MENTION-jmuzerelle_1357569591153', 'u-MENTION-jmuzerelle_1357569874938'] 

	 euh un étranger veut venir en France madame pour apprendre le français euh dans **[quelle région de la France]** est -ce que ?. vous pouvez arrêter non un petit peu ?. [...] euh dans quelle région est -ce qu' il doit aller d' après vous ?. en France on prétend que c' est à Tours surtout dans **[l' Indre-et-Loire]** et peut -être l' Orléanais. 

 * r-ASSOCIATIVE-jmuzerelle_1357580808290: ['u-MENTION-jmuzerelle_1357569591153', 'u-MENTION-jmuzerelle_1357569883048'] 

	 euh un étranger veut venir en France madame pour apprendre le français euh dans **[quelle région de la France]** est -ce que ?. vous pouvez arrêter non un petit peu ?. [...] euh dans quelle région est -ce qu' il doit aller d' après vous ?. en France on prétend que c' est à Tours surtout dans l' Indre-et-Loire et peut -être **[l' Orléanais]**. 

 * r-ASSOCIATIVE-jmuzerelle_1357580911561: ['u-MENTION-jmuzerelle_1357569591153', 'u-MENTION-jmuzerelle_1357569981582'] 

	 euh un étranger veut venir en France madame pour apprendre le français euh dans **[quelle région de la France]** est -ce que ?. vous pouvez arrêter non un petit peu ?. [...] oui. ça c' est certain hein ? hein ? il paraît que c' est c' est dans **[ces régions du centre]** là. 

 * r-ASSOCIATIVE-jmuzerelle_1357581133882: ['u-MENTION-jmuzerelle_1357570325053', 'u-MENTION-jmuzerelle_1357570442529'] 

	 hm hm et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ?. quels ?. quels gens devrait- il fréquenter ?. peut-être **[du personnel]** enfin dans dans dans les membres de l' enseignement ou je pense. 

 * s-CHAIN-42: ['u-MENTION-jmuzerelle_1357569591153', 'u-MENTION-jmuzerelle_1357569672749', 'u-MENTION-jmuzerelle_1357569845816', 'u-MENTION-jmuzerelle_1357570581241', 'u-MENTION-jmuzerelle_1357570813904'] 

	 euh un étranger veut venir en France madame pour apprendre le français euh dans **[quelle région de la France]** est -ce que ?. vous pouvez arrêter non un petit peu ?. oui oui pardon. non parce que si vous avez dans **[quelle région]** oui vous reposez votre question. un étranger qui veut venir en France pour apprendre le français. hm. euh dans **[quelle région]** est -ce qu' il doit aller d' après vous ?. en France on prétend que c' est à Tours surtout dans l' Indre-et-Loire et peut -être l' Orléanais. [...] oui oui. dans **[un endroit]** **[où]** y a susceptible d' entendre parler correctement le français. 

 * s-CHAIN-48: ['u-MENTION-jmuzerelle_1357570325053', 'u-MENTION-jmuzerelle_1357570337322'] 

	 hm hm et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ?. quels ?. **[quels gens]** devrait- il fréquenter ?. 

### File: 007_C-2.tei

 * r-ASSOCIATIVE-gpascault_1359620265763: ['u-MENTION-gpascault_1359461738197', 'u-MENTION-gpascault_1359620241750'] 

	 un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce qu' il doit aller d' après vous ?. disons dans **[notre région]**. 

 * r-ASSOCIATIVE-gpascault_1359623008667: ['u-MENTION-gpascault_1359622419911', 'u-MENTION-gpascault_1359622891378'] 

	 et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ?. on peut dire qu' il y a toutes sortes de Français. hm hm. des gens euh **[des instituteurs]** je crois. 

 * s-CHAIN-54: ['u-MENTION-gpascault_1359622419911', 'u-MENTION-gpascault_1359622634511', 'u-MENTION-gpascault_1359622678642', 'u-MENTION-gpascault_1359641292690', 'u-MENTION-gpascault_1359641572935'] 

	 et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ?. on peut dire qu' il y a toutes sortes **[de Français]**. hm hm. **[des gens]** euh des instituteurs je crois. hm hm. [...] comme partout partout bien. voyez **[le Français]** est trop riche en fait euh des voitures **[tout le monde]** a sa voiture. 

 * s-CHAIN-99: ['u-MENTION-gpascault_1359644325422', 'u-MENTION-jmuzerelle_1372411721073'] 

	 très peu de temps libre euh je leur demande déjà **[quel jour]** il pourrait être libre. hm hm. si ça **[ça]** pouvait correspondre avec euh les horaires de mon mari et les miens je leur dis que j' aurais plaisir à les recevoir euh un peu pas trop longtemps. 

### File: 026_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1357307264383: ['u-MENTION-jmuzerelle_1357209839204', 'u-MENTION-jmuzerelle_1357209878751'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que l' enfant euh continue ses études ?. en France maintenant c' est obligatoirement **[seize ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1357307719535: ['u-MENTION-jmuzerelle_1357209839204', 'u-MENTION-jmuzerelle_1357210383645'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que l' enfant euh continue ses études ?. en France maintenant c' est obligatoirement seize ans. [...] c' est seize ans. c' était **[quatorze ans]** et c' est passé seize ans. 

 * r-ASSOCIATIVE-jmuzerelle_1357309976915: ['u-MENTION-jmuzerelle_1357222224527', 'u-MENTION-jmuzerelle_1357222246867'] 

	 euh mais dans **[quel sens]** mais **[au point de vue distractions]** non à quel point de vue vous voulez dire ?. 

 * r-ASSOCIATIVE-jmuzerelle_1357310038655: ['u-MENTION-jmuzerelle_1357222224527', 'u-MENTION-jmuzerelle_1357222330233'] 

	 euh mais dans **[quel sens]** mais au point de vue distractions non à quel point de vue vous voulez dire ?. enfin dans la ville enfin l' ensemble de la ville en général enfin est -ce que d- enfin dans à peu près tous les branches est -ce que pour par exemple euh **[les services de voirie]** ou la construction ou les ou les. 

 * r-ASSOCIATIVE-jmuzerelle_1357310046555: ['u-MENTION-jmuzerelle_1357222224527', 'u-MENTION-jmuzerelle_1357222346145'] 

	 euh mais dans **[quel sens]** mais au point de vue distractions non à quel point de vue vous voulez dire ?. enfin dans la ville enfin l' ensemble de la ville en général enfin est -ce que d- enfin dans à peu près tous les branches est -ce que pour par exemple euh les services de voirie ou **[la construction]** ou les ou les. 

 * r-ASSOCIATIVE-jmuzerelle_1357317298962: ['u-MENTION-jmuzerelle_1376408088892', 'u-MENTION-jmuzerelle_1357230546599'] 

	 là tu avais là un autre service tout à fait différent mais sinon voilà ce que c' est pour tout monde voyez c' est c' est depuis les grèves ça voyez et avec **[le même salaire]** et même un salaire qui a été un peu augmenté y avait **[des salaires quand même excessivement bas]**. 

 * s-CHAIN-16: ['u-MENTION-jmuzerelle_1357209839204', 'u-MENTION-jmuzerelle_1376406159681', 'u-MENTION-jmuzerelle_1357210528788', 'u-MENTION-jmuzerelle_1357210515200', 'u-MENTION-jmuzerelle_1357210533624', 'u-MENTION-jmuzerelle_1357210540785', 'u-MENTION-jmuzerelle_1357210549848', 'u-MENTION-jmuzerelle_1357210555059', 'u-MENTION-jmuzerelle_1357210563405'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que l' enfant euh continue ses études ?. en France maintenant c' est obligatoirement seize ans. [...] mais en France de toute façon c' est obligatoire maintenant c' est seize ans. oui et vous enfin je crois que y a un projet en France ici pour augmenter enfin pour euh **[l' âge de la fin de la sco- scolarité]** oui mais ils n' ont pas un projet pour euh **[le]** mettre à s- à dix-huit ans ?. **[c']** est seize ans. **[c']** était quatorze ans et **[c']** est passé seize ans. **[c']** est **[c']** était quatorze ans ici. **[c']** était quatorze ans. 

 * s-CHAIN-50: ['u-MENTION-jmuzerelle_1357222224527', 'u-MENTION-jmuzerelle_1357222264089', 'u-MENTION-jmuzerelle_1357222314087'] 

	 euh mais dans **[quel sens]** mais au point de vue distractions non à **[quel point de vue]** vous voulez dire ?. enfin dans la ville enfin l' ensemble de la ville en général enfin est -ce que d- enfin dans à peu près **[tous les branches]** est -ce que pour par exemple euh les services de voirie ou la construction ou les ou les. 

 * s-CHAIN-132: ['u-MENTION-jmuzerelle_1357230546599', 'u-MENTION-jmuzerelle_1357230576169'] 

	 là tu avais là un autre service tout à fait différent mais sinon voilà ce que c' est pour tout monde voyez c' est c' est depuis les grèves ça voyez et avec le même salaire et même un salaire qui a été un peu augmenté y avait **[des salaires quand même excessivement bas]**.. [...] hm hm. **[des salaires très très bas]** hein ?. 

### File: 005_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1358845993986: ['u-MENTION-jmuzerelle_1358782771983', 'u-MENTION-jmuzerelle_1358782796702'] 

	 dans **[quelles matières]** est -ce que vous aimeriez que vos enfants soient forts surtout ?. ben mes garçons j' aimerais bien qu' ils soient forts en **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1358846020350: ['u-MENTION-jmuzerelle_1358782771983', 'u-MENTION-jmuzerelle_1358782818722'] 

	 dans **[quelles matières]** est -ce que vous aimeriez que vos enfants soient forts surtout ?. ben mes garçons j' aimerais bien qu' ils soient forts en maths. oui. et puis les filles euh ma foi en **[langues]** peut-être j' aimerais assez il me semble qu' une fille avec euh se débrouillant en langues euh. 

 * r-ASSOCIATIVE-jmuzerelle_1358847787412: ['u-MENTION-jmuzerelle_1358784874914', 'u-MENTION-jmuzerelle_1358785249549'] 

	 jusqu' à **[quel âge]** est -ce que vous pensez que les enfants devraient pousser leurs études ?. oh bien tout tout dépend des enfants. [...] oui. si on parle d' études enfin là actuellement la scolarité est jusqu' à **[seize ans]**. 

 * s-CHAIN-98: ['u-MENTION-jmuzerelle_1358780029339', 'u-MENTION-jmuzerelle_1358780088801'] 

	 ben je pense qu' on devrait leur apprendre euh enfin évidemment les enfants oui à **[quel âge]** vous pensez ? euh la lecture et tout à ce point de vue là vous voulez dire non ?. euh **[n' importe quel âge]**. 

 * s-CHAIN-125: ['u-MENTION-jmuzerelle_1358784261034', 'u-MENTION-jmuzerelle_1358784288772'] 

	 formation de l' esprit dans **[quel sens]** ?. formation de l' esprit euh dans **[le sens]** euh d' abord au point de vue français et ça ça aide beaucoup parce que c' est quand même le français vient du latin donc au point de vue analyse au point de vue construction de la phrase je pense que c' était très bon d' avoir fait du latin et puis au point de vue culture générale voyez pour des enfants qui qui aiment ça enfin je trouve que faut pas pousser tout le monde non plus peut-être à vouloir le faire si on n' a pas si c' est une chose de plus qui est surajoutée dans la dans la classe. 

### File: 024_C-3.tei

 * r-ASSOCIATIVE-agoudjo_1340285963675: ['u-MENTION-agoudjo_1337678643062', 'u-MENTION-jmuzerelle_1338645583871'] 

	 euh un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est il est -ce qu' il doit aller ? d' après vous dans quelle ville ou coin ?. un étranger qui voudrait apprendre la langue française ?. [...] hm non plus je vois pas hein. non enfin il n' y a pas de régions où vous croyez qu' il apprendrait un enfin un meilleur français que que dans **[d' autres]**. 

 * s-CHAIN-1: ['u-MENTION-agoudjo_1337604434006', 'u-MENTION-agoudjo_1337604509740'] 

	 jusqu' à **[quel âge]** vous croyez euh que les enfants devraient continuer leurs leurs études ?. ah alors là pour continuer les études **[l' âge]** importe peu mais c' est un choix à faire avant. 

 * s-CHAIN-76: ['u-MENTION-agoudjo_1337676539162', 'u-MENTION-agoudjo_1337676601471'] 

	 bien il s' est passé un un malaise qui a pris qui a commencé à prendre euh par les intellectuels euh c' est eux qui ont commencé à à faire euh du chambard quoi puis qui se sont mis en grève puis ça s' est enchaîné dans les ouvriers je sais pas dans **[quel sens]** j' **[en]** sais rien. 

 * s-CHAIN-84: ['u-MENTION-agoudjo_1337678643062', 'u-MENTION-agoudjo_1337678758283', 'u-MENTION-agoudjo_1337679076652', 'u-MENTION-agoudjo_1337679246258', 'u-MENTION-jmuzerelle_1376040267216', 'u-MENTION-agoudjo_1337679311338', 'u-MENTION-jmuzerelle_1376040402328'] 

	 euh un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est il est -ce qu' il doit aller ? d' après vous dans quelle ville ou **[coin]** ?. un étranger qui voudrait apprendre la langue française ?. [...] oui. **[quelle région]** ça vous savez. non ?. non je suis incapable de vous répondre. il n' y a pas **[d' endroit]** **[qu']** il devrait éviter ?. hm non plus je vois pas hein. non enfin il n' y a pas **[de régions]** où vous croyez **[qu']** il apprendrait un enfin un meilleur français que que dans d' autres. 

### File: 096_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1363185911531: ['u-MENTION-jmuzerelle_1363163378717', 'u-MENTION-jmuzerelle_1363163395113'] 

	 et vous avez été jusqu' à **[quel âge]** à l' école ?. ah j' ai commencé à travailler j' avais **[douze ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1363186439686: ['u-MENTION-jmuzerelle_1363163921021', 'u-MENTION-jmuzerelle_1363164575968'] 

	 et qu' est -ce que vous préférez comme émission à Europe ? **[quel genre de choses]** vous préférez ?. euh j' aime bien les soirs à à sept heures là y a toujours des ou alors y a aussi y a des docteurs qui parlent y a ouais y a y a beaucoup de choses je trouve à Europe moi je trouve beaucoup de choses. [...] y a le docteur Europe qui parle ou y a tout ça enfin y a plein de choses qui très intéressantes non je je trouve que c' est très très intéressant les émissions sont très bien. mais vous préférez euh plutôt **[les débats politiques]** ou bien la musi- les chansons ou bien ? qu' est -ce que vous préférez ?. 

 * r-ASSOCIATIVE-jmuzerelle_1363186452696: ['u-MENTION-jmuzerelle_1363163921021', 'u-MENTION-jmuzerelle_1363164582848'] 

	 et qu' est -ce que vous préférez comme émission à Europe ? **[quel genre de choses]** vous préférez ?. euh j' aime bien les soirs à à sept heures là y a toujours des ou alors y a aussi y a des docteurs qui parlent y a ouais y a y a beaucoup de choses je trouve à Europe moi je trouve beaucoup de choses. [...] y a le docteur Europe qui parle ou y a tout ça enfin y a plein de choses qui très intéressantes non je je trouve que c' est très très intéressant les émissions sont très bien. mais vous préférez euh plutôt les débats politiques ou bien la musi- **[les chansons]** ou bien ? qu' est -ce que vous préférez ?. 

### File: 131_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1360603145525: ['u-MENTION-jmuzerelle_1360589961804', 'u-MENTION-jmuzerelle_1360589953411'] 

	 après le certificat d' études c' est une récompense eh ben ma foi j' avais **[douze ans]**. **[quelle année]** à peu près ?. 

 * r-ASSOCIATIVE-jmuzerelle_1360603178426: ['u-MENTION-jmuzerelle_1360589953411', 'u-MENTION-jmuzerelle_1360590889116'] 

	 **[quelle année]** à peu près ?. vous aviez douze ans ?. je l' ai reçu avant quand même j' ai reçu oui il m' a servi plus longtemps déjà j' avais **[dix ans]** peut-être quand je l' ai eu oui prix oui c' était un prix offert par la ville d' Orléans. 

 * r-ASSOCIATIVE-jmuzerelle_1360604745433: ['u-MENTION-jmuzerelle_1360592277394', 'u-MENTION-jmuzerelle_1360592289702'] 

	 parmi vos connaissances quelle est **[la personne]** qui parle le mieux le français ? **[quelle profession]** ? laquelle ? parmi les gens qui. 

 * r-ASSOCIATIVE-jmuzerelle_1360605796547: ['u-MENTION-jmuzerelle_1360593849518', 'u-MENTION-jmuzerelle_1360593867739'] 

	 et dans **[quelles matières]** étiez- vous la plus forte à l' école ?. en **[maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1360606080062: ['u-MENTION-jmuzerelle_1360594517683', 'u-MENTION-jmuzerelle_1360594524765'] 

	 ah votre filleule elle a **[quel âge]** ?. **[deux ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1360607677193: ['u-MENTION-jmuzerelle_1360597715049', 'u-MENTION-jmuzerelle_1360597734783'] 

	 et **[quel type de papier]** utilisez- vous ? **[papier à carreaux]** papier à lignes papier blanc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1360607684603: ['u-MENTION-jmuzerelle_1360597715049', 'u-MENTION-jmuzerelle_1360597750149'] 

	 et **[quel type de papier]** utilisez- vous ? papier à carreaux **[papier à lignes]** papier blanc ?. 

 * r-ASSOCIATIVE-jmuzerelle_1360607715460: ['u-MENTION-jmuzerelle_1360597715049', 'u-MENTION-jmuzerelle_1360597783580'] 

	 et **[quel type de papier]** utilisez- vous ? papier à carreaux papier à lignes **[papier blanc]** ?. 

### File: 132_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1360162228684: ['u-MENTION-jmuzerelle_1360140380403', 'u-MENTION-jmuzerelle_1360140468434'] 

	 je comprends mieux **[les langues]** euh par exemple euh l' anglais l' allemand euh l' espagnol je crois que ça peut servir euh dans dans le commerce dans euh dans des comment ? des des situations où on va à l' étranger enfin c' est mon avis tout au moins.. [...] non malheureusement. ben dans **[quelle matière]** euh vous auriez aimé si vous en aviez eu euh dans quelle matière vous auriez aimé qu' ils soient forts à l' école ?. 

 * r-ASSOCIATIVE-jmuzerelle_1360162485031: ['u-MENTION-jmuzerelle_1360141255806', 'u-MENTION-jmuzerelle_1360141280485'] 

	 et jusqu' où un enfant devrait aller enfin jusqu' à **[quel âge]** à peu près un enfant devrait aller à l' école d' après vous ? qu' est -ce qui serait souhaitable ?. je trouve que **[seize ans]** c' est déjà un minimum. 

 * r-ASSOCIATIVE-jmuzerelle_1360165860016: ['u-MENTION-jmuzerelle_1360147753964', 'u-MENTION-jmuzerelle_1360147762813'] 

	 de **[quelle année]** je l' ai euh **[cinquante-cinq]** je crois. 

 * s-CHAIN-13: ['u-MENTION-jmuzerelle_1360140468434', 'u-MENTION-jmuzerelle_1360140481647'] 

	 ben dans **[quelle matière]** euh vous auriez aimé si vous en aviez eu euh dans **[quelle matière]** vous auriez aimé qu' ils soient forts à l' école ?. 

 * s-CHAIN-70: ['u-MENTION-jmuzerelle_1360147655950', 'u-MENTION-jmuzerelle_1360147743217', 'u-MENTION-jmuzerelle_1360147771148'] 

	 ah oui oui très bien très beau est -ce que vous vous souvenez euh à à **[quelle occasion]** vous avez eu ce euh vous avez euh ce dictionnaire ?. le gros dictionnaire ?. [...] oui il est de la vers mille neuf cent. vous n' avez pas de petit dictionnaire euh ? de petit dictionnaire vous avez un petit aussi ? ah oui très bien et celui-là à **[quelle occasion]** vous l' avez ?. j' en ai un petit. de quelle année je l' ai euh cinquante-cinq je crois. et vous vous souvenez de **[l' occasion]** euh ?. 

### File: 018_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1366736603746: ['u-MENTION-jmuzerelle_1366290504170', 'u-MENTION-jmuzerelle_1366291186251'] 

	 jusqu' à **[quel âge]** d' après vous les enfants devraient aller à l' école ?. bah ils doivent aller à l' école jusqu' à temps qu' ils aient terminé non pas ce qu' on appelle leurs études mais qu' ils aient terminé de progresser. [...] vous pensez par exemple que quelqu'un qui ne progresse qui ne progresserait pas euh pourrait être retiré de l' école euh vers douze ans treize ans. je pense pas il faut au moins attendre **[seize ans]**. 

 * s-CHAIN-32: ['u-MENTION-jmuzerelle_1366276009994', 'u-MENTION-jmuzerelle_1366276020464'] 

	 vous personnellement enfin pour vos enfants dans **[quelle matière]** vous dans **[quelle matière]** vous aviez vous auriez aimé qu' ils soient forts ? vous avez une euh ?. 

 * s-CHAIN-59: ['u-MENTION-jmuzerelle_1366287178384', 'u-MENTION-jmuzerelle_1366287187565'] 

	 exactement un exemple enfin exemple de **[quel point de vue]** ?. **[point de vue moral]** surtout. 

 * s-CHAIN-90: ['u-MENTION-jmuzerelle_1366290504170', 'u-MENTION-jmuzerelle_1366290600970', 'u-MENTION-jmuzerelle_1366290629590'] 

	 jusqu' à **[quel âge]** d' après vous les enfants devraient aller à l' école ?. bah ils doivent aller à l' école jusqu' à temps qu' ils aient terminé non pas ce qu' on appelle leurs études mais qu' ils aient terminé de progresser. et est -ce que il y aurait **[un âge minimum]** pour tout le monde enfin euh ?. je pense pas je pense pas il y a pas d' **[âge minimum]** c' est une question de progression à partir du moment où on progresse plus c' est pas la peine. 

### File: 008_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1365772317137: ['u-MENTION-jmuzerelle_1365755424538', 'u-MENTION-jmuzerelle_1365755438016'] 

	 un étranger veut venir en **[France]** pour apprendre le français dans **[quelle région]** est -ce qu' il doit aller d' après vous ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365772567736: ['u-MENTION-jmuzerelle_1365755764297', 'u-MENTION-jmuzerelle_1365755847774'] 

	 un patois oui et pour bien apprendre le français **[quelles gens]** devrait- il fréquenter ?. quelles ?. [...] hm hm. mais si vous voulez euh parfaire le si vous voulez parfaire la langue il vaut mieux euh il vaut mieux fréquenter des **[des gens de classe moyenne]** quoi euh vous euh vous apprenez vous apprenez en plus de ce qu' on apprend euh à l' école quoi enfin disons à. 

 * r-ASSOCIATIVE-jmuzerelle_1365772716435: ['u-MENTION-jmuzerelle_1365755438016', 'u-MENTION-jmuzerelle_1365756252345'] 

	 un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce qu' il doit aller d' après vous ?. ben ça dépend quel étranger aussi. [...] hm hm. et est -ce qu' on parle bien à **[Orléans]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365773749236: ['u-MENTION-jmuzerelle_1365760296702', 'u-MENTION-jmuzerelle_1365760185072'] 

	 et vous invitez **[quelqu'un]** à prendre quelque chose à la maison qu' est -ce que vous lui dites pour l' inviter ?. j' ai pas tellement bien compris votre question là. [...] à prendre quelque chose à la maison chez vous qu' est -ce que vous lui dites pour l' inviter de de venir chez vous ?. je lui dis euh ça dépend qui euh si c' est ça dépend **[quelle personne]** évidemment mais venez donc prendre l' apéritif ou venez donc nous dire bonjour ou venez. 

 * r-ASSOCIATIVE-jmuzerelle_1365773922357: ['u-MENTION-jmuzerelle_1365760185072', 'u-MENTION-jmuzerelle_1365760560322'] 

	 je lui dis euh ça dépend qui euh si c' est ça dépend **[quelle personne]** évidemment mais venez donc prendre l' apéritif ou venez donc nous dire bonjour ou venez. c' est ça c' est. [...] alors ça dépend encore de la personne. oui aussi euh évidemment euh si c' est **[un ami]** ben je lui dit ben passe donc à la maison quoi euh. 

 * r-ASSOCIATIVE-jmuzerelle_1365775477571: ['u-MENTION-jmuzerelle_1365770416136', 'u-MENTION-jmuzerelle_1365770441444'] 

	 ah je euh c' était pour euh retrouver un mot avoir **[la définition d' un mot]** que j' avais entendu et que je ne connaissais pas. hm hm et **[quel genre de chose]** y cherchez- vous le plus souvent l' orthographe ou le sens ou quoi ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365775491440: ['u-MENTION-jmuzerelle_1365770441444', 'u-MENTION-jmuzerelle_1365770474825'] 

	 hm hm et **[quel genre de chose]** y cherchez- vous le plus souvent **[l' orthographe]** ou le sens ou quoi ?. 

 * s-CHAIN-17: ['u-MENTION-jmuzerelle_1365755764297', 'u-MENTION-jmuzerelle_1365755791004'] 

	 un patois oui et pour bien apprendre le français **[quelles gens]** devrait- il fréquenter ?. **[quelles ?. 

 * s-CHAIN-47: ['u-MENTION-jmuzerelle_1365760185072', 'u-MENTION-jmuzerelle_1365760531462', 'u-MENTION-jmuzerelle_1365760552212', 'u-MENTION-jmuzerelle_1365760684472'] 

	 je lui dis euh ça dépend qui euh si c' est ça dépend **[quelle personne]** évidemment mais venez donc prendre l' apéritif ou venez donc nous dire bonjour ou venez. c' est ça c' est. [...]. alors ça dépend encore de **[la personne]**. oui aussi euh évidemment euh si **[c']** est un ami ben je lui dit ben passe donc à la maison quoi euh. hm hm hm. si **[c']** est quelqu'un ben venez donc prendre le café euh mais. 

### File: 133_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1364907222719: ['u-MENTION-jmuzerelle_1364894854278', 'u-MENTION-jmuzerelle_1364895168609'] 

	 alors jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ? en moyenne ?. si euh on veut leur donner un bagage euh un bagage un petit bagage qui ne vaut pas grand chose euh faut aller au moins jusqu' au brevet. oui c'est-à-dire ?. euh ça fait **[quinze seize ans]**. 

### File: 013_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1367166807210: ['u-MENTION-jmuzerelle_1367158255993', 'u-MENTION-jmuzerelle_1367158325233'] 

	 quand vous vous servez des dictionnaires en général c' est pour **[quel genre de choses]** ?. ou bien un mot que je ne comprends pas ou. c' est plutôt une question de **[sens de mot]** ou. 

### File: 010_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1355329958146: ['u-MENTION-jmuzerelle_1355301092603', 'u-MENTION-jmuzerelle_1355301112914'] 

	 et dans **[quelle matière]** vous est -ce que vous étiez le la plus forte à l' école ?. **[la composition française]**. 

 * r-ASSOCIATIVE-jmuzerelle_1355393382368: ['u-MENTION-jmuzerelle_1355308763497', 'u-MENTION-jmuzerelle_1373301155269'] 

	 c' est ça mais vous écrivez euh quand vous écrivez ces lettres vous les écrivez avec une une plume à encre ou bien avec le stylo ? toujours toujours ce même stylo euh stylo bille **[quel type de papier]** est -ce que vous utilisez ? **[papier blanc]** euh. 

 * r-ASSOCIATIVE-jmuzerelle_1355393399325: ['u-MENTION-jmuzerelle_1355308763497', 'u-MENTION-jmuzerelle_1355308792965'] 

	 c' est ça mais vous écrivez euh quand vous écrivez ces lettres vous les écrivez avec une une plume à encre ou bien avec le stylo ? toujours toujours ce même stylo euh stylo bille **[quel type de papier]** est -ce que vous utilisez ? papier blanc euh. j' ai pas pas. [...] de plume à encre monsieur. du **[du papier euh à bloc]** euh alors tout dépend soit le un grand format pour euh ou un petit format pour euh. 

 * r-ASSOCIATIVE-jmuzerelle_1355394096540: ['u-MENTION-jmuzerelle_1355308763497', 'u-MENTION-jmuzerelle_1355309591156'] 

	 c' est ça mais vous écrivez euh quand vous écrivez ces lettres vous les écrivez avec une une plume à encre ou bien avec le stylo ? toujours toujours ce même stylo euh stylo bille **[quel type de papier]** est -ce que vous utilisez ? papier blanc euh. j' ai pas pas. [...]. vous n' avez jamais employé **[du papier à carreaux]** par exemple ?. 

### File: 021_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1355751536831: ['u-MENTION-jmuzerelle_1355737832156', 'u-MENTION-jmuzerelle_1355738264830'] 

	 si vous n' étiez pas euh de ce métier -là euh quel est -ce que quel **[quel métier]** auriez vous aimé à faire ?. quand mon mari est mort j' ai choisi ce métier parce que j' aimais les enfants beaucoup. [...] ah oui. j' aime beaucoup et j' aurais peut-être pu faire autre chose je sais pas **[bonne soeur]** peut-être. 

 * s-CHAIN-35: ['u-MENTION-jmuzerelle_1355737832156', 'u-MENTION-jmuzerelle_1355738243978'] 

	 si vous n' étiez pas euh de ce métier -là euh quel est -ce que quel **[quel métier]** auriez vous aimé à faire ?. quand mon mari est mort j' ai choisi ce métier parce que j' aimais les enfants beaucoup. [...] ah oui. j' aime beaucoup et j' aurais peut-être pu faire **[autre chose]** je sais pas bonne soeur peut-être. 

### File: 008_C-1.tei

 * r-ASSOCIATIVE-gpascault_1360326166496: ['u-MENTION-gpascault_1360325992557', 'u-MENTION-gpascault_1360326148446'] 

	 et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. ben maintenant moi à mon avis je pense que euh ce serait pour l' avenir je pense pour les les enfants de maintenant ce serait plutôt **[les mathématiques]** plus qu' ils se dirigent vers la science c' est là quand même le meilleur débouché. 

 * s-CHAIN-87: ['u-MENTION-gpascault_1360325992557', 'u-MENTION-jmuzerelle_1372686618601', 'u-MENTION-jmuzerelle_1372686632091'] 

	 et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. ben maintenant moi à mon avis je pense que euh **[ce]** serait pour l' avenir je pense pour les les enfants de maintenant **[ce]** serait plutôt les mathématiques plus qu' ils se dirigent vers la science c' est là quand même le meilleur débouché. 

### File: 023_C.tei

 * r-ASSOCIATIVE-jmuzerelle_1352468522042: ['u-MENTION-agoudjo_1335436522218', 'u-MENTION-agoudjo_1335436689890'] 

	 oui **[quelles sortes de gens]** habitent par ici euh ?. bah auparavant y avait ça dépend quand on prend la plu- en remontant plus loin c' était des **[des vignerons]**. 

 * r-ASSOCIATIVE-jmuzerelle_1352468543960: ['u-MENTION-agoudjo_1335436522218', 'u-MENTION-agoudjo_1335517917796'] 

	 oui **[quelles sortes de gens]** habitent par ici euh ?. bah auparavant y avait ça dépend quand on prend la plu- en remontant plus loin c' était des des vignerons. ah oui. des vignerons **[cultivateurs]**. 

 * r-ASSOCIATIVE-jmuzerelle_1352470016822: ['u-MENTION-jmuzerelle_1375887569402', 'u-MENTION-agoudjo_1335459976093'] 

	 oh jusqu' à jusqu' à Jeanne d' Arc par là on retrouve **[des noms de de ma famille]** non c' est pas mon côté par les femmes.. ah oui ce serait **[quel nom]** euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1352570731479: ['u-MENTION-agoudjo_1335809258468', 'u-MENTION-agoudjo_1335809359812'] 

	 au courant oui d' accord oui oui oui oui euh vous avez fait des études jusqu' à **[quel âge]** monsieur ?. euh jusqu' à **[treize ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1352656996730: ['u-MENTION-agoudjo_1335954212593', 'u-MENTION-agoudjo_1335955837921'] 

	 et vous êtes d' ac- d' avis que les enfants doivent aller à l' école très tard ou enfin jusqu' à **[quel âge]** à votre avis est -ce qu' on devrait aller à l' école aujourd'hui ?. bah ça c' est ça dépend des enfants. [...] oui. entre **[quatorze et seize ans]** bien ça n' est pas au point encore alors ceux qui ne peuvent pas suivre euh à ce moment -là y a un trou on les oblige à aller à l' école et il n' y a rien de spécial pour eux ça viendra peut- être mais. 

 * s-CHAIN-13: ['u-MENTION-agoudjo_1335459976093', 'u-MENTION-agoudjo_1335460013578', 'u-MENTION-agoudjo_1335460030968', 'u-MENTION-agoudjo_1335460252812', 'u-MENTION-agoudjo_1335460644875', 'u-MENTION-agoudjo_1335460696546', 'u-MENTION-agoudjo_1335517530093', 'u-MENTION-agoudjo_1335517641625'] 

	 ah oui ce serait **[quel nom]** euh ?. **[c']** était **[Ligneaux]** et puis du reste y a la rue **[aux Ligneaux]** au bout de la un peu plus bas. ah bon. il y avait beaucoup de **[Ligneaux]** par ici. oui. et **[ce nom-là]** euh figurent dans les registres de des paroisses à ce moment -là c' était des paroisses alors à ce moment -là si on regarde les registres de paroisses depuis des siècles je.. [...]. ah bon c' est très intéressant le le mot **[Ligneaux]** ça veut dire quelque chose ou bien ? c' est seulement **[un nom]** alors vos euh vos grands parents par exemple qu' est -ce qu' ils faisaient ?. 

 * s-CHAIN-91: ['u-MENTION-agoudjo_1335954212593', 'u-MENTION-agoudjo_1336048278671', 'u-MENTION-agoudjo_1336048340953'] 

	 et vous êtes d' ac- d' avis que les enfants doivent aller à l' école très tard ou enfin jusqu' à **[quel âge]** à votre avis est -ce qu' on devrait aller à l' école aujourd'hui ?. bah ça c' est ça dépend des enfants. [...] hm hm d' accord. et vous vous ne voyez pas de différences entre les garçons et les filles à **[ce point de vue -là]** euh ?. oh non. pour **[l' âge]** d' aller à l' école y a pas de pour vous y a pas de différence ?. 

 * s-CHAIN-311: ['u-MENTION-agoudjo_1337602780345', 'u-MENTION-agoudjo_1337602878079'] 

	 plus instruite ah oui dans **[quel sens]** ?. ben **[sens]** euh français surtout c' est ce qui se fait quand on a besoin. 

### File: 012_C-2.tei

 * r-ASSOCIATIVE-jmuzerelle_1361875670053: ['u-MENTION-jmuzerelle_1361804743079', 'u-MENTION-jmuzerelle_1361804847958'] 

	 jusqu' à **[quel âge]** pensez- vous qu' il faudrait qu' un enfant poursuive ses études ?. ben il on on ne doit jamais s' arrêter. ah oui. on ne doit jamais s' arrêter enfin disons que la formation de base euh doit s' arrêter euh euh très naturellement au moment où l' enfant euh euh a envie de se marier et je j' admets que l' âge normal de se marier étant de **[vingt- et-un vingt-deux vingt-trois ans]** il faut qu' à peu près à cette époque -là si vous voulez il ait acquis euh suffisamment de bagage intellectuel pour pouvoir alors exercer une activité productrice mais il faudrait absolument que que son activité intellectuelle euh gratuite continue absolument encore une fois de la même façon que c' est comme si vous me disiez à quel âge faut- il s' arrêter de faire du sport. 

 * s-CHAIN-62: ['u-MENTION-jmuzerelle_1361804743079', 'u-MENTION-jmuzerelle_1361804838302', 'u-MENTION-jmuzerelle_1361805318081', 'u-MENTION-jmuzerelle_1361805338673'] 

	 jusqu' à **[quel âge]** pensez- vous qu' il faudrait qu' un enfant poursuive ses études ?. ben il on on ne doit jamais s' arrêter. ah oui. on ne doit jamais s' arrêter enfin disons que la formation de base euh doit s' arrêter euh euh très naturellement au moment où l' enfant euh euh a envie de se marier et je j' admets que **[l' âge normal]** de se marier étant de vingt- et-un vingt-deux vingt-trois ans il faut qu' à peu près à cette époque -là si vous voulez il ait acquis euh suffisamment de bagage intellectuel pour pouvoir alors exercer une activité productrice mais il faudrait absolument que que son activité intellectuelle euh gratuite continue absolument encore une fois de la même façon que c' est comme si vous me disiez à **[quel âge]** faut- il s' arrêter de faire du sport. hm hm ah oui. il n' y a pas **[d' âge]** pour s' arrêter. 

### File: 078_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1358436686236: ['u-MENTION-jmuzerelle_1358413538634', 'u-MENTION-jmuzerelle_1358413554665'] 

	 hm hm hm hm et euh dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh j' étais fort en **[maths]** c' est surtout en maths que j' étais. 

 * r-ASSOCIATIVE-jmuzerelle_1358437929123: ['u-MENTION-jmuzerelle_1358416565481', 'u-MENTION-jmuzerelle_1358416641647'] 

	 vous savez pas à **[quel âge]** vous avez eu votre ?. eh bien j' ai eu mon premier stylo euh je m' en souviens très bien c' était à l' âge de je parle stylo hein je ne parle pas de de plume parce qu' on écrivait à la plume gauloise. [...] oui oui. euh j' ai possédé mon stylo pour la première fois à **[l' âge de onze ans]** onze ans on me on on m' a offert un stylo. 

 * r-ASSOCIATIVE-jmuzerelle_1358441883929: ['u-MENTION-jmuzerelle_1358429217617', 'u-MENTION-jmuzerelle_1358429235248'] 

	 c' est ça oui oui euh et **[quel type de papier]** est -ce que vous utilisez pour écrire à v- ?. euh **[un bloc de papier ordinaire]** euh. 

 * r-ASSOCIATIVE-jmuzerelle_1358441930479: ['u-MENTION-jmuzerelle_1358429217617', 'u-MENTION-jmuzerelle_1358429270474'] 

	 c' est ça oui oui euh et **[quel type de papier]** est -ce que vous utilisez pour écrire à v- ?. euh un bloc de papier ordinaire euh. à lignes euh ?. non non ligné non ligné j' ai horreur **[du papier à lignes]** je trouve que ce n' est pas correct. 

 * r-ASSOCIATIVE-jmuzerelle_1358444127105: ['u-MENTION-jmuzerelle_1358430920905', 'u-MENTION-jmuzerelle_1358431173880'] 

	 c' est leur mère et euh pour **[quel genre de choses]** en général ?. bof. [...] oui euh et est -ce est -ce qu' il y a des choses que vous interdisez de prononcer à vos enfants ?. en somme **[tous les mots grossiers]**. 

 * r-ASSOCIATIVE-jmuzerelle_1358444317130: ['u-MENTION-jmuzerelle_1358431397208', 'u-MENTION-jmuzerelle_1358431420888'] 

	 hm hm votre mère et pour **[quel genre de choses]** euh ?. ah euh **[toutes les affaires de de langage]** de correction de de la langue française ça elle y était très attachée. 

 * s-CHAIN-25: ['u-MENTION-jmuzerelle_1358413538634', 'u-MENTION-jmuzerelle_1358413783221'] 

	 hm hm hm hm et euh dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh j' étais fort en maths **[c']** est surtout en maths que j' étais. 

 * s-CHAIN-40: ['u-MENTION-jmuzerelle_1358416565481', 'u-MENTION-jmuzerelle_1358416762829', 'u-MENTION-jmuzerelle_1358416583833'] 

	 vous savez pas à **[quel âge]** vous avez eu votre ?. eh bien j' ai eu mon premier stylo euh je m' en souviens très bien **[c']** était à **[l' âge]** de je parle stylo hein je ne parle pas de de plume parce qu' on écrivait à la plume gauloise. 

### File: 025_C-3.tei

 * r-ASSOCIATIVE-jmuzerelle_1353407336827: ['u-MENTION-agoudjo_1341301103369', 'u-MENTION-agoudjo_1341301145834'] 

	 oui et **[quel type de papier]** utilisez- vous ?. **[le papier ordinaire]**. 

 * r-ASSOCIATIVE-jmuzerelle_1353407499363: ['u-MENTION-agoudjo_1341300507250', 'u-MENTION-agoudjo_1341302088412'] 

	 oh **[stylo bile]** ou stylo plume ça dépend ce que j' ai sous la main. oui. [...]. vous vous servirez euh de **[quel instrument]** euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1353407510408: ['u-MENTION-agoudjo_1341300549624', 'u-MENTION-agoudjo_1341302088412'] 

	 oh stylo bile ou **[stylo plume]** ça dépend ce que j' ai sous la main. oui. [...]. vous vous servirez euh de **[quel instrument]** euh ?. 

 * r-ASSOCIATIVE-jmuzerelle_1353407878070: ['u-MENTION-agoudjo_1341301103369', 'u-MENTION-jmuzerelle_1353402199467'] 

	 oui et **[quel type de papier]** utilisez- vous ?. le papier ordinaire. [...] et pour le papier ?. oh bah le papier ça dépend à qui j' écrirais m' enfin si j' écrivais à Monsieur le Président de la République par exemple je prendrais **[du papier papier ministre]**. 

 * s-CHAIN-49: ['u-MENTION-agoudjo_1341318750539', 'u-MENTION-agoudjo_1341318984308'] 

	 hum et qui vous reprenez le plus souvent votre père ou votre mère ? oui ? et euh pour **[quel genre de choses]** surtout ?. mon père. [...] vous savez. oui et **[quel genre de choses]** ? un rien euh. 

### File: 029_C-5.tei

 * r-ASSOCIATIVE-jmuzerelle_1363967850304: ['u-MENTION-jmuzerelle_1363947452210', 'u-MENTION-jmuzerelle_1363959330686'] 

	 oui pour parler **[français]** un français euh. hum hum. [...] ça c' est. et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. 

 * r-ASSOCIATIVE-jmuzerelle_1363967890411: ['u-MENTION-jmuzerelle_1363947362151', 'u-MENTION-jmuzerelle_1363959330686'] 

	 et pensez -vous enfin je vous ai déjà posé la question une question sur **[le latin]** est -ce que vous pensez que ce soit utile que les enfants apprennent le latin à l' école ? oui.. [...] ça c' est. et dans **[quelles matières]** étiez- vous le plus fort à l' école ?. 

 * r-ASSOCIATIVE-jmuzerelle_1363967971500: ['u-MENTION-jmuzerelle_1363959604732', 'u-MENTION-jmuzerelle_1363959639270'] 

	 non ? vous ne souvien- euh quel â- à peu près **[quel âge]** vous avez eu ? dix ans. **[dix ans]**. 

 * r-ASSOCIATIVE-jmuzerelle_1363970614443: ['u-MENTION-jmuzerelle_1363963999445', 'u-MENTION-jmuzerelle_1363964052969'] 

	 oui oui et pour **[quel genre de choses]** surtout ? c' était des enfin **[des fautes de français]** ou. 

 * r-ASSOCIATIVE-jmuzerelle_1363970747512: ['u-MENTION-jmuzerelle_1363958659104', 'u-MENTION-jmuzerelle_1363963999445'] 

	 des fautes par exemple **[des fautes de liaison]**. hum hum. [...]. oui oui et pour **[quel genre de choses]** surtout ? c' était des enfin des fautes de français ou. 

 * r-ASSOCIATIVE-jmuzerelle_1363970818633: ['u-MENTION-jmuzerelle_1363963999445', 'u-MENTION-jmuzerelle_1363964272384'] 

	 oui oui et pour **[quel genre de choses]** surtout ? c' était des enfin des fautes de français ou. des fautes de français ensem- euh je vais revenir à je me rappelle je m' en souviens. hum hum. hein ? et des fautes de liaison des des fautes de liaison qui expriment **[des fautes d' accord]**. 

 * s-CHAIN-46: ['u-MENTION-jmuzerelle_1363959464379', 'u-MENTION-jmuzerelle_1363959661710', 'u-MENTION-jmuzerelle_1363959845347'] 

	 et à la suite de **[quelle circonstance]** avez- vous possédé un stylo à plume pour la première fois ? est -ce que vous vous souvenez ?. je me souviens pas. [...] dix ans. oui environ oui ça je pense pas trop me tromper **[la circonstance]** **[c']** était probablement qu' on m' avait dit qu' on écrivait mal avec un stylo à bille. 

 * s-CHAIN-83: ['u-MENTION-jmuzerelle_1363963999445', 'u-MENTION-jmuzerelle_1363964040754'] 

	 oui oui et pour **[quel genre de choses]** surtout ? **[c']** était des enfin des fautes de français ou. 

### File: 015_C-1.tei

 * r-ASSOCIATIVE-jmuzerelle_1367859173401: ['u-MENTION-jmuzerelle_1367848602854', 'u-MENTION-jmuzerelle_1367848666970'] 

	 bien écoutez personnellement on dit que ce ça sert pour les études de **[français]** je crois que ça amène quand même une base dans le dans le français ou dans les langues euh mais enfin euh quand on a la possibilité de le faire euh qu' on réussit bien euh d' accord mais sinon je trouve que c' est c' est même pas la peine de de pousser si on réussit pas enfin. oh oui pourquoi pas ? euh enfin euh mettons que si vous aviez des enfants dans **[quelles matières]** est -ce que vous aimeriez qu' ils soient forts ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367859412729: ['u-MENTION-jmuzerelle_1367849206948', 'u-MENTION-jmuzerelle_1367849286790'] 

	 enfin **[la littérature]** aussi ?. oui la littérature oui. [...] ah oui moi ça quand j' allais en classe ça m' a toujours intéressée et puis même encore maintenant. hm hm euh **[quel genre]** surtout ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367859484107: ['u-MENTION-jmuzerelle_1367849286790', 'u-MENTION-jmuzerelle_1367849497662'] 

	 hm hm euh **[quel genre]** surtout ?. oh ben qu' est -ce que vous voulez que je vous dise ? je sais pas moi quel genre euh. [...] c'est-à-dire qu' il faut quand même être au courant un petit peu de tout aussi bien des des auteurs euh passés que des auteurs modernes que quand même se tenir au courant de l' actualité euh au point de vue littérature ou au point de vue théâtre ou n' importe. oui enfin je me demandais si vous étiez particulièrement touchée par **[la poésie]** ou par le théâtre ou par le roman. 

 * r-ASSOCIATIVE-jmuzerelle_1367859500905: ['u-MENTION-jmuzerelle_1367849286790', 'u-MENTION-jmuzerelle_1367849469807'] 

	 hm hm euh **[quel genre]** surtout ?. oh ben qu' est -ce que vous voulez que je vous dise ? je sais pas moi quel genre euh. enfin si si s' il y avait des. c'est-à-dire qu' il faut quand même être au courant un petit peu de tout aussi bien des des auteurs euh passés que des auteurs modernes que quand même se tenir au courant de l' actualité euh au point de vue littérature ou au point de vue **[théâtre]** ou n' importe. 

 * r-ASSOCIATIVE-jmuzerelle_1367859508198: ['u-MENTION-jmuzerelle_1367849286790', 'u-MENTION-jmuzerelle_1367849510775'] 

	 hm hm euh **[quel genre]** surtout ?. oh ben qu' est -ce que vous voulez que je vous dise ? je sais pas moi quel genre euh. [...] c'est-à-dire qu' il faut quand même être au courant un petit peu de tout aussi bien des des auteurs euh passés que des auteurs modernes que quand même se tenir au courant de l' actualité euh au point de vue littérature ou au point de vue théâtre ou n' importe. oui enfin je me demandais si vous étiez particulièrement touchée par la poésie ou par le théâtre ou par **[le roman]**. 

 * r-ASSOCIATIVE-jmuzerelle_1367860851765: ['u-MENTION-jmuzerelle_1367851230302', 'u-MENTION-jmuzerelle_1367851661144'] 

	 dans **[le centre]** personnellement je la connais pas parce que je n' y suis jamais allée même pas pour visiter j' ai pas encore eu l' occasion mais euh il y a quand même eu un certain effort de fait sinon il y avait bien quelques maisons de jeunes mais dans différents quartiers ce qui c' était pas toujours possible tandis que là c' est vraiment dans le centre alors je pense qu' il y a quand même un un effort de fait ça a donc apporté quelque chose parce que je suppose que c' est pas parce que moi je la fréquente pas qu' il y a des des personnes qui n' y vont pas c' est ça doit être d' ailleurs très intéressant d' après ce que j' ai entendu dire il y a des choses euh en fait qui sont bien. hm hm c' est de **[quel côté]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1367860931621: ['u-MENTION-jmuzerelle_1367851661144', 'u-MENTION-jmuzerelle_1367851752573'] 

	 hm hm c' est de **[quel côté]** ?. la maison de jeunes ? euh celle dont je vous parle elle se trouve vous connaissez Orléans ?. à peu près. à peu près ? elle se trouve en face **[la grande poste]**. 

 * s-CHAIN-59: ['u-MENTION-jmuzerelle_1367848666970', 'u-MENTION-jmuzerelle_1367859307540'] 

	 oh oui pourquoi pas ? euh enfin euh mettons que si vous aviez des enfants dans **[quelles matières]** est -ce que vous aimeriez qu' ils soient forts ?. en français. [...] ah bon. alors je crois que **[c']** est le le français parce que j' ai je préfère quand même ça enfin le français en général pas le la langue. 

 * s-CHAIN-61: ['u-MENTION-jmuzerelle_1367849286790', 'u-MENTION-jmuzerelle_1367849372648'] 

	 hm hm euh **[quel genre]** surtout ?. oh ben qu' est -ce que vous voulez que je vous dise ? je sais pas moi **[quel genre]** euh. 

### File: 133_C-4.tei

 * r-ASSOCIATIVE-jmuzerelle_1365168552811: ['u-MENTION-jmuzerelle_1365152362790', 'u-MENTION-jmuzerelle_1365152411431'] 

	 oui quand même oui mais c' est commode oui alors à la suite de **[quelles circonstances]** avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à quel âge ? si vous pouvez. j' aime pas beaucoup. [...]. c' est c' est **[un anniversaire]** ou première communion. 

 * r-ASSOCIATIVE-jmuzerelle_1365168559675: ['u-MENTION-jmuzerelle_1365152362790', 'u-MENTION-jmuzerelle_1365152423146'] 

	 oui quand même oui mais c' est commode oui alors à la suite de **[quelles circonstances]** avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à quel âge ? si vous pouvez. j' aime pas beaucoup. [...]. c' est c' est un anniversaire ou **[première communion]**. 

 * r-ASSOCIATIVE-jmuzerelle_1365168570377: ['u-MENTION-jmuzerelle_1365152398436', 'u-MENTION-jmuzerelle_1365152452849'] 

	 oui quand même oui mais c' est commode oui alors à la suite de quelles circonstances avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à **[quel âge]** ? si vous pouvez. j' aime pas beaucoup. [...] un stylo encre la première ou c' était. oui **[mes douze ans]** quoi onze ans quoi quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1365168579113: ['u-MENTION-jmuzerelle_1365152398436', 'u-MENTION-jmuzerelle_1365152462614'] 

	 oui quand même oui mais c' est commode oui alors à la suite de quelles circonstances avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à **[quel âge]** ? si vous pouvez. j' aime pas beaucoup. [...] un stylo encre la première ou c' était. oui mes douze ans quoi **[onze ans]** quoi quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1365168742320: ['u-MENTION-jmuzerelle_1365153106137', 'u-MENTION-jmuzerelle_1365153238066'] 

	 pour faire **[quelles sortes de choses]** alors ?. je sais pas euh pour faire quelles sortes de euh dans mon travail vous me demandez ? ça y avait y avait pas mal de choses y avait pour les clients euh comment vous dirais- je ? moi je sais pas y avait **[des comptes]** y avait on faisait les bons on faisait pour les euh des bons du Trésor des choses comme ça le. 

 * r-ASSOCIATIVE-jmuzerelle_1365168751384: ['u-MENTION-jmuzerelle_1365153106137', 'u-MENTION-jmuzerelle_1365153277924'] 

	 pour faire **[quelles sortes de choses]** alors ?. je sais pas euh pour faire quelles sortes de euh dans mon travail vous me demandez ? ça y avait y avait pas mal de choses y avait pour les clients euh comment vous dirais- je ? moi je sais pas y avait des comptes y avait on faisait **[les bons]** on faisait pour les euh des bons du Trésor des choses comme ça le. 

 * r-ASSOCIATIVE-jmuzerelle_1365170813013: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164160363'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. **[papier. 

 * r-ASSOCIATIVE-jmuzerelle_1365170843984: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164075359'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. papier. oui les **[les verts]** ou les blancs ou les gris enfin euh. 

 * r-ASSOCIATIVE-jmuzerelle_1365170850004: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164083939'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. papier. oui les les verts ou **[les blancs]** ou les gris enfin euh. 

 * r-ASSOCIATIVE-jmuzerelle_1365170856264: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164092503'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. papier. oui les les verts ou les blancs ou **[les gris]** enfin euh. 

 * r-ASSOCIATIVE-jmuzerelle_1365170973073: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164228847'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. [...] classique écoute euh raconte pas d' histoire. et sans **[rayures]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1365171017268: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164260219'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. [...] rien quand même oui non l' esthétique euh. et sans glisser un **[un papier]** ah oui. 

 * r-ASSOCIATIVE-jmuzerelle_1365171165156: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164584575'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. [...] et si vous deviez écrire au professeur à l' école de vos enfants est -ce que vous faites la même chose en général ?. euh du papier alors là euh soit ou **[une carte]** vous savez c' est pas les cartes de visite mais. 

 * r-ASSOCIATIVE-jmuzerelle_1365171261970: ['u-MENTION-jmuzerelle_1365164023378', 'u-MENTION-jmuzerelle_1365164794978'] 

	 oui oui et **[quel type de papier]** emp- préférez- vous ?. comment dirais- je euh ?. [...] et alors pour une lettre officielle ?. pour la lettre ben pareil et puis de toute façon vous savez j' ai un un type de **[papier à lettres]** qui fait vraiment pour euh. 

 * r-ASSOCIATIVE-jmuzerelle_1377781006292: ['u-MENTION-jmuzerelle_1365149222765', 'u-MENTION-jmuzerelle_1365151950387'] 

	 mais alors parmi vos connaissances madame quelle est la personne qui parle le mieux **[le français]** c'est-à-dire donner la profession si vous ?. mon mari. [...]. enfin madame dans **[quelle matière]** étiez- vous le plus fort à l' école ?. 

 * s-CHAIN-47: ['u-MENTION-jmuzerelle_1365152398436', 'u-MENTION-jmuzerelle_1365152962071'] 

	 oui quand même oui mais c' est commode oui alors à la suite de quelles circonstances avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à **[quel âge]** ? si vous pouvez. j' aime pas beaucoup. [...] un stylo encre la première ou c' était. oui mes douze ans quoi onze ans quoi **[quelque chose]** comme ça. 

 * s-CHAIN-49: ['u-MENTION-jmuzerelle_1365153106137', 'u-MENTION-jmuzerelle_1365153148631'] 

	 pour faire **[quelles sortes de choses]** alors ?. je sais pas euh pour faire **[quelles sortes]** de euh dans mon travail vous me demandez ? ça y avait y avait pas mal de choses y avait pour les clients euh comment vous dirais- je ? moi je sais pas y avait des comptes y avait on faisait les bons on faisait pour les euh des bons du Trésor des choses comme ça le. 

