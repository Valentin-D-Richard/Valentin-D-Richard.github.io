### File: CO2_ESLO_002_C.tei

 * s-CHAIN-55: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616662623'] 

	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?. Paris oui Paris. [...] oui. essayer de voir **[quelque chose de valable]** bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi. 

### File: CO2_ESLO_001_C.tei

 * s-CHAIN-76: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292100299062', 'u-MENTION-jmuzerelle_1292101269216', 'u-MENTION-jmuzerelle_1292102584083', 'u-MENTION-jmuzerelle_1348844990034', 'u-MENTION-jmuzerelle_1292102607143', 'u-MENTION-jmuzerelle_1292102964263', 'u-MENTION-jmuzerelle_1292102772196', 'u-MENTION-jmuzerelle_1292102827081'] 

	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir. oui oui oui. comprenez- vous ? je l' ai aiguillé vers **[un métier manuel]** il est coiffeur. hum hum. [...] oui. voyez ce qui prouve que même même dans **[des métiers manuels]** on on peut faire sa place j' estime. oui hum. [...] oui oui oui oui oui. moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis **[tous ces métiers manuels]** **[qui]** sont **[des métiers rudes]** d' accord hein mais **[qui]** sont **[des métiers rémunérateurs]** croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment **[des petits métiers]** question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois. 

 * s-CHAIN-175: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1357320621452', 'u-MENTION-jmuzerelle_1294145351820', 'u-MENTION-jmuzerelle_1294145404615'] 

	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?. bah **[c']** est peut-être ça quand même l' orthographe. oui. c' est peut-être un paradoxe mais enfin. et un **[une autre matière]** **[deuxième matière]** aurait été quoi ?. 

