### File: 027_0000001c.tei

 * s-CHAIN-0: ['u-MENTION-gpascault_1349679753650', 'u-MENTION-gpascault_1349679868949', 'u-MENTION-gpascault_1349680409559', 'u-MENTION-gpascault_1349680518697', 'u-MENTION-gpascault_1349680546703', 'u-MENTION-gpascault_1349682910016', 'u-MENTION-gpascault_1349682996040', 'u-MENTION-gpascault_1349682998060', 'u-MENTION-gpascault_1349683000299', 'u-MENTION-gpascault_1349682968568', 'u-MENTION-gpascault_1349683891634', 'u-MENTION-gpascault_1349683947547', 'u-MENTION-gpascault_1349683965467', 'u-MENTION-gpascault_1349684077293', 'u-MENTION-gpascault_1349684142158', 'u-MENTION-gpascault_1349684154649', 'u-MENTION-gpascault_1349684157705', 'u-MENTION-gpascault_1349684290908'] 

	 oui bonjour c' est monsieur Nom j' ai **[ma fille]** **[qui]** a passé son DEUG l' année dernière et puis e **[elle]** voulait récupéré son diplôme alors je sais pas quand est ce qu' **[elle]** peut le récupérer. **[elle]** a passé son e quel DEUG e monsieur. le DEUG de e a- ad- administration économique et sociale hein. [...] ha oui. donc c' est pour çà il faut nous préciser le DEUG donc c' est le DEUG a- ac- économique ouais donc **[elle]** peut revenir quand **[elle]** veux **[elle]** peut venir quand **[elle]** veux comment. A E S **[elle]** a eu oui. c' est ouvert aujourd'hui par exemple. [...] jusqu' à dix sept heure trente. enfin moi je vais partir tout à l' heure à seize heure parce que je suis en congé mais e **[elle]** va passer à quelle heure.. ben e- **[elle]** est sur la route de Rennes e pour venir de Rennes là donc e **[elle]** va passer ben je sais pas bientôt. **[elle]** s' adresse e au secrétariat hein qu' **[elle]** s' inquiète pas hein. d' accord hé bien je vais **[lui]** dire qu' **[elle]** peut passer à ce moment là jusqu' à dix sept heure. ouais ouais ouais ben e et a dix si il y a personne à l' accueil **[elle]** va directement au secrétariat. 

 * s-CHAIN-2: ['u-MENTION-gpascault_1349679903453', 'u-MENTION-gpascault_1349680653219', 'u-MENTION-gpascault_1349680953025', 'u-MENTION-jmuzerelle_1365668383195', 'u-MENTION-gpascault_1349682674640', 'u-MENTION-gpascault_1349682679650'] 

	 oui bonjour c' est monsieur Nom j' ai ma fille qui a passé **[son DEUG]** l' année dernière et puis e elle voulait récupéré son diplôme alors je sais pas quand est ce qu' elle peut le récupérer. elle a passé son e **[quel DEUG]** e monsieur. **[le DEUG de e a- ad- administration économique et]** sociale hein. **[c']** est chez nous alors e ouais ouais ouais donc c' est à rue de la Loi c' est Vannes centre ouais c' est çà oui que les les sciences ils sont partis à Tohannic et puis bon les gens qui savent pas il viennent récupérer les les DEUG de S V ou S M ici si vous voulez.. ha oui. donc c' est pour çà il faut nous préciser **[le DEUG]** donc c' est **[le DEUG a- ac- économique]** ouais donc elle peut revenir quand elle veux elle peut venir quand elle veux comment. 

 * s-CHAIN-3: ['u-MENTION-gpascault_1349682198026', 'u-MENTION-gpascault_1349682205257', 'u-MENTION-gpascault_1349682214844'] 

	 c' est chez nous alors e ouais ouais ouais donc c' est à rue de la Loi c' est Vannes centre ouais c' est çà oui que les les sciences ils sont partis à Tohannic et puis bon **[les gens]** **[qui]** savent pas **[il]** viennent récupérer les les DEUG de S V ou S M ici si vous voulez. 

### File: 047_00000030.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378218063212', 'u-MENTION-jmuzerelle_1378218094642', 'u-MENTION-jmuzerelle_1378218202393', 'u-MENTION-jmuzerelle_1378218307423', 'u-MENTION-jmuzerelle_1378218316233', 'u-MENTION-jmuzerelle_1378218367783', 'u-MENTION-jmuzerelle_1378218461173', 'u-MENTION-jmuzerelle_1378218478323', 'u-MENTION-jmuzerelle_1378218483583', 'u-MENTION-jmuzerelle_1378219368125', 'u-MENTION-jmuzerelle_1378218412443'] 

	 oui bonjour madame e j' appelais pour avoir un petit renseignement e je souhaitais savoir si l' université préparait e comment faisait faisait une préparation à **[des concours administratifs style e rédacteur territorial ou adjoint administratif]**. **[des concours administratifs]**. ouais. si on avait un programme sur **[ça]**. voilà oui oui. [...] je l' avais. est ce qu' il y aurait pas **[des concours administratifs]**. e **[des concours administratifs]** e ouais il y a un service de de douze heures à dix-huit heures allo. allo. ouais c' est **[quels concours]** vous parlez madame. e donc e s- soit adjoint administratif ou rédacteur e. ah non **[c']** est pas **[ça]** **[c']** est pas ici chez nous non. non **[c']** est pas vous ne faîtes pas de préparations e e pour **[ces concours -là]**. 

 * s-CHAIN-12: ['u-MENTION-jmuzerelle_1378219071275', 'u-MENTION-jmuzerelle_1378219102605'] 

	 le Service de l' Information et de l' Orientation lui il doit peut-être e au au moins il vous donnera **[le numéro]** **[où]** téléphoner quoi. 

### File: 083_00000054.tei

 * r-ASSOCIATIVE-jmuzerelle_1339688416198: ['u-MENTION-adrouin_1339070059809', 'u-MENTION-adrouin_1339070091093'] 

	 je vais rechercher je vais regarder s' il est dans son bureau et dans **[quelle filière]** il travaille. e il travaille e **[au niveau informatique]**. 

### File: 068_00000045.tei

 * r-ASSOCIATIVE-jmuzerelle_1378303203486: ['u-MENTION-jmuzerelle_1378302768821', 'u-MENTION-jmuzerelle_1378302817088'] 

	 d' accord et vous rep- et vous reprenez à **[quelle heure]**.. oh moi je m' arrête une demie heure de midi à **[midi et demie]** hein. 

 * s-CHAIN-10: ['u-MENTION-jmuzerelle_1378302244941', 'u-MENTION-jmuzerelle_1378302497895', 'u-MENTION-jmuzerelle_1378302501842', 'u-MENTION-jmuzerelle_1378302511639', 'u-MENTION-jmuzerelle_1378302514634', 'u-MENTION-jmuzerelle_1378302572854', 'u-MENTION-jmuzerelle_1378302576582', 'u-MENTION-jmuzerelle_1378302625800', 'u-MENTION-jmuzerelle_1378302740601', 'u-MENTION-jmuzerelle_1378302744064'] 

	 ah d' accord ben voilà j' ai toutes les explications non parce que je connais Prénom2 et **[Prénom4]** à l' accueil et puis voilà à T- à rue de la Loi donc j' étais étonnée donc e moi j' appelais parce que ce soir à six heures dix-huit heures il y a une réunion d' info- enfin deux réunions d' informations rue de la Loi. la même voix oui. [...] e il doit y avoir des supports non. e oui il faut que j' en parle à **[Prénom4]** parce que **[Prénom4]** est à la repro ce que je vais faire je vais. ou je rappelle **[Prénom4]** vous préférez ou **[Prénom4]** me rappelle tout à l' heure.. oui enfin toute manière je crois qu' **[il]** est **[il]** est à la repro pour l' instant. oui. donc e à une heure et demie ben je peux **[lui]** dire e de vous rappeler oui. oui parce qu' il doit y avoir des panneaux à mettre à l' extérieur ou quelque chose comme ça alors mon numéro c' est 0 2 97 oh ben voilà que j' ai un trou maintenant. [...] ça va mal non 0 2 97 0 1 72 XX. 72 XX Prénom Nom oui d' accord d' accord c' est **[lui]** **[qui]** s' occupe de de ça. 

### File: 037_00000026.tei

 * r-ASSOCIATIVE-gpascault_1349947242882: ['u-MENTION-gpascault_1349707731355', 'u-MENTION-jmuzerelle_1349788729862'] 

	 e conservez je vais demander à qu- à partir de **[quelle heure]** ce soir. c' est à **[dix huit heure]**. 

 * s-CHAIN-0: ['u-MENTION-gpascault_1349706928655', 'u-MENTION-gpascault_1349707028867', 'u-MENTION-gpascault_1349707305238', 'u-MENTION-jmuzerelle_1349787875993', 'u-MENTION-gpascault_1349707462519', 'u-MENTION-gpascault_1349707920372'] 

	 oui bonjour madame e j' aurais aimé savoir e ou se trouve la réunion de présentation **[du D A E U]** ce soir. **[du D A E U]** ha je sais pas c' est avec qui. e ben je sais pas je vous ai téléph- enfin je sais pas si vous sur qui je suis tombé e vous préparez **[un examen]** e **[qui]** s' appelle **[le D A E U]** un équivalent bac au niveau de l' université et il y a eu une réun- réunion de présentation ce soir. e conservez je vais demander à qu- à partir de quelle heure ce soir. c' est à dix huit heure. et comme moi je viens d' arriver là je sais pas est ce que tu sais ou il y a une réunion de **[D A E U]** à dix huit heure tu n' est pas au courant. 

### File: 098_00000063.tei

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1378307098238', 'u-MENTION-jmuzerelle_1378307142433', 'u-MENTION-jmuzerelle_1378307157628', 'u-MENTION-jmuzerelle_1378307218811', 'u-MENTION-jmuzerelle_1378307231291', 'u-MENTION-jmuzerelle_1378307245440', 'u-MENTION-jmuzerelle_1378307255409', 'u-MENTION-jmuzerelle_1378307264504'] 

	 oui bonjour madame excusez moi de vous déranger j' aurais voulu un renseignement s' il vous plait j' ai **[ma fille]** **[qui]** s' est inscrite chez vous e par internet.. hm hm. et **[elle]** n' a pas eu confirmation. alors e donc **[elle]** a formulé trois voeux au départ sur internet. ouais oui je pense oui. oui et avant le six juin **[elle]** a dû valider un des trois voeux. non justement **[elle]** a pas pu le faire. **[elle]** n' a pas pu le faire bon alors **[elle]** souhaite s' inscrire chez nous madame. 

 * s-CHAIN-3: ['u-MENTION-jmuzerelle_1378307297622', 'u-MENTION-jmuzerelle_1378307309790'] 

	 en **[quoi]**. e **[licence un A E S]**. 

### File: 067_00000044.tei

 * s-CHAIN-3: ['u-MENTION-jmuzerelle_1378298524205', 'u-MENTION-jmuzerelle_1378298542379', 'u-MENTION-jmuzerelle_1378298672453', 'u-MENTION-jmuzerelle_1378298676478', 'u-MENTION-jmuzerelle_1378298845878'] 

	 c' est ça et **[madame Nom3]** j' ai pas son numéro direct. **[madame Nom3]**. oui. [...] nous on fait 26 9 oui oui oui je sais vous bon je fais les mêmes e au départ ouais 0 2 97. **[elle]** **[qui]** est responsable de la première année e A E S. oui mais je peux vous passer le secrétariat autrement mais je crois qu' elle est en ligne la personne mais autrement oui il y a Nom2 Prénom2 **[Prénom3]**. 

### File: 048_00000031.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378220296128', 'u-MENTION-jmuzerelle_1378220363928', 'u-MENTION-jmuzerelle_1378220522468', 'u-MENTION-jmuzerelle_1378220533478', 'u-MENTION-jmuzerelle_1378221729815', 'u-MENTION-jmuzerelle_1378220665139'] 

	 ah d' accord très bien parce qu' on m' a donné **[un autre numéro]** **[c']** est le 88 05 49. oui oui je vais vous donner le numéro de téléphone directement de Lorient de madame Nom. [...] oui c' est Prénom c' est ça. mais je crois qu' on m' a donné **[l' autre numéro]** hein je suis en train de vous laisser chercher quelque chose que j' ai déjà c' est pas gentil. **[quel numéro]** vous avez **[quel numéro]** vous avez. j' ai le 88 0 5 49 on m' a dit d' essayer soit l' un soit **[l' autre]**. 

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378220296128', 'u-MENTION-jmuzerelle_1378220363928', 'u-MENTION-jmuzerelle_1378220522468', 'u-MENTION-jmuzerelle_1378220533478', 'u-MENTION-jmuzerelle_1378221729815', 'u-MENTION-jmuzerelle_1378220665139'] 

	 ah d' accord très bien parce qu' on m' a donné **[un autre numéro]** **[c']** est le 88 05 49. oui oui je vais vous donner le numéro de téléphone directement de Lorient de madame Nom. [...] oui c' est Prénom c' est ça. mais je crois qu' on m' a donné **[l' autre numéro]** hein je suis en train de vous laisser chercher quelque chose que j' ai déjà c' est pas gentil. **[quel numéro]** vous avez **[quel numéro]** vous avez. j' ai le 88 0 5 49 on m' a dit d' essayer soit l' un soit **[l' autre]**. 

### File: 022_00000017.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378212888606', 'u-MENTION-jmuzerelle_1378212921236', 'u-MENTION-jmuzerelle_1378213015716'] 

	 à l' accueil donc voilà et c' est parce que moi je e c' est pour une préinscription ma fille a été e c' est c' est **[madame Nom2]** **[qui]** l' a e inscrite il y a deux jours en première année et e **[elle]** m' a donné un numéro de code. 

### File: 079_00000050.tei

 * r-ASSOCIATIVE-jmuzerelle_1378305124438: ['u-MENTION-jmuzerelle_1378304678492', 'u-MENTION-jmuzerelle_1378304687103'] 

	 oui en **[quelle filière]**. elle est en **[licence professionnelle gestion des Ressources Humaines]** dans les PMO. 

### File: 053_00000036.tei

 * r-ASSOCIATIVE-jmuzerelle_1378223276209: ['u-MENTION-jmuzerelle_1378222891908', 'u-MENTION-jmuzerelle_1378223051629'] 

	 oui bonjour j' aurais aimé savoir si **[les diplômes]** de qui a été envoyé au rectorat pour des modifications était arrivé ou pas. e j' ai pas compris vous p- oui. [...] ouais ben ouais ouais ouais. et en **[quelle filière]**. 

 * r-ASSOCIATIVE-jmuzerelle_1378223299179: ['u-MENTION-jmuzerelle_1378223051629', 'u-MENTION-jmuzerelle_1378223061479'] 

	 et en **[quelle filière]**. **[A E S]** de deux mille deux. 

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1378222891908', 'u-MENTION-jmuzerelle_1378222915258', 'u-MENTION-jmuzerelle_1378222984408', 'u-MENTION-jmuzerelle_1378222993378'] 

	 oui bonjour j' aurais aimé savoir si **[les diplômes]** de qui a été envoyé au rectorat pour des modifications était arrivé ou pas. e j' ai pas compris vous p- oui. donc en fait il y a **[un diplôme]** **[qui]** a été envoyé au rectorat pour des modifications et donc j' aurais aimé savoir est -ce qu' **[il]** vous est parvenu ou pas encore. 

### File: 104_00000069.tei

 * s-CHAIN-3: ['u-MENTION-jmuzerelle_1378310013045', 'u-MENTION-jmuzerelle_1378310025868', 'u-MENTION-jmuzerelle_1378310070968', 'u-MENTION-jmuzerelle_1378310155270', 'u-MENTION-jmuzerelle_1378310163835', 'u-MENTION-jmuzerelle_1378310224722'] 

	 c' est pour **[ma fille]**. vous me donnez son nom s' il vous plaît. **[Nom Prénom]**. N O M. voilà oui oui. **[Nom Prénom]** donc e dossier de dérogation pour entrer en deuxième année de D U. oui. [...] oui. alors madame je suppose Nom appelle pour **[sa fille **[Nom Prénom]** **[qui]** aurait envoyé un dossier de dérogation pour entrer en deuxième année de D U elle voulait savoir e si tu avais bien reçu le dossier ce qu' il en était quand est -ce qu' elle aurait les réponses. 

### File: 028_0000001d.tei

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1378371594441', 'u-MENTION-jmuzerelle_1378371637497', 'u-MENTION-jmuzerelle_1378371656358'] 

	 e j' ai en communication là **[une personne]** **[qui]** a un souci avec e son inscription je te passe. un souci avec une inscription. ouais d' accord Ok. **[la]** moi ouais. 

 * s-CHAIN-11: ['u-MENTION-jmuzerelle_1378372479952', 'u-MENTION-jmuzerelle_1378372487982', 'u-MENTION-jmuzerelle_1378372498622', 'u-MENTION-jmuzerelle_1378372509892', 'u-MENTION-jmuzerelle_1378372520432', 'u-MENTION-jmuzerelle_1378372563172', 'u-MENTION-jmuzerelle_1378372575232', 'u-MENTION-jmuzerelle_1378372583612', 'u-MENTION-jmuzerelle_1378372604072'] 

	 e peut-être ça a pas été pris mais bon **[ceux]** **[qui]** l' ont pas fait **[ils]** vont le refaire là. d' accord. parce qu' il y **[en]** a **[qui]** l' ont pas fait. d' accord. [...] voilà c' est tout ce que je voulais savoir parce que je m' inquiétais un peu de pas a- de pas avoir. **[en]** a il y **[en]** a beaucoup **[qui]** **[qui]** ont pas fait ça ceux qui étaient candidate à la fois à l' I U T et puis e chez nous et ils savaient pas si il fallait valider ou attendre les résultats de l' I U T d' accord parce que ben moi. 

 * s-CHAIN-11: ['u-MENTION-jmuzerelle_1378372479952', 'u-MENTION-jmuzerelle_1378372487982', 'u-MENTION-jmuzerelle_1378372498622', 'u-MENTION-jmuzerelle_1378372509892', 'u-MENTION-jmuzerelle_1378372520432', 'u-MENTION-jmuzerelle_1378372563172', 'u-MENTION-jmuzerelle_1378372575232', 'u-MENTION-jmuzerelle_1378372583612', 'u-MENTION-jmuzerelle_1378372604072'] 

	 e peut-être ça a pas été pris mais bon **[ceux]** **[qui]** l' ont pas fait **[ils]** vont le refaire là. d' accord. parce qu' il y **[en]** a **[qui]** l' ont pas fait. d' accord. [...] voilà c' est tout ce que je voulais savoir parce que je m' inquiétais un peu de pas a- de pas avoir. **[en]** a il y **[en]** a beaucoup **[qui]** **[qui]** ont pas fait ça ceux qui étaient candidate à la fois à l' I U T et puis e chez nous et ils savaient pas si il fallait valider ou attendre les résultats de l' I U T d' accord parce que ben moi. 

 * s-CHAIN-11: ['u-MENTION-jmuzerelle_1378372479952', 'u-MENTION-jmuzerelle_1378372487982', 'u-MENTION-jmuzerelle_1378372498622', 'u-MENTION-jmuzerelle_1378372509892', 'u-MENTION-jmuzerelle_1378372520432', 'u-MENTION-jmuzerelle_1378372563172', 'u-MENTION-jmuzerelle_1378372575232', 'u-MENTION-jmuzerelle_1378372583612', 'u-MENTION-jmuzerelle_1378372604072'] 

	 e peut-être ça a pas été pris mais bon **[ceux]** **[qui]** l' ont pas fait **[ils]** vont le refaire là. d' accord. parce qu' il y **[en]** a **[qui]** l' ont pas fait. d' accord. [...] voilà c' est tout ce que je voulais savoir parce que je m' inquiétais un peu de pas a- de pas avoir. **[en]** a il y **[en]** a beaucoup **[qui]** **[qui]** ont pas fait ça ceux qui étaient candidate à la fois à l' I U T et puis e chez nous et ils savaient pas si il fallait valider ou attendre les résultats de l' I U T d' accord parce que ben moi. 

 * s-CHAIN-11: ['u-MENTION-jmuzerelle_1378372479952', 'u-MENTION-jmuzerelle_1378372487982', 'u-MENTION-jmuzerelle_1378372498622', 'u-MENTION-jmuzerelle_1378372509892', 'u-MENTION-jmuzerelle_1378372520432', 'u-MENTION-jmuzerelle_1378372563172', 'u-MENTION-jmuzerelle_1378372575232', 'u-MENTION-jmuzerelle_1378372583612', 'u-MENTION-jmuzerelle_1378372604072'] 

	 e peut-être ça a pas été pris mais bon **[ceux]** **[qui]** l' ont pas fait **[ils]** vont le refaire là. d' accord. parce qu' il y **[en]** a **[qui]** l' ont pas fait. d' accord. [...] voilà c' est tout ce que je voulais savoir parce que je m' inquiétais un peu de pas a- de pas avoir. **[en]** a il y **[en]** a beaucoup **[qui]** **[qui]** ont pas fait ça ceux qui étaient candidate à la fois à l' I U T et puis e chez nous et ils savaient pas si il fallait valider ou attendre les résultats de l' I U T d' accord parce que ben moi. 

 * s-CHAIN-12: ['u-MENTION-jmuzerelle_1378372620292', 'u-MENTION-jmuzerelle_1378372642812', 'u-MENTION-jmuzerelle_1378372677852'] 

	 en a il y en a beaucoup qui qui ont pas fait ça **[ceux]** **[qui]** étaient candidate à la fois à l' I U T et puis e chez nous et **[ils]** savaient pas si il fallait valider ou attendre les résultats de l' I U T d' accord parce que ben moi. 

### File: 057_0000003a.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378287795766', 'u-MENTION-jmuzerelle_1378288008840'] 

	 oui bonjour madame excusez- moi de vous déranger en fait je suis étudiant et en fait j' aurais voulu savoir e les formations qui e qu' il y avait au niveau des troisièmes cycles avec **[le nouveau master]** **[qui]** va se mettre en place en gestion en fait ce que vous aviez. 

 * s-CHAIN-5: ['u-MENTION-jmuzerelle_1378288121067', 'u-MENTION-jmuzerelle_1378288206523'] 

	 qu' est -ce qui fait où c' est que j' ai mis ma feuille c' est pas **[le S U I O]** **[qui]** peut les renseigner et c' est vous autrement oui est -ce que vous pouvez rappeler la semaine prochaine parce qu' ils n' ont pas eu toutes les informations e. 

 * s-CHAIN-9: ['u-MENTION-jmuzerelle_1378288037575', 'u-MENTION-jmuzerelle_1378288190065', 'u-MENTION-jmuzerelle_1378288280468', 'u-MENTION-jmuzerelle_1378297112922', 'u-MENTION-jmuzerelle_1378297123171'] 

	 non pour savoir ce que vous aviez en en **[master]** en fait. oui conservez je vais vous passer je v- je vais vous passer une personne hein conservez. [...] c' est pour les la date d' inscription c' est ça. e ouais pour s' inscrire par exemple s' il y a **[un master]** **[qui]** m' intéresse il y a **[un master]** **[qui]** l' intéresse et il voudrait s' inscrire e. 

 * s-CHAIN-9: ['u-MENTION-jmuzerelle_1378288037575', 'u-MENTION-jmuzerelle_1378288190065', 'u-MENTION-jmuzerelle_1378288280468', 'u-MENTION-jmuzerelle_1378297112922', 'u-MENTION-jmuzerelle_1378297123171'] 

	 non pour savoir ce que vous aviez en en **[master]** en fait. oui conservez je vais vous passer je v- je vais vous passer une personne hein conservez. [...] c' est pour les la date d' inscription c' est ça. e ouais pour s' inscrire par exemple s' il y a **[un master]** **[qui]** m' intéresse il y a **[un master]** **[qui]** l' intéresse et il voudrait s' inscrire e. 

### File: 073_0000004a.tei

 * r-ASSOCIATIVE-jmuzerelle_1343835975178: ['u-MENTION-adrouin_1341137130053', 'u-MENTION-adrouin_1341137283713'] 

	 e oui qu' avez v- dans **[quelle filière]**. e je je en fait j' ai reçu un un appel sur mon portable par ce que je je donne des cours et c' est j' aurais voulu la personne qui s' occupe en maîtrise de **[droit publique]** de de collecter les notes alors je c' est sur un portable c' est très mal indiqué je j' arrive pas à comprendre le nom. 

 * s-CHAIN-0: ['u-MENTION-adrouin_1341137240485', 'u-MENTION-adrouin_1341137255009', 'u-MENTION-adrouin_1341137363133', 'u-MENTION-adrouin_1341137373507', 'u-MENTION-adrouin_1341137695225', 'u-MENTION-adrouin_1341137724709'] 

	 e je je en fait j' ai reçu un un appel sur mon portable par ce que je je donne des cours et c' est j' aurais voulu **[la personne]** **[qui]** s' occupe en maîtrise de droit publique de de collecter les notes alors je c' est sur un portable c' est très mal indiqué je j' arrive pas à comprendre le nom.. **[çà]** doit être **[Nom Prénom]**. e c' est possible oui. [...] maîtrise. maîtrise **[Nom Prénom]** conservez je vais vous **[la]** passer. 

### File: 024_00000019.tei

 * r-ASSOCIATIVE-jmuzerelle_1378216757764: ['u-MENTION-jmuzerelle_1378214623790', 'u-MENTION-jmuzerelle_1378214637760'] 

	 il est **[quelle heure]** là **[deux heures]** e deux heures. 

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1378214018545', 'u-MENTION-jmuzerelle_1378214069320', 'u-MENTION-jmuzerelle_1378214076825', 'u-MENTION-jmuzerelle_1378214148035', 'u-MENTION-jmuzerelle_1378214167820', 'u-MENTION-jmuzerelle_1378214260920', 'u-MENTION-jmuzerelle_1378214304825', 'u-MENTION-jmuzerelle_1378214451401', 'u-MENTION-jmuzerelle_1378214489796', 'u-MENTION-jmuzerelle_1378214682255', 'u-MENTION-jmuzerelle_1378214695885', 'u-MENTION-jmuzerelle_1378215218300', 'u-MENTION-jmuzerelle_1378215468646', 'u-MENTION-jmuzerelle_1378215616381', 'u-MENTION-jmuzerelle_1378215646446'] 

	 e Prénom Nom c' est Prénom2 il paraît que tu as **[des sujets d' examen]**.. oui. **[qui]** urgent. e ben oui. **[c']** est pour quand. e ben écoute e pour demain après-midi j' en ai un. [...]. e tu veux qu ? on fasse **[ça]** demain matin. e **[c']** est combien de pages e. e alors attends tu es e après il y en a un autre pour lundi. [...] oui bon. c' est quoi c' est qu' est -ce qu' il y a **[c']** est recto verso à agrafer ou il y a des. **[c']** est et il y a il y a des agrafages et des recto verso et des e des dossiers des petits dossiers de cinq ou six pages à quatre-vingt-dix exemplaires là par exemple. e ouais mais cinq six pages c' est agrafé quoi. oui oui oui oui oui. ouais ouais ouais c' est pas des A3 e des e des A4 à transformer en A3 e ou et cetera e tu veux qu' on voie **[ça]** demain matin.. ah ben écoute demain matin Prénom2 si tu veux. **[c']** est pour demain après-midi. oui. il est quelle heure là deux heures e deux heures. nous on peut faire **[ça]** demain matin hein. tu as **[les sujets]** là avec toi. oui. [...] ouais. **[ça]** passe avant hein là là là il y a des priorités où. oui. [...] un exa- non non. Prénom3 était au courant je lui avais dit qu' en fin de semaine il y avait **[des sujets d' examen]** à bon elle me l' avait dit il y a pas de problèmes hein. hum. [...] bon écoute on on voit cet après-midi il est pas là Prénom4 que je sache un p-. il est pas là mais je vais prévenir Prénom5 que déjà il mette **[ça]** sur le programme de demain matin.. voilà demain matin et qu' on fasse **[ça]**. 

 * s-CHAIN-15: ['u-MENTION-jmuzerelle_1378215229405', 'u-MENTION-jmuzerelle_1378215237960', 'u-MENTION-jmuzerelle_1378215255416', 'u-MENTION-jmuzerelle_1378215262301'] 

	 ça passe avant hein là là là il y a **[des priorités]** **[où]**. oui. t' es bien obligé de foutre **[des priorités]** à **[des priorités]** aussi. 

### File: 054_00000037.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378286685068', 'u-MENTION-jmuzerelle_1378286776562', 'u-MENTION-jmuzerelle_1378286783286', 'u-MENTION-jmuzerelle_1378286798402', 'u-MENTION-jmuzerelle_1378286804158', 'u-MENTION-jmuzerelle_1378286809353', 'u-MENTION-jmuzerelle_1378286956430', 'u-MENTION-jmuzerelle_1378287035335', 'u-MENTION-jmuzerelle_1378287047316'] 

	 oui alors je vais vous passer **[une personne]** **[qui]** se trouve alors attendez **[elle]** est absentée ici mais je vais vous **[la]** passer ailleurs parce qu' **[elle]** est partie à la repro donc **[elle]** s' occupe de ça conservez hein. c' est gentil merci madame. [...] au même numéro. e oui rappelez ici autrement je vais vous donner celui qui est à la repro mais il va pas rester tout le temps à la repro c' est **[une collègue]** **[qui]** est absente donc il **[la]** remplace pour e faire des papiers e des dossiers que les profs ont besoin donc mais il va pas être là tout le temps donc rappelez ici à l' accueil. 

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378286685068', 'u-MENTION-jmuzerelle_1378286776562', 'u-MENTION-jmuzerelle_1378286783286', 'u-MENTION-jmuzerelle_1378286798402', 'u-MENTION-jmuzerelle_1378286804158', 'u-MENTION-jmuzerelle_1378286809353', 'u-MENTION-jmuzerelle_1378286956430', 'u-MENTION-jmuzerelle_1378287035335', 'u-MENTION-jmuzerelle_1378287047316'] 

	 oui alors je vais vous passer **[une personne]** **[qui]** se trouve alors attendez **[elle]** est absentée ici mais je vais vous **[la]** passer ailleurs parce qu' **[elle]** est partie à la repro donc **[elle]** s' occupe de ça conservez hein. c' est gentil merci madame. [...] au même numéro. e oui rappelez ici autrement je vais vous donner celui qui est à la repro mais il va pas rester tout le temps à la repro c' est **[une collègue]** **[qui]** est absente donc il **[la]** remplace pour e faire des papiers e des dossiers que les profs ont besoin donc mais il va pas être là tout le temps donc rappelez ici à l' accueil. 

 * s-CHAIN-2: ['u-MENTION-jmuzerelle_1378286918819', 'u-MENTION-jmuzerelle_1378286927211'] 

	 e oui rappelez ici autrement je vais vous donner **[celui]** **[qui]** est à la repro mais il va pas rester tout le temps à la repro c' est une collègue qui est absente donc il la remplace pour e faire des papiers e des dossiers que les profs ont besoin donc mais il va pas être là tout le temps donc rappelez ici à l' accueil. 

### File: 038_00000027.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1378374458196', 'u-MENTION-jmuzerelle_1378374499076', 'u-MENTION-jmuzerelle_1378374508336', 'u-MENTION-jmuzerelle_1378374521106', 'u-MENTION-jmuzerelle_1378374631796', 'u-MENTION-jmuzerelle_1378374692236', 'u-MENTION-jmuzerelle_1378374784800', 'u-MENTION-jmuzerelle_1378374862641', 'u-MENTION-jmuzerelle_1378374869261', 'u-MENTION-jmuzerelle_1378374838560', 'u-MENTION-jmuzerelle_1378374877611', 'u-MENTION-jmuzerelle_1378374883231', 'u-MENTION-jmuzerelle_1378374889301'] 

	 e tu vas essayer de voir je sais pas avec qui si peut-être avec Prénom2 mais il doit être à la repro- ce soir il doit y avoir **[une réunion]** sur le D A E U **[qui]** doit se faire à l' I U- e rue de la Loi **[c']** est pas ici... non **[c']** est rue de la Loi. oh je je pense parce que. écoute là je sais qui c' est ici oui. ah oui oui ben je te passe la b- la dame elle veut quelques renseignements sur **[ça]**. d' accord ben passe- la moi. [...] non non. e j' aimerais savoir e j' ai **[une réunion]** ce soir e oui ça a ça a coupé ou je sais pas. vous qui avez appelé tout à l' heure. on a été coupé parce que je me renseignais si si **[c']** est bien rue de la Loi. **[c']** est un rue de la Loi hein. oui **[c']** est rue de la Loi **[la réunion]**. et e ben c' est un grand bâtiment **[c']** est **[ce]** sera indiqué. oui **[c']** est indiqué oui oui oui. 

### File: 101_00000066.tei

 * r-ASSOCIATIVE-jmuzerelle_1378308973398: ['u-MENTION-jmuzerelle_1378308401298', 'u-MENTION-jmuzerelle_1378308432030'] 

	 oui au site à Lorient à **[quel numéro]**. **[au 0 2 97 87. 

### File: 058_0000003b.tei

 * r-ASSOCIATIVE-jmuzerelle_1378224895325: ['u-MENTION-jmuzerelle_1378224550221', 'u-MENTION-jmuzerelle_1378224555603'] 

	 oui bonjour madame madame Nom de Brest je vous appelle pour savoir si vous faîtes la capacité en **[droit]**. en **[quelle filière]**. 

