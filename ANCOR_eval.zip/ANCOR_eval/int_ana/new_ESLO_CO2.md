### File: CO2_ESLO_002_C.tei

 * r-ASSOCIATIVE-jmuzerelle_1301513126905: ['u-MENTION-aboyer_1295380400537', 'u-MENTION-aboyer_1295380490690'] 

	 **[la maison]**. je peux demander lequel ?. [...] un un euh assez épais mais enfin un volume. j' y suis et euh où est -ce que vous le gardez à la maison dans **[quelle pièce]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1301513533773: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466660861'] 

	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?. un **[un mot]** ou quelquefois un mot peu usuel alors on cherche l' orthographe ou le sens exact pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301513586664: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466677163'] 

	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?. un un mot ou quelquefois un mot peu usuel alors on cherche **[l' orthographe]** ou le sens exact pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301513621135: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466684373'] 

	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?. un un mot ou quelquefois un mot peu usuel alors on cherche l' orthographe ou **[le sens exact]** pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301513638614: ['u-MENTION-jmuzerelle_1300740713340', 'u-MENTION-aboyer_1296466691834'] 

	 enfin vous cherchez **[quel genre de choses]** le plus souvent ?. un un mot ou quelquefois un mot peu usuel alors on cherche l' orthographe ou le sens exact pour avoir vraiment **[tous les sens d' un mot]** ou quelque chose comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301515545623: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296393376469'] 

	 ah **[quel genre de difficultés]** ?. euh c' est nous avons des **[des complications]** des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301515588735: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296393380119'] 

	 ah **[quel genre de difficultés]** ?. euh c' est nous avons des des complications **[des mots]** qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça. 

 * r-ASSOCIATIVE-jmuzerelle_1301515618634: ['u-MENTION-aboyer_1296393276504', 'u-MENTION-jmuzerelle_1300741204698'] 

	 et **[l' orthographe]** est -ce que c' est important ?. oui. [...] hélas et en français c' est très difficile. ah **[quel genre de difficultés]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1301515727614: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296913066845'] 

	 ah **[quel genre de difficultés]** ?. euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça. je dois dire mon rêve ce serait d' abolir **[le genre]** des règles de grammaire étant donné que ça n' existe pas en anglais. 

 * r-ASSOCIATIVE-jmuzerelle_1301515738992: ['u-MENTION-jmuzerelle_1300741204698', 'u-MENTION-aboyer_1296912939709'] 

	 ah **[quel genre de difficultés]** ?. euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça. je dois dire mon rêve ce serait d' abolir le genre **[des règles de grammaire]** étant donné que ça n' existe pas en anglais. 

 * r-ASSOCIATIVE-jmuzerelle_1301773139320: ['u-MENTION-jmuzerelle_1300914259562', 'u-MENTION-aboyer_1296394421203'] 

	 et vous utilisez **[quel genre de papier]** ?. pour mes brouillons ou pour euh ?. [...] oui et pour la lettre euh elle-même ?. **[du papier à lettres]** euh enfin à lettres correct euh à lettres blanc en général. 

 * r-ASSOCIATIVE-jmuzerelle_1301777225904: ['u-MENTION-jmuzerelle_1301001274816', 'u-MENTION-aboyer_1297335287032'] 

	 enfin **[quel genre d' émissions]** est -ce que vous choisissez ?. quand il y a **[un bon film]** euh quelques variétés mais faut pas en abuser. 

 * r-ASSOCIATIVE-jmuzerelle_1301777242760: ['u-MENTION-jmuzerelle_1301001274816', 'u-MENTION-aboyer_1297335312044'] 

	 enfin **[quel genre d' émissions]** est -ce que vous choisissez ?. quand il y a un bon film euh **[quelques variétés]** mais faut pas en abuser. 

 * r-ASSOCIATIVE-jmuzerelle_1301777441352: ['u-MENTION-jmuzerelle_1301001798443', 'u-MENTION-aboyer_1297337634861'] 

	 hm euh **[quel genre de films]** ?. je suis l' homme très très pacifique mais je vais voir **[des films de guerre]**. 

 * r-ASSOCIATIVE-jmuzerelle_1301943842608: ['u-MENTION-jmuzerelle_1301342395604', 'u-MENTION-aboyer_1297614594288'] 

	 euh **[quel genre de musique]** surtout ?. bah de **[la grande musique]** c' est un grand mot mais enfin euh mettons de la bonne musique. 

 * r-ASSOCIATIVE-jmuzerelle_1301944402213: ['u-MENTION-aboyer_1297615688277', 'u-MENTION-aboyer_1297615848193'] 

	 **[au théâtre]** ?. oui. ici ou à Paris ? Paris toujours la même suite dans les questions quel genre de pièces ou **[quels auteurs]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1301944527687: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616088605'] 

	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?. Paris oui Paris. hum je sais pas bon ben ça je euh en général je je regarde un peu sur les journaux les critiques oui oui **[les pièces horribles]** les pièces noires euh truc euh. 

 * r-ASSOCIATIVE-jmuzerelle_1305058983987: ['u-MENTION-aboyer_1299104642878', 'u-MENTION-aboyer_1299106639547'] 

	 enfin lesquelles sont **[ses activités]** ? **[quels genres de professions]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1358629200972: ['u-MENTION-aboyer_1297115324666', 'u-MENTION-jmuzerelle_1300999217920'] 

	 euh est -ce qu' on prenait **[des sanctions]** ?. oh oui. **[quel genre]** ?. 

 * s-CHAIN-55: ['u-MENTION-jmuzerelle_1301342992274', 'u-MENTION-aboyer_1297616662623'] 

	 ici ou à Paris ? Paris toujours la même suite dans les questions **[quel genre de pièces]** ou quels auteurs ?. Paris oui Paris. [...] oui. essayer de voir **[quelque chose de valable]** bien sûr mais enfin c' est pas pour revenir avec des idées noires quoi. 

### File: CO2_ESLO_003_C.tei

 * r-ASSOCIATIVE-aboyer_1301748853897: ['u-MENTION-jmuzerelle_1295981057115', 'u-MENTION-jmuzerelle_1295981148578'] 

	 mais que euh le le travail de de huit heures par jour pour une femme mariée ayant des enfants pose d' énormes questions on en a parlé j' ai lu **[une série d' articles]** euh je ne sais plus dans **[quel journal]** il y a il y a un an où y avait -il eu ce projet de euh d' une loi sociale sur des de le travail à mi-temps des femmes je crois que ça ce serait une euh une chose qui serait sûrement très intéressante et très payante pour le pour les pour les femmes parce que ça les ça les sort de leur euh de leur vie de la maison qui n' est sûrement pas très euh très payant pour euh pour l' esprit enfin euh qui ne leur donne que peu d' aspirations intellectuelles si vous voulez et je je crois que ce serait très positif ça sûrement très positif maintenant ça se heurte euh aux entreprises et il est facile de concevoir que qu' un patron euh apprécie sûrement peu de ne pas avoir la même secrétaire le matin et l' après-midi parce qu' elles sont euh l' une et l' autre ça met deux fois plus de temps à former et je me rends fort bien compte que j' ai une secrétaire dont je suis parfaitement satisfait et s' il fallait que ce soit une différente que j' aie l' après-midi ça ne me plairait pas ou moins du moins. 

 * r-ASSOCIATIVE-aboyer_1301941732741: ['u-MENTION-jmuzerelle_1296133993397', 'u-MENTION-jmuzerelle_1296134030610'] 

	 vous avez **[une voiture]** évidemment ?. oui. euh. **[quel modèle]** qu' est -ce que vous avez comme voiture ?. 

 * r-ASSOCIATIVE-aboyer_1302206176414: ['u-MENTION-jmuzerelle_1296827485294', 'u-MENTION-jmuzerelle_1296827589883'] 

	 et vous-même quand vous étiez à l' école euh dans **[quelle matière]** étiez- vous le plus fort ?. **[en physique]**. 

 * r-ASSOCIATIVE-aboyer_1302206219953: ['u-MENTION-jmuzerelle_1296827485294', 'u-MENTION-jmuzerelle_1296827696205'] 

	 et vous-même quand vous étiez à l' école euh dans **[quelle matière]** étiez- vous le plus fort ?. en physique. ah oui ? ça change le nombre de témoins qui dit automatiquement **[le français]**. 

 * r-ASSOCIATIVE-aboyer_1302250339864: ['u-MENTION-jmuzerelle_1297089349260', 'u-MENTION-jmuzerelle_1297089629832'] 

	 euhm **[quel genre d' émissions]** surtout ?. bah j' écoute **[les informations sur Europe numéro Un]**. 

 * r-ASSOCIATIVE-aboyer_1302250962976: ['u-MENTION-jmuzerelle_1297090400918', 'u-MENTION-jmuzerelle_1297090571644'] 

	 et **[le cinéma]** vous avez dit que vous y allez. oui pas très souvent pas très souvent. [...] dans quel euh sens ?. de préférence **[quel genre de film]** ?. 

### File: CO2_ESLO_001_C.tei

 * r-ASSOCIATIVE-jmuzerelle_1292184311824: ['u-MENTION-jmuzerelle_1292184079686', 'u-MENTION-jmuzerelle_1292184159546'] 

	 dans **[quelles matières]** aimeriez- vous que vos vos enfants aient été forts à l' école ? pourriez- vous les langues et les maths oui. **[les langues]** et les maths. 

 * r-ASSOCIATIVE-jmuzerelle_1292184319002: ['u-MENTION-jmuzerelle_1292184079686', 'u-MENTION-jmuzerelle_1292184180216'] 

	 dans **[quelles matières]** aimeriez- vous que vos vos enfants aient été forts à l' école ? pourriez- vous les langues et les maths oui. les langues et **[les maths]**. 

 * r-ASSOCIATIVE-jmuzerelle_1293386353215: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385700098'] 

	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre **[orthographe]** euh le sens des mots l' histoire ou la géographie ?. 

 * r-ASSOCIATIVE-jmuzerelle_1293386359863: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385761743'] 

	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh **[le sens des mots]** l' histoire ou la géographie ?. 

 * r-ASSOCIATIVE-jmuzerelle_1293386365755: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385911944'] 

	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh le sens des mots l' **[histoire]** ou la géographie ?. 

 * r-ASSOCIATIVE-jmuzerelle_1293386370631: ['u-MENTION-jmuzerelle_1293385629475', 'u-MENTION-jmuzerelle_1293385955738'] 

	 bon euh là s' il s' agit de dire dans dans **[quelle catégorie]** vous cherchez le plus souvent entre orthographe euh le sens des mots l' histoire ou **[la géographie]** ?. 

 * r-ASSOCIATIVE-jmuzerelle_1294595775708: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294595147201'] 

	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.. [...] et pour quel genre de choses ?. ah bah si on avait mal conjugué **[un verbe]** vous étiez sûr d' avoir deux cent deux cent fois à le faire. 

 * r-ASSOCIATIVE-jmuzerelle_1353950551135: ['u-MENTION-jmuzerelle_1292186508608', 'u-MENTION-jmuzerelle_1292186586927'] 

	 alors d' après vous euh jusqu' à **[quel âge]** est -ce qu' il faut que les enfants euh fassent des études ?. je suis d' accord pour aller jusqu' à **[seize ans]** quand même c' est un minimum de bagages qu' il faut parce que moi j' en souffre de ça. 

 * r-ASSOCIATIVE-jmuzerelle_1358094904408: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294347096244'] 

	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?. **[un stylo]**. 

 * s-CHAIN-76: ['u-MENTION-jmuzerelle_1292100262315', 'u-MENTION-jmuzerelle_1292100299062', 'u-MENTION-jmuzerelle_1292101269216', 'u-MENTION-jmuzerelle_1292102584083', 'u-MENTION-jmuzerelle_1348844990034', 'u-MENTION-jmuzerelle_1292102607143', 'u-MENTION-jmuzerelle_1292102964263', 'u-MENTION-jmuzerelle_1292102772196', 'u-MENTION-jmuzerelle_1292102827081'] 

	 à ce moment -là j' ai fait faire un test euh ici là rue des Grands Champs n' est -ce pas ? pour voir à **[quel métier manuel]** pourrait lui lui convenir. oui oui oui. comprenez- vous ? je l' ai aiguillé vers **[un métier manuel]** il est coiffeur. hum hum. [...] oui. voyez ce qui prouve que même même dans **[des métiers manuels]** on on peut faire sa place j' estime. oui hum. [...] oui oui oui oui oui. moi je vois ça comme ça je le vois de par mon métier on n' est plus capable de trouver de et je vous dis **[tous ces métiers manuels]** **[qui]** sont **[des métiers rudes]** d' accord hein mais **[qui]** sont **[des métiers rémunérateurs]** croyez- moi maintenant hein on a pu dire que avant la guerre on avait vraiment **[des petits métiers]** question salaire maintenant hein euh un bon chef peut gagner cent cinquante cent quatre vingt mille francs par mois. 

 * s-CHAIN-175: ['u-MENTION-jmuzerelle_1294145120769', 'u-MENTION-jmuzerelle_1357320621452', 'u-MENTION-jmuzerelle_1294145351820', 'u-MENTION-jmuzerelle_1294145404615'] 

	 euh dans **[quelle matière]** étiez -vous le plus fort à l' école ?. bah **[c']** est peut-être ça quand même l' orthographe. oui. c' est peut-être un paradoxe mais enfin. et un **[une autre matière]** **[deuxième matière]** aurait été quoi ?. 

 * s-CHAIN-197: ['u-MENTION-jmuzerelle_1294348040361', 'u-MENTION-jmuzerelle_1294421256167'] 

	 stylo à encre stylo à bille ? stylo à encre oui euh hum **[quel type de papier]** utilisez- vous ?. stylo à encre. [...] oui. d' accord et **[quel papier]** ?. 

 * s-CHAIN-207: ['u-MENTION-jmuzerelle_1294591840127', 'u-MENTION-jmuzerelle_1294594682192'] 

	 et votre instituteur est -ce qu' il faisait attention à la façon dont vous parliez ? oui pour **[quel genre de choses]** surtout ?.. [...]. et pour **[quel genre de choses]** ?. 

 * s-CHAIN-262: ['u-MENTION-jmuzerelle_1294346987708', 'u-MENTION-jmuzerelle_1294420807395', 'u-MENTION-jmuzerelle_1294422956773'] 

	 oui euh **[quel instrument]** est -ce que vous utilisez pour écrire à vos amis ?. un stylo. [...] ah oui plus que jamais oui. vous utiliseriez quel euh **[quel euh instrument]** ?. même chose stylo à encre. [...] papier. **[instrument]** et le même papier bon euh hum. 

