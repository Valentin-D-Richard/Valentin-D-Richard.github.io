### File: 1SO0623.tei

 * r-ASSOCIATIVE-jmuzerelle_1340006914739: ['u-MENTION-adrouin_1338899027607', 'u-MENTION-adrouin_1338899076302'] 

	 bonjour je voudrais savoir jusqu' à **[quelle heure]** est ouverte la poste. à côté **[dix-huit heures trente]**. 

### File: 1AG0391.tei

 * r-ASSOCIATIVE-jmuzerelle_1368779394058: ['u-MENTION-sduchon_1329426524269', 'u-MENTION-sduchon_1329426556303'] 

	 bonjour je voudrais savoir si vous avez des listes concernant les pays étrangers les listes d' hôtels auberges de jeunesse e même un appartement pour étudiants **[Barcelone]**. **[quel endroit]**. 

### File: 2AG0361.tei

 * r-ASSOCIATIVE-jmuzerelle_1344348858498: ['u-MENTION-sduchon_1343479738247', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " Carrefour Echirolles " " Carrefour Meylan " et " **[Géant Casino]** " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

 * r-ASSOCIATIVE-jmuzerelle_1344348864223: ['u-MENTION-sduchon_1343479707016', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " Carrefour Echirolles " **[" Carrefour Meylan]** " et " Géant Casino " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

 * r-ASSOCIATIVE-jmuzerelle_1344348870635: ['u-MENTION-sduchon_1343479702422', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " **[Carrefour Echirolles]** " " Carrefour Meylan " et " Géant Casino " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

### File: 1PF0420.tei

 * r-ASSOCIATIVE-gpascault_1353062004214: ['u-MENTION-gpascault_1353061267103', 'u-MENTION-gpascault_1353061561586'] 

	 je voudrais savoir **[quel bus]** faut prendre pour aller jusqu' à Meylan. alors vous allez voir la TAG mademoiselle parce que e je veux pas vous dire de bêtises je crois que c' est **[le quarante-et-un]** hein vous leur demandez voyez c' est ils ont carrément des plans là bas hein ma collègue Prénom va vous dire ça. 

 * s-CHAIN-1: ['u-MENTION-gpascault_1353061267103', 'u-MENTION-jmuzerelle_1370880442373', 'u-MENTION-jmuzerelle_1369228630721'] 

	 je voudrais savoir **[quel bus]** faut prendre pour aller jusqu' à Meylan. alors vous allez voir la TAG mademoiselle parce que e je veux pas vous dire de bêtises je crois que **[c']** est le quarante-et-un hein vous leur demandez voyez c' est ils ont carrément des plans là bas hein ma collègue Prénom va vous dire **[ça]**. 

### File: 1AP0217.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1343422591088', 'u-MENTION-adrouin_1343422724932'] 

	 bonjour c' était pour savoir e si vous savez **[quel bus]** s' arrête aux Véoux. non il faut voir avec la TAG ça hein s' occupe du réseau **[bus]** et tramway. 

### File: 1SB0284.tei

 * s-CHAIN-0: ['u-MENTION-mgodefroy_1331829890597', 'u-MENTION-mgodefroy_1331829908337', 'u-MENTION-mgodefroy_1331830113118'] 

	 s' il vous plaît j' allais vous demander ce e le **[quel bus]** **[il]** amène à Général Mangin. faut voir avec la TAG c' est eux qui s' **[en]** occupent hein. 

### File: 1SB0311.tei

 * r-ASSOCIATIVE-jmuzerelle_1332236869619: ['u-MENTION-mgodefroy_1331836403396', 'u-MENTION-mgodefroy_1331836462601'] 

	 bonjour ce serait pour un renseignement je cherche un appartement la semaine prochaine j' aimerais savoir **[quel jour]** sort " le 38 ".. " le 38 " nous est livré **[le lundi]**. 

### File: 2AG0535.tei

 * r-ASSOCIATIVE-jmuzerelle_1344352409392: ['u-MENTION-sduchon_1343585903404', 'u-MENTION-sduchon_1343585914795'] 

	 e ça dépend pour **[quelles destinations]**. pas **[l' extérieur de Grenoble]** e. 

 * s-CHAIN-3: ['u-MENTION-sduchon_1343585903404', 'u-MENTION-sduchon_1343586235833'] 

	 e ça dépend pour **[quelles destinations]**. pas l' extérieur de Grenoble e. [...] ouais il y a il y a pas un horaire des V F D e complet non. si ils le donnent pas nous on l' a à consulter mais e voilà autocars ou gares hôtelières donc voilà vous avez e pour **[toutes ces destinations]** je vous laisse regarder. 

### File: 1PF0305.tei

 * r-ASSOCIATIVE-gpascault_1351184234507: ['u-MENTION-gpascault_1351178967535', 'u-MENTION-gpascault_1351179053342'] 

	 il faudrait que vous envoyez rapidement à je vous fais un package aussi comme ça vous voyez ce qu' on a à l' Office vous êtes **[quelle société]**. eh ce au fait c' est pas c' est pas moi qui suis de la société c' est c' est moi qui qui mène e c' est **[Thomson C S F]** Thomson C S F. 

 * s-CHAIN-11: ['u-MENTION-gpascault_1351178967535', 'u-MENTION-gpascault_1351179025781', 'u-MENTION-jmuzerelle_1365667036780'] 

	 il faudrait que vous envoyez rapidement à je vous fais un package aussi comme ça vous voyez ce qu' on a à l' Office vous êtes **[quelle société]**. eh ce au fait c' est pas c' est pas moi qui suis de **[la société]** c' est c' est moi qui qui mène e **[c']** est Thomson C S F Thomson C S F. 

