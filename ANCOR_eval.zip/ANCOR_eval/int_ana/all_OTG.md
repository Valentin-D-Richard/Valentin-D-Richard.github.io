### File: 1PF0462.tei

 * s-CHAIN-1: ['u-MENTION-agoudjo_1330080382642', 'u-MENTION-agoudjo_1330080453738', 'u-MENTION-agoudjo_1330080564114', 'u-MENTION-agoudjo_1330080666170'] 

	 nous e c' est pour e organiser une réception pour un mariage on aimerait avoir la liste des **[des bars restaurants]** **[qui]** font des réceptions il y **[en]** a pas on m' a dit de e. j' **[en]** ai un petit peu là dessus hein mais bon c' est pas. 

### File: 1AG0549.tei

 * s-CHAIN-3: ['u-MENTION-sduchon_1329684385040', 'u-MENTION-sduchon_1329684503677'] 

	 ah le Club Alpin Français c' est à la Caisse d' Allocations Familiales aussi CAF je vais vous donner l' adresse vous avez **[la maison mère]** **[qui]** est là au trente-deux avenue Félix Viallet et sinon vous avez une une un petit bureau juste à la M J C des Allobroges c' est en face de la hum du musée de Grenoble. 

### File: 1SO0623.tei

 * r-ASSOCIATIVE-jmuzerelle_1340006914739: ['u-MENTION-adrouin_1338899027607', 'u-MENTION-adrouin_1338899076302'] 

	 bonjour je voudrais savoir jusqu' à **[quelle heure]** est ouverte la poste. à côté **[dix-huit heures trente]**. 

### File: 1PF0306.tei

 * s-CHAIN-3: ['u-MENTION-gpascault_1352123871374', 'u-MENTION-jmuzerelle_1369227479756'] 

	 e j' étais venue chercher un plan de l' agglomération grenobloise on m' avait donné une photocopie parce que c' est pour refaire un plan de direction pour **[des gens]** **[qui]** viennent en réunion à Grenoble seulement je n' ai pas pu l' exploiter en photocopie parce que c' en était déjà une et là donc e. 

### File: 2AP0034.tei

 * s-CHAIN-1: ['u-MENTION-adrouin_1330630060812', 'u-MENTION-adrouin_1330630097379', 'u-MENTION-adrouin_1329947758232', 'u-MENTION-adrouin_1329948289349', 'u-MENTION-adrouin_1330630188238', 'u-MENTION-jmuzerelle_1370424317587', 'u-MENTION-adrouin_1330630464953'] 

	 je voudrais savoir si où est le **[la Caisse d' Epargne de Grenoble]** s' il vous plaît. e en vue d' un retrait ou pour vous adresser au guichet. au guichet. alors il faut aller e en face c' est **[la Caisse d' Epargne]** **[qui]** est en face de la Banque de France boulevard Edouard Rey voyez par ici alors non oups tombera pas plus bas merci donc on est là d' accord boulevard Edouard Rey donc il y a la Banque de France qui est là et **[c']** est en face hein **[la Caisse d' Epargne]** vous passez e oui à pied vous hum coupez par la place de Verdun place Victor Hugo passez place Grenette là après la place Grenette e vous êtes sur des feux vous tombez à des feux place Victor Hugo en face de vous il y a le Quick qui est en face de vous aussi vous empruntez le boulevard de le le trottoir du Quick. je sais pas où c' est.. on **[y]** va à pied ou oui.. [...] oui. et **[la Caisse d' Epargne]** est en face. 

 * s-CHAIN-6: ['u-MENTION-adrouin_1329949327997', 'u-MENTION-adrouin_1329949465808', 'u-MENTION-adrouin_1329949608875', 'u-MENTION-adrouin_1330630281719', 'u-MENTION-adrouin_1330630406183', 'u-MENTION-adrouin_1330630512453', 'u-MENTION-adrouin_1330630605545', 'u-MENTION-adrouin_1330630642049'] 

	 alors il faut aller e en face c' est la Caisse d' Epargne qui est en face de la Banque de France boulevard Edouard Rey voyez par ici alors non oups tombera pas plus bas merci donc on est là d' accord boulevard Edouard Rey donc il y a la Banque de France qui est là et c' est en face hein la Caisse d' Epargne vous passez e oui à pied vous hum coupez par la place de Verdun place Victor Hugo passez place Grenette là après la place Grenette e vous êtes sur des feux vous tombez à des feux place Victor Hugo en face de vous il y a **[le Quick]** **[qui]** est en face de vous aussi vous empruntez le boulevard de le le trottoir **[du Quick]**. je sais pas où c' est. [...] oui. vous traversez vous êtes sur le trottoir **[du Quick]**. oui. vous le longez vous le remontez le boulevard **[du Quick]** jusqu' à arriver au niveau de la Banque de France sur votre droite. oui. [...] ah d' accord. vous tombez en plein dessus en prenant le le trottoir **[du Quick]**. d' accord. **[Quick place Victor Hugo]** **[qui]** est là voilà il y en a vraiment pas pour longtemps d' ici hein. 

 * s-CHAIN-6: ['u-MENTION-adrouin_1329949327997', 'u-MENTION-adrouin_1329949465808', 'u-MENTION-adrouin_1329949608875', 'u-MENTION-adrouin_1330630281719', 'u-MENTION-adrouin_1330630406183', 'u-MENTION-adrouin_1330630512453', 'u-MENTION-adrouin_1330630605545', 'u-MENTION-adrouin_1330630642049'] 

	 alors il faut aller e en face c' est la Caisse d' Epargne qui est en face de la Banque de France boulevard Edouard Rey voyez par ici alors non oups tombera pas plus bas merci donc on est là d' accord boulevard Edouard Rey donc il y a la Banque de France qui est là et c' est en face hein la Caisse d' Epargne vous passez e oui à pied vous hum coupez par la place de Verdun place Victor Hugo passez place Grenette là après la place Grenette e vous êtes sur des feux vous tombez à des feux place Victor Hugo en face de vous il y a **[le Quick]** **[qui]** est en face de vous aussi vous empruntez le boulevard de le le trottoir **[du Quick]**. je sais pas où c' est. [...] oui. vous traversez vous êtes sur le trottoir **[du Quick]**. oui. vous le longez vous le remontez le boulevard **[du Quick]** jusqu' à arriver au niveau de la Banque de France sur votre droite. oui. [...] ah d' accord. vous tombez en plein dessus en prenant le le trottoir **[du Quick]**. d' accord. **[Quick place Victor Hugo]** **[qui]** est là voilà il y en a vraiment pas pour longtemps d' ici hein. 

 * s-CHAIN-9: ['u-MENTION-adrouin_1331046859664', 'u-MENTION-adrouin_1330630023877', 'u-MENTION-adrouin_1329948272517', 'u-MENTION-adrouin_1330630419322'] 

	 alors il faut aller e en face c' est la Caisse d' Epargne qui est en face de **[la Banque de France]** boulevard Edouard Rey voyez par ici alors non oups tombera pas plus bas merci donc on est là d' accord boulevard Edouard Rey donc il y a **[la Banque de France]** **[qui]** est là et c' est en face hein la Caisse d' Epargne vous passez e oui à pied vous hum coupez par la place de Verdun place Victor Hugo passez place Grenette là après la place Grenette e vous êtes sur des feux vous tombez à des feux place Victor Hugo en face de vous il y a le Quick qui est en face de vous aussi vous empruntez le boulevard de le le trottoir du Quick. je sais pas où c' est. [...] oui. vous le longez vous le remontez le boulevard du Quick jusqu' à arriver au niveau de **[la Banque de France]** sur votre droite. 

### File: 1SB0265.tei

 * s-CHAIN-0: ['u-MENTION-mgodefroy_1331125881387', 'u-MENTION-mgodefroy_1331125901197'] 

	 je voudrais avoir des informations sur **[tous les clubs de marche en montagne]** **[qui]** existent sur la région. 

 * s-CHAIN-1: ['u-MENTION-mgodefroy_1331126045191', 'u-MENTION-mgodefroy_1331126066672'] 

	 hum c' est **[" info montagne]** " **[qui]** ah mais je dois avoir la liste maintenant voilà l' école de montagne. 

### File: 1PF0572.tei

 * s-CHAIN-3: ['u-MENTION-agoudjo_1330355692438', 'u-MENTION-jmuzerelle_1330698678294', 'u-MENTION-agoudjo_1330355862774'] 

	 ben moi je suis e donc parisien donc c' est le moment la la la **[la période des des vacances]**.. on fait ce qu' on peut hein. yes ouais c' est difficile avec les enfants de changer de dates donc ça ça **[ça]** démarre juste avant le le premier novembre quoi. c' est sur **[quelle période scolaire]**. 

 * s-CHAIN-8: ['u-MENTION-jmuzerelle_1330698721499', 'u-MENTION-jmuzerelle_1330698806406', 'u-MENTION-jmuzerelle_1330698880594', 'u-MENTION-agoudjo_1330356245639', 'u-MENTION-agoudjo_1330357030455', 'u-MENTION-agoudjo_1330357057918', 'u-MENTION-agoudjo_1330357093070'] 

	 faudrait voir un petit peu déjà téléphoner aux gîtes ruraux hein prendre e relever leur e **[leur numéro de téléphone]** ils ont la centrale pardon hein normalement c- voilà **[79 40 78]** attendez attendez voir **[76 ouais e 66 relevez **[ça]** achetez la plaquette si vous voulez je sais plus e si c' est vingt ou trente francs trente francs voilà.. [...] ouais. et après les gîtes ruraux ont une centrale ils ont un autre bouqu- un autre bouquin au-dessus vous avez donc e la **[un seul numéro]** **[qui]** est **[celui-ci]**. 

### File: 2AP0238.tei

 * s-CHAIN-6: ['u-MENTION-adrouin_1330878330888', 'u-MENTION-adrouin_1330878349309', 'u-MENTION-jmuzerelle_1371130186410'] 

	 elle est dans la grand rue ici au tout début de la rue c' est à dire vous remontez **[la rue de la République]** **[où]** nous sommes actuellement. la grand rue. [...]. on est **[place de la République]** là d' accord. 

 * s-CHAIN-8: ['u-MENTION-adrouin_1330878198163', 'u-MENTION-jmuzerelle_1371040632523', 'u-MENTION-adrouin_1330878223622', 'u-MENTION-jmuzerelle_1331648729725', 'u-MENTION-adrouin_1330878601453', 'u-MENTION-adrouin_1330879698876', 'u-MENTION-adrouin_1330878689835'] 

	 elle est dans **[la grand rue]** ici au tout début de **[la rue]** c' est à dire vous remontez la rue de la République où nous sommes actuellement. **[la grand rue]**. hum. vous allez tomber place Grenette et c' est **[la première rue piétonne]** **[qui]** part de la place Grenette. **[la rue]**. droite **[la grande rue]** et la FNAC elle est par là aussi. 

### File: 1AG0391.tei

 * r-ASSOCIATIVE-jmuzerelle_1368779394058: ['u-MENTION-sduchon_1329426524269', 'u-MENTION-sduchon_1329426556303'] 

	 bonjour je voudrais savoir si vous avez des listes concernant les pays étrangers les listes d' hôtels auberges de jeunesse e même un appartement pour étudiants **[Barcelone]**. **[quel endroit]**. 

 * s-CHAIN-1: ['u-MENTION-sduchon_1329426760523', 'u-MENTION-jmuzerelle_1330360002767', 'u-MENTION-jmuzerelle_1330360095332'] 

	 je vais regarder je peux donner le numéro de **[l' office tourisme d' Espagne à Paris]** **[qui]** vous enverront tout ce que vous désirez **[c']** est à Paris vous leur écrivez vous les appelez ils vous envoient gratuitement tout ce que vous désirez hein. 

### File: 1AP0316.tei

 * s-CHAIN-0: ['u-MENTION-klunari_1331291830968', 'u-MENTION-klunari_1331291833718'] 

	 est ce que vous connaissez ce journal d' **[une association]** **[qui]** s' occupe e de sorties le dimanche e dans des stations de ski e des du Rhône-Alpes. 

 * s-CHAIN-2: ['u-MENTION-adrouin_1340383165099', 'u-MENTION-adrouin_1340383519208', 'u-MENTION-adrouin_1340383682025', 'u-MENTION-jmuzerelle_1369210133009', 'u-MENTION-adrouin_1340383717156', 'u-MENTION-adrouin_1340383731836'] 

	 ben moi je sais que **[les V F D]** l' autocariste le fait e quand on arrive dans la période d' hiver **[il]** le fait avec le forfait plus transport pour un prix général très économique à part **[les V F D]** enfin disons que **[c']** est **[le seul autocariste]** **[qui]** nous laisse ses programmes. 

 * s-CHAIN-4: ['u-MENTION-adrouin_1340384861780', 'u-MENTION-adrouin_1340384876101', 'u-MENTION-adrouin_1340384891873', 'u-MENTION-adrouin_1340384920702', 'u-MENTION-adrouin_1340385207851'] 

	 ils auront peut être 2 ou 3 petites choses aussi et si vraiment ça donne rien je vais vous laisser les coordonnées de **[du Bureau OMSCAG]** **[c']** est **[le bureau]** **[qui]** s' occupe de la vie associative de la ville.. [...] d' accord. voilà clubs de montagne **[le SCAG]** et puis la maison de la randonnée " info montagne ". 

 * s-CHAIN-10: ['u-MENTION-klunari_1331291765937', 'u-MENTION-jmuzerelle_1332165555991', 'u-MENTION-klunari_1331291769093', 'u-MENTION-klunari_1331291772484', 'u-MENTION-klunari_1331291774406', 'u-MENTION-jmuzerelle_1340628105800', 'u-MENTION-klunari_1331291812578', 'u-MENTION-klunari_1331291817062', 'u-MENTION-jmuzerelle_1340628130136', 'u-MENTION-klunari_1331291819437', 'u-MENTION-jmuzerelle_1340628560153', 'u-MENTION-jmuzerelle_1365666672064', 'u-MENTION-adrouin_1340383907663', 'u-MENTION-adrouin_1340383921501', 'u-MENTION-adrouin_1340384035006', 'u-MENTION-jmuzerelle_1340628615517', 'u-MENTION-jmuzerelle_1340628543320', 'u-MENTION-adrouin_1340385138134', 'u-MENTION-adrouin_1340385155123'] 

	 bonjour il y a quelques années il y avait **[une association]** **[qui]** s' appelait **[" Pop ski "]** **[qui]** existait et **[qui]** se réunissait par ici **[ça]** dépendait de Grenoble **[c']** était oui " **[Pop ski]** ". **[" Pop s "]**. " **[Pop ski]** ". est ce que vous connaissez ce journal d' une association qui s' occupe e de sorties le dimanche e dans des stations de ski e des du Rhône-Alpes. [...] donc e après c' est les clubs si les clubs alpins les clubs de montagne. **[c']** était **[un club]** de. hum. je sais pas trop **[c']** était **[une association]** constituée **[qui]** e **[ça]** vous dit rien. moi **[ça]** me dit absolument rien mais e ce que vous. je pourrais me renseigner sur les associations. [...] d' accord. ils pourront vous dire si **[l' association]** existe toujours parce que c' est possible qu' **[elle]** soit peut être plus. 

 * s-CHAIN-10: ['u-MENTION-klunari_1331291765937', 'u-MENTION-jmuzerelle_1332165555991', 'u-MENTION-klunari_1331291769093', 'u-MENTION-klunari_1331291772484', 'u-MENTION-klunari_1331291774406', 'u-MENTION-jmuzerelle_1340628105800', 'u-MENTION-klunari_1331291812578', 'u-MENTION-klunari_1331291817062', 'u-MENTION-jmuzerelle_1340628130136', 'u-MENTION-klunari_1331291819437', 'u-MENTION-jmuzerelle_1340628560153', 'u-MENTION-jmuzerelle_1365666672064', 'u-MENTION-adrouin_1340383907663', 'u-MENTION-adrouin_1340383921501', 'u-MENTION-adrouin_1340384035006', 'u-MENTION-jmuzerelle_1340628615517', 'u-MENTION-jmuzerelle_1340628543320', 'u-MENTION-adrouin_1340385138134', 'u-MENTION-adrouin_1340385155123'] 

	 bonjour il y a quelques années il y avait **[une association]** **[qui]** s' appelait **[" Pop ski "]** **[qui]** existait et **[qui]** se réunissait par ici **[ça]** dépendait de Grenoble **[c']** était oui " **[Pop ski]** ". **[" Pop s "]**. " **[Pop ski]** ". est ce que vous connaissez ce journal d' une association qui s' occupe e de sorties le dimanche e dans des stations de ski e des du Rhône-Alpes. [...] donc e après c' est les clubs si les clubs alpins les clubs de montagne. **[c']** était **[un club]** de. hum. je sais pas trop **[c']** était **[une association]** constituée **[qui]** e **[ça]** vous dit rien. moi **[ça]** me dit absolument rien mais e ce que vous. je pourrais me renseigner sur les associations. [...] d' accord. ils pourront vous dire si **[l' association]** existe toujours parce que c' est possible qu' **[elle]** soit peut être plus. 

 * s-CHAIN-10: ['u-MENTION-klunari_1331291765937', 'u-MENTION-jmuzerelle_1332165555991', 'u-MENTION-klunari_1331291769093', 'u-MENTION-klunari_1331291772484', 'u-MENTION-klunari_1331291774406', 'u-MENTION-jmuzerelle_1340628105800', 'u-MENTION-klunari_1331291812578', 'u-MENTION-klunari_1331291817062', 'u-MENTION-jmuzerelle_1340628130136', 'u-MENTION-klunari_1331291819437', 'u-MENTION-jmuzerelle_1340628560153', 'u-MENTION-jmuzerelle_1365666672064', 'u-MENTION-adrouin_1340383907663', 'u-MENTION-adrouin_1340383921501', 'u-MENTION-adrouin_1340384035006', 'u-MENTION-jmuzerelle_1340628615517', 'u-MENTION-jmuzerelle_1340628543320', 'u-MENTION-adrouin_1340385138134', 'u-MENTION-adrouin_1340385155123'] 

	 bonjour il y a quelques années il y avait **[une association]** **[qui]** s' appelait **[" Pop ski "]** **[qui]** existait et **[qui]** se réunissait par ici **[ça]** dépendait de Grenoble **[c']** était oui " **[Pop ski]** ". **[" Pop s "]**. " **[Pop ski]** ". est ce que vous connaissez ce journal d' une association qui s' occupe e de sorties le dimanche e dans des stations de ski e des du Rhône-Alpes. [...] donc e après c' est les clubs si les clubs alpins les clubs de montagne. **[c']** était **[un club]** de. hum. je sais pas trop **[c']** était **[une association]** constituée **[qui]** e **[ça]** vous dit rien. moi **[ça]** me dit absolument rien mais e ce que vous. je pourrais me renseigner sur les associations. [...] d' accord. ils pourront vous dire si **[l' association]** existe toujours parce que c' est possible qu' **[elle]** soit peut être plus. 

 * s-CHAIN-10: ['u-MENTION-klunari_1331291765937', 'u-MENTION-jmuzerelle_1332165555991', 'u-MENTION-klunari_1331291769093', 'u-MENTION-klunari_1331291772484', 'u-MENTION-klunari_1331291774406', 'u-MENTION-jmuzerelle_1340628105800', 'u-MENTION-klunari_1331291812578', 'u-MENTION-klunari_1331291817062', 'u-MENTION-jmuzerelle_1340628130136', 'u-MENTION-klunari_1331291819437', 'u-MENTION-jmuzerelle_1340628560153', 'u-MENTION-jmuzerelle_1365666672064', 'u-MENTION-adrouin_1340383907663', 'u-MENTION-adrouin_1340383921501', 'u-MENTION-adrouin_1340384035006', 'u-MENTION-jmuzerelle_1340628615517', 'u-MENTION-jmuzerelle_1340628543320', 'u-MENTION-adrouin_1340385138134', 'u-MENTION-adrouin_1340385155123'] 

	 bonjour il y a quelques années il y avait **[une association]** **[qui]** s' appelait **[" Pop ski "]** **[qui]** existait et **[qui]** se réunissait par ici **[ça]** dépendait de Grenoble **[c']** était oui " **[Pop ski]** ". **[" Pop s "]**. " **[Pop ski]** ". est ce que vous connaissez ce journal d' une association qui s' occupe e de sorties le dimanche e dans des stations de ski e des du Rhône-Alpes. [...] donc e après c' est les clubs si les clubs alpins les clubs de montagne. **[c']** était **[un club]** de. hum. je sais pas trop **[c']** était **[une association]** constituée **[qui]** e **[ça]** vous dit rien. moi **[ça]** me dit absolument rien mais e ce que vous. je pourrais me renseigner sur les associations. [...] d' accord. ils pourront vous dire si **[l' association]** existe toujours parce que c' est possible qu' **[elle]** soit peut être plus. 

### File: 2AP0014.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1330538244999', 'u-MENTION-adrouin_1329740826631', 'u-MENTION-adrouin_1329741181063', 'u-MENTION-adrouin_1329772088901', 'u-MENTION-adrouin_1329772186805', 'u-MENTION-adrouin_1331045728056'] 

	 ben vous allez à nouveau vous occupez de moi je crois qu' il y a **[des visites]** **[qui]** sont organisées par l' Office du Tourisme non seulement au niveau de Grenoble.. [...] hum hum. **[qui]** sont faites sur les monuments mais aussi sur des extérieurs des départements ou des choses comme ceci.. [...] voilà. par contre pour l' extérieur maintenant **[c']** est à cette période là **[c']** est pour les groupes uniquement sur demande hein. d' accord. [...] oui. où là il y a des visites pour tout le monde il faut s' inscrire tout simplement mais à cette période là **[c']** est simplement les groupes. 

 * s-CHAIN-2: ['u-MENTION-adrouin_1330538244999', 'u-MENTION-adrouin_1329740826631', 'u-MENTION-adrouin_1329741181063', 'u-MENTION-adrouin_1329772088901', 'u-MENTION-adrouin_1329772186805', 'u-MENTION-adrouin_1331045728056'] 

	 ben vous allez à nouveau vous occupez de moi je crois qu' il y a **[des visites]** **[qui]** sont organisées par l' Office du Tourisme non seulement au niveau de Grenoble.. [...] hum hum. **[qui]** sont faites sur les monuments mais aussi sur des extérieurs des départements ou des choses comme ceci.. [...] voilà. par contre pour l' extérieur maintenant **[c']** est à cette période là **[c']** est pour les groupes uniquement sur demande hein. d' accord. [...] oui. où là il y a des visites pour tout le monde il faut s' inscrire tout simplement mais à cette période là **[c']** est simplement les groupes. 

 * s-CHAIN-8: ['u-MENTION-adrouin_1330627802517', 'u-MENTION-jmuzerelle_1331216535177'] 

	 c' est terminé e il y avait eu je crois une année il y avait eu avec **[les églises romanes]** **[où]** on allait un petit peu plus loin que sur les domaines de l' Isère et tout ça. 

### File: 1SB0164.tei

 * s-CHAIN-2: ['u-MENTION-mgodefroy_1330028426032', 'u-MENTION-mgodefroy_1330028442197'] 

	 bon c' est à côté billetterie il faut vous mettre **[l' accueil]** **[qui]** s' en occupe. 

### File: 1AP0286.tei

 * s-CHAIN-2: ['u-MENTION-klunari_1329064753171', 'u-MENTION-jmuzerelle_1329833977340', 'u-MENTION-jmuzerelle_1340011380958', 'u-MENTION-jmuzerelle_1340011389699'] 

	 pour la Grèce il y a **[un musée]** **[où]** ils font une expo sur les météorites et il me semblait les pierres **[c']** est tout près d' ici.. **[c']** est la Casemate. 

### File: 1AP0133.tei

 * s-CHAIN-1: ['u-MENTION-sduchon_1340549852475', 'u-MENTION-sduchon_1341219263092'] 

	 c' est **[le bureau TAG]** **[qui]** est juste en face. 

### File: 1AG0141.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329078621299', 'u-MENTION-sduchon_1329078402602', 'u-MENTION-sduchon_1329078420293'] 

	 je voudrais avoir une documentation sur Grenoble pour **[des allemands]** **[qui]** vont venir e. je suis très très pauvre hein. **[qui]** connaissent pas alors Grenoble et la région. 

 * s-CHAIN-0: ['u-MENTION-sduchon_1329078621299', 'u-MENTION-sduchon_1329078402602', 'u-MENTION-sduchon_1329078420293'] 

	 je voudrais avoir une documentation sur Grenoble pour **[des allemands]** **[qui]** vont venir e. je suis très très pauvre hein. **[qui]** connaissent pas alors Grenoble et la région. 

### File: 2AP0055.tei

 * s-CHAIN-1: ['u-MENTION-adrouin_1330698868943', 'u-MENTION-adrouin_1330107889244'] 

	 ouais on n' a pas de liste de commerces toute faite après c' est les **[la Chambre de Commerce et d' Industrie]** **[qui]** peut vous fournir une liste hein. 

### File: 1AG0390.tei

 * s-CHAIN-1: ['u-MENTION-sduchon_1329424994625', 'u-MENTION-sduchon_1329425372747'] 

	 oui je n' ai aucune adresse de location faudrait aller à " info montagne " parce que moi j' ai que **[des groupes]** **[qui]** proposent de faire du canoë mais pas de les louer. 

### File: 1PF0447.tei

 * s-CHAIN-6: ['u-MENTION-agoudjo_1329929856080', 'u-MENTION-agoudjo_1329929897069', 'u-MENTION-jmuzerelle_1369661958186', 'u-MENTION-agoudjo_1329929959732', 'u-MENTION-agoudjo_1329930378137', 'u-MENTION-agoudjo_1329930489391'] 

	 je vérifie avec V F D mais si il y a il y a que V F D hein parce que **[les compagnies privées pour individuel]** **[c']** est pas rentable **[elles]** sont **[elles]** sont fichues il y a la la les les départementaux e service public ils assurent pas mal de chose quand même dès qu' on passe sur le le le temps à des trucs utiles le service public il y **[en]** a beaucoup **[qui]** se décarcassent quand même maintenant je sais pas si voilà il me semble bien que j' ai vu Chamonix Chamonix e Aiguille du Midi du premier mai a oui mais au trente septembre. 

### File: 1AP0083.tei

 * s-CHAIN-1: ['u-MENTION-yrives_1330437716046', 'u-MENTION-yrives_1330437779265'] 

	 e **[concert]**. c' est **[quel concert]** parce que. 

### File: 1AP0007.tei

 * s-CHAIN-1: ['u-MENTION-sduchon_1330019958992', 'u-MENTION-sduchon_1330021091166', 'u-MENTION-sduchon_1330021440556', 'u-MENTION-sduchon_1330020077317'] 

	 derrière vous le présentoir il n' y a que **[le " théâtre de Grenoble]** " **[qui]** ne soit pas présent sur le le petit présentoir là je vais vous **[le]** remettre. **[le " théâtre de Grenoble]** ". 

### File: 1AP0245.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1343767419249', 'u-MENTION-adrouin_1343767429123', 'u-MENTION-adrouin_1343767567493'] 

	 la CAF c' est rue trois rue des Alliés donc nous on est là c' est **[la rue]** **[qui]** est ici en face de la Sécurité Sociale le numéro trois **[la rue des Alliés]**. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1343767610346', 'u-MENTION-adrouin_1343767643231'] 

	 vous avez **[le tramway]** **[qui]** passe hein pas très loin ligne A. 

### File: 1AG0554.tei

 * s-CHAIN-2: ['u-MENTION-sduchon_1329762070802', 'u-MENTION-sduchon_1329762036493', 'u-MENTION-sduchon_1329762515648', 'u-MENTION-sduchon_1329762117012'] 

	 et est ce qui il y a est ce qu' il y a quelque chose d' analogue dans le même système que **[la discothèque]** non.. le même système que **[la discothèque]** **[qui]** est à côté. je vais regarder s' il y a. merci. il y a la vidéothèque qui doit être le même principe que **[la discothèque]** puisque ça fait partie des bibliothèques municipales de Grenoble. 

 * s-CHAIN-3: ['u-MENTION-sduchon_1329762089345', 'u-MENTION-sduchon_1329762761405', 'u-MENTION-sduchon_1330427857834', 'u-MENTION-sduchon_1329762779691', 'u-MENTION-sduchon_1330427904548'] 

	 il y a **[la vidéothèque]** **[qui]** doit être le même principe que la discothèque puisque **[ça]** fait partie des bibliothèques municipales de Grenoble. **[qui]** est où ici. ah non à Grand' place. [...] mais c' est pas de votre faute bon et alors ils prêtent ça c' est le même système que les disques hein. oh je pense oui parce que c' est la bibliothèque qui s' en occupe donc e **[ça]** doit être un le même système que les bibliothèques. 

 * s-CHAIN-3: ['u-MENTION-sduchon_1329762089345', 'u-MENTION-sduchon_1329762761405', 'u-MENTION-sduchon_1330427857834', 'u-MENTION-sduchon_1329762779691', 'u-MENTION-sduchon_1330427904548'] 

	 il y a **[la vidéothèque]** **[qui]** doit être le même principe que la discothèque puisque **[ça]** fait partie des bibliothèques municipales de Grenoble. **[qui]** est où ici. ah non à Grand' place. [...] mais c' est pas de votre faute bon et alors ils prêtent ça c' est le même système que les disques hein. oh je pense oui parce que c' est la bibliothèque qui s' en occupe donc e **[ça]** doit être un le même système que les bibliothèques. 

 * s-CHAIN-5: ['u-MENTION-sduchon_1330427749263', 'u-MENTION-sduchon_1329762227618', 'u-MENTION-sduchon_1329762960682', 'u-MENTION-sduchon_1329762287914'] 

	 il y a la vidéothèque qui doit être le même principe que la discothèque puisque ça fait partie **[des bibliothèques municipales de Grenoble]**. qui est où ici. [...] mais c' est pas de votre faute bon et alors ils prêtent ça c' est le même système que les disques hein. oh je pense oui parce que c' est **[la bibliothèque]** **[qui]** s' en occupe donc e ça doit être un le même système que **[les bibliothèques]**. 

### File: 1SB0320.tei

 * s-CHAIN-6: ['u-MENTION-mgodefroy_1332409325925', 'u-MENTION-mgodefroy_1332409386169', 'u-MENTION-mgodefroy_1332409409055', 'u-MENTION-mgodefroy_1332409787990', 'u-MENTION-jmuzerelle_1370352925738', 'u-MENTION-mgodefroy_1332409812170', 'u-MENTION-mgodefroy_1332409844734', 'u-MENTION-mgodefroy_1333572906355', 'u-MENTION-jmuzerelle_1370352952889', 'u-MENTION-mgodefroy_1332409866154', 'u-MENTION-mgodefroy_1333572947923', 'u-MENTION-mgodefroy_1333572993282', 'u-MENTION-mgodefroy_1333573006665', 'u-MENTION-mgodefroy_1333573761376'] 

	 bonjour est ce que vous avez une liste d' agents immobiliers ou pour trouver un logement oui suffit de d' aller à la FNAIM **[rue Vicat]** **[la rue]** **[qui]** traverse le tramway derrière oui. des agences immobilières. et ils répertorient eux e ils ont quatre-vingt pour cent des agences immobilières à leur fédération ça évite en fait de faire le tour de toutes les agences donc ils ont des listes gratuites faut aller les retirer c' est e **[rue Vicat]** **[c']** est **[la petite rue]** **[qui]** est là **[qui]** est là... **[c']** est **[la rue]** **[qui]** passe là. voilà voilà **[la rue]** **[qui]** coupe le tramway là voilà ils sont ils sont à. je vais ils sont trois par là et passent là bas. voilà vous faites le tour hop du de du Crédit Agricole vous traversez la voie du tram vous êtes **[rue Vicat]** et c' est marqué TAI T A I TAI trente-huit en symboles en logo et c' est là. 

 * s-CHAIN-6: ['u-MENTION-mgodefroy_1332409325925', 'u-MENTION-mgodefroy_1332409386169', 'u-MENTION-mgodefroy_1332409409055', 'u-MENTION-mgodefroy_1332409787990', 'u-MENTION-jmuzerelle_1370352925738', 'u-MENTION-mgodefroy_1332409812170', 'u-MENTION-mgodefroy_1332409844734', 'u-MENTION-mgodefroy_1333572906355', 'u-MENTION-jmuzerelle_1370352952889', 'u-MENTION-mgodefroy_1332409866154', 'u-MENTION-mgodefroy_1333572947923', 'u-MENTION-mgodefroy_1333572993282', 'u-MENTION-mgodefroy_1333573006665', 'u-MENTION-mgodefroy_1333573761376'] 

	 bonjour est ce que vous avez une liste d' agents immobiliers ou pour trouver un logement oui suffit de d' aller à la FNAIM **[rue Vicat]** **[la rue]** **[qui]** traverse le tramway derrière oui. des agences immobilières. et ils répertorient eux e ils ont quatre-vingt pour cent des agences immobilières à leur fédération ça évite en fait de faire le tour de toutes les agences donc ils ont des listes gratuites faut aller les retirer c' est e **[rue Vicat]** **[c']** est **[la petite rue]** **[qui]** est là **[qui]** est là... **[c']** est **[la rue]** **[qui]** passe là. voilà voilà **[la rue]** **[qui]** coupe le tramway là voilà ils sont ils sont à. je vais ils sont trois par là et passent là bas. voilà vous faites le tour hop du de du Crédit Agricole vous traversez la voie du tram vous êtes **[rue Vicat]** et c' est marqué TAI T A I TAI trente-huit en symboles en logo et c' est là. 

 * s-CHAIN-6: ['u-MENTION-mgodefroy_1332409325925', 'u-MENTION-mgodefroy_1332409386169', 'u-MENTION-mgodefroy_1332409409055', 'u-MENTION-mgodefroy_1332409787990', 'u-MENTION-jmuzerelle_1370352925738', 'u-MENTION-mgodefroy_1332409812170', 'u-MENTION-mgodefroy_1332409844734', 'u-MENTION-mgodefroy_1333572906355', 'u-MENTION-jmuzerelle_1370352952889', 'u-MENTION-mgodefroy_1332409866154', 'u-MENTION-mgodefroy_1333572947923', 'u-MENTION-mgodefroy_1333572993282', 'u-MENTION-mgodefroy_1333573006665', 'u-MENTION-mgodefroy_1333573761376'] 

	 bonjour est ce que vous avez une liste d' agents immobiliers ou pour trouver un logement oui suffit de d' aller à la FNAIM **[rue Vicat]** **[la rue]** **[qui]** traverse le tramway derrière oui. des agences immobilières. et ils répertorient eux e ils ont quatre-vingt pour cent des agences immobilières à leur fédération ça évite en fait de faire le tour de toutes les agences donc ils ont des listes gratuites faut aller les retirer c' est e **[rue Vicat]** **[c']** est **[la petite rue]** **[qui]** est là **[qui]** est là... **[c']** est **[la rue]** **[qui]** passe là. voilà voilà **[la rue]** **[qui]** coupe le tramway là voilà ils sont ils sont à. je vais ils sont trois par là et passent là bas. voilà vous faites le tour hop du de du Crédit Agricole vous traversez la voie du tram vous êtes **[rue Vicat]** et c' est marqué TAI T A I TAI trente-huit en symboles en logo et c' est là. 

 * s-CHAIN-6: ['u-MENTION-mgodefroy_1332409325925', 'u-MENTION-mgodefroy_1332409386169', 'u-MENTION-mgodefroy_1332409409055', 'u-MENTION-mgodefroy_1332409787990', 'u-MENTION-jmuzerelle_1370352925738', 'u-MENTION-mgodefroy_1332409812170', 'u-MENTION-mgodefroy_1332409844734', 'u-MENTION-mgodefroy_1333572906355', 'u-MENTION-jmuzerelle_1370352952889', 'u-MENTION-mgodefroy_1332409866154', 'u-MENTION-mgodefroy_1333572947923', 'u-MENTION-mgodefroy_1333572993282', 'u-MENTION-mgodefroy_1333573006665', 'u-MENTION-mgodefroy_1333573761376'] 

	 bonjour est ce que vous avez une liste d' agents immobiliers ou pour trouver un logement oui suffit de d' aller à la FNAIM **[rue Vicat]** **[la rue]** **[qui]** traverse le tramway derrière oui. des agences immobilières. et ils répertorient eux e ils ont quatre-vingt pour cent des agences immobilières à leur fédération ça évite en fait de faire le tour de toutes les agences donc ils ont des listes gratuites faut aller les retirer c' est e **[rue Vicat]** **[c']** est **[la petite rue]** **[qui]** est là **[qui]** est là... **[c']** est **[la rue]** **[qui]** passe là. voilà voilà **[la rue]** **[qui]** coupe le tramway là voilà ils sont ils sont à. je vais ils sont trois par là et passent là bas. voilà vous faites le tour hop du de du Crédit Agricole vous traversez la voie du tram vous êtes **[rue Vicat]** et c' est marqué TAI T A I TAI trente-huit en symboles en logo et c' est là. 

 * s-CHAIN-6: ['u-MENTION-mgodefroy_1332409325925', 'u-MENTION-mgodefroy_1332409386169', 'u-MENTION-mgodefroy_1332409409055', 'u-MENTION-mgodefroy_1332409787990', 'u-MENTION-jmuzerelle_1370352925738', 'u-MENTION-mgodefroy_1332409812170', 'u-MENTION-mgodefroy_1332409844734', 'u-MENTION-mgodefroy_1333572906355', 'u-MENTION-jmuzerelle_1370352952889', 'u-MENTION-mgodefroy_1332409866154', 'u-MENTION-mgodefroy_1333572947923', 'u-MENTION-mgodefroy_1333572993282', 'u-MENTION-mgodefroy_1333573006665', 'u-MENTION-mgodefroy_1333573761376'] 

	 bonjour est ce que vous avez une liste d' agents immobiliers ou pour trouver un logement oui suffit de d' aller à la FNAIM **[rue Vicat]** **[la rue]** **[qui]** traverse le tramway derrière oui. des agences immobilières. et ils répertorient eux e ils ont quatre-vingt pour cent des agences immobilières à leur fédération ça évite en fait de faire le tour de toutes les agences donc ils ont des listes gratuites faut aller les retirer c' est e **[rue Vicat]** **[c']** est **[la petite rue]** **[qui]** est là **[qui]** est là... **[c']** est **[la rue]** **[qui]** passe là. voilà voilà **[la rue]** **[qui]** coupe le tramway là voilà ils sont ils sont à. je vais ils sont trois par là et passent là bas. voilà vous faites le tour hop du de du Crédit Agricole vous traversez la voie du tram vous êtes **[rue Vicat]** et c' est marqué TAI T A I TAI trente-huit en symboles en logo et c' est là. 

### File: 1AP0099.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1340297486930', 'u-MENTION-sduchon_1340297260655'] 

	 vous avez **[un magazine]** **[qui]** présente Grenoble un petit peu sous toutes ses. 

### File: 1PF0442.tei

 * s-CHAIN-1: ['u-MENTION-agoudjo_1329672020081', 'u-MENTION-agoudjo_1329672029281', 'u-MENTION-agoudjo_1329672329408', 'u-MENTION-agoudjo_1329672418825', 'u-MENTION-jmuzerelle_1370938805202'] 

	 **[la départementale]** **[qui]** est ici. et vous savez où **[elle]** est. bien sûr **[elle]** est avenue Paul Verlaine les directions régionales à Grenoble elles sont toutes parties depuis la décentralisation donc e c' est tout à Lyon maintenant hein capitale régionale alors vous êtes là et vous allez Paul Verlaine c' est ici donc il faut voir les bus si vous avez pas de voiture hein parce que **[c']** est. 

### File: 2AP0505.tei

 * s-CHAIN-1: ['u-MENTION-adrouin_1337520959292', 'u-MENTION-jmuzerelle_1371048112817', 'u-MENTION-adrouin_1337521028268', 'u-MENTION-adrouin_1337521064388', 'u-MENTION-adrouin_1337521141876'] 

	 alors ça c' est **[le guide]** **[que]** vous voyez derrière moi mais **[qui]** est en vente hein. oui. **[il]** coûte trente francs s' il vous plaît bien sûr. je préfère que vous regardez si **[ça]** correspond à ce que je cherche parce que sinon je connais également le système Cléconfort. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1337605360852', 'u-MENTION-adrouin_1337605377216', 'u-MENTION-jmuzerelle_1337675052398', 'u-MENTION-adrouin_1337605445154', 'u-MENTION-adrouin_1337605589938', 'u-MENTION-adrouin_1337606039795', 'u-MENTION-adrouin_1337605866791'] 

	 ah oui c' est une association à c' est plutôt des meublés des chalets des choses comme ça hein e **[la nouvelle parution]** **[qui]** se forme n' est pas encore ici hein on **[l']** aura on **[l']** aura je pense ça dépend du C D T puisque ce sont eux qui s' **[en]** occupent et je pense qu' il faut attendre la première dizaine d' octobre hein.. [...] plus. il est épuisé et il y a pas encore **[la nouvelle parution]**. les ils ils sont dessus. hum d' accord je vais regarder si c' est ça peut fonctionner hein. **[ça]** va pas tarder oui. 

 * s-CHAIN-4: ['u-MENTION-adrouin_1337605527600', 'u-MENTION-adrouin_1337605573823', 'u-MENTION-adrouin_1337605847244'] 

	 ah oui c' est une association à c' est plutôt des meublés des chalets des choses comme ça hein e la nouvelle parution qui se forme n' est pas encore ici hein on l' aura on l' aura je pense ça dépend du C D T puisque ce sont **[eux]** **[qui]** s' en occupent et je pense qu' il faut attendre la première dizaine d' octobre hein.. [...] il est épuisé et il y a pas encore la nouvelle parution. les ils **[ils]** sont dessus. 

### File: 1PF0358.tei

 * s-CHAIN-2: ['u-MENTION-gpascault_1352208776267', 'u-MENTION-gpascault_1352210041220', 'u-MENTION-gpascault_1352210087798', 'u-MENTION-jmuzerelle_1352212446476'] 

	 ben on est ici e c' est par **[le tramway]** ah oui c' est dans le sens opposé où vous êtes.. [...] je vais mettre une croix. information et Denfert-Rochereau c' est cette rue là donc si vous allez en **[tramway]** ben vous prenez **[le tramway]** **[qui]** allait juste là derrière direction Europôle Fontaine la gare et vous vous arrêtez quand vous entendez Alsace Lorraine vous descendez et vous êtes à côté de la rue Denfert-Rochereau. 

 * s-CHAIN-4: ['u-MENTION-gpascault_1352208984289', 'u-MENTION-jmuzerelle_1352212336620'] 

	 ben on est ici e c' est par le tramway ah oui c' est dans **[le sens opposé]** **[où]** vous êtes. 

### File: 1PF0424.tei

 * s-CHAIN-2: ['u-MENTION-gpascault_1352726917562', 'u-MENTION-gpascault_1352726986305', 'u-MENTION-gpascault_1352727030248', 'u-MENTION-gpascault_1352727633460', 'u-MENTION-gpascault_1352727681177', 'u-MENTION-gpascault_1352727826619', 'u-MENTION-jmuzerelle_1369229033628', 'u-MENTION-jmuzerelle_1369229040604', 'u-MENTION-jmuzerelle_1369229092616'] 

	 ah hé ben à part les cinémas je vois pas e ou sinon **[les Decaux]**.. où ça. **[la maison Decaux]** **[qui]** est rue du Vercors quand vous allez e direction Fontaine. ah d' accord. hein la rue du Vercors c' est la rue qui se trouve e derrière le knack là bas et alors e au numéro trente-sept vous avez **[la maison Decaux]** donc **[qui]** fait tous les affichages des panneaux **[eux]** e peut être vous donneront e des renseignements. près en allant vers. [...] ah oui d' accord. **[c']** est par là je crois que **[c']** est au numéro trente-sept. e ouais d' accord **[c']** est là où passe le cinq d' accord. 

 * s-CHAIN-2: ['u-MENTION-gpascault_1352726917562', 'u-MENTION-gpascault_1352726986305', 'u-MENTION-gpascault_1352727030248', 'u-MENTION-gpascault_1352727633460', 'u-MENTION-gpascault_1352727681177', 'u-MENTION-gpascault_1352727826619', 'u-MENTION-jmuzerelle_1369229033628', 'u-MENTION-jmuzerelle_1369229040604', 'u-MENTION-jmuzerelle_1369229092616'] 

	 ah hé ben à part les cinémas je vois pas e ou sinon **[les Decaux]**.. où ça. **[la maison Decaux]** **[qui]** est rue du Vercors quand vous allez e direction Fontaine. ah d' accord. hein la rue du Vercors c' est la rue qui se trouve e derrière le knack là bas et alors e au numéro trente-sept vous avez **[la maison Decaux]** donc **[qui]** fait tous les affichages des panneaux **[eux]** e peut être vous donneront e des renseignements. près en allant vers. [...] ah oui d' accord. **[c']** est par là je crois que **[c']** est au numéro trente-sept. e ouais d' accord **[c']** est là où passe le cinq d' accord. 

 * s-CHAIN-3: ['u-MENTION-gpascault_1352727044646', 'u-MENTION-gpascault_1352727246289', 'u-MENTION-jmuzerelle_1369228960719', 'u-MENTION-gpascault_1352727357441', 'u-MENTION-gpascault_1352727368699'] 

	 la maison Decaux qui est **[rue du Vercors]** quand vous allez e direction Fontaine. ah d' accord. hein **[la rue du Vercors]** **[c']** est **[la rue]** **[qui]** se trouve e derrière le knack là bas et alors e au numéro trente-sept vous avez la maison Decaux donc qui fait tous les affichages des panneaux eux e peut être vous donneront e des renseignements. 

### File: 1AP0060.tei

 * s-CHAIN-1: ['u-MENTION-sduchon_1330029868905', 'u-MENTION-sduchon_1330030426943', 'u-MENTION-sduchon_1330030444750', 'u-MENTION-sduchon_1330030529337'] 

	 et c' est **[l' avenue Felix Viallet]** **[elle]** est ici c' est **[celle]** **[qui]** mène sur la gare au numéro quarante-sept à peu près par là. 

### File: 1PF0439.tei

 * s-CHAIN-4: ['u-MENTION-agoudjo_1329399021478', 'u-MENTION-agoudjo_1329399070370', 'u-MENTION-agoudjo_1329399174414'] 

	 pour **[les personnes]** donc **[qui]** sont toutes seules ou **[qui]** veulent pas prendre leur voiture ou. 

 * s-CHAIN-4: ['u-MENTION-agoudjo_1329399021478', 'u-MENTION-agoudjo_1329399070370', 'u-MENTION-agoudjo_1329399174414'] 

	 pour **[les personnes]** donc **[qui]** sont toutes seules ou **[qui]** veulent pas prendre leur voiture ou. 

 * s-CHAIN-9: ['u-MENTION-agoudjo_1329398225037', 'u-MENTION-jmuzerelle_1329736512550', 'u-MENTION-agoudjo_1329398417910'] 

	 un périple d' une journée on part de de Vizille jusqu' à **[Brangues]** dans dans l' Isère on **[où]** a eu lieu du du **[le lieu du " rouge et noir]** " et e on a toute une série aussi de de visites qu' on fait en été avec ma collègue Prénom. 

### File: 1AP0096.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1340294683596', 'u-MENTION-sduchon_1340295413613', 'u-MENTION-sduchon_1340294706122', 'u-MENTION-sduchon_1340294765542', 'u-MENTION-sduchon_1340294778553'] 

	 e je cherche **[un guide]** **[où]** on présenterait Grenoble disons **[un petit guide]** un. hum. **[un prospectus]** **[un truc]** comme ça. 

### File: 2AP0144.tei

 * s-CHAIN-4: ['u-MENTION-adrouin_1330702689470', 'u-MENTION-adrouin_1330296121170', 'u-MENTION-adrouin_1330296139703'] 

	 ils sont tombés en rupture de stock **[la communauté de commune]** c' est **[elle]** **[qui]** nous les fournit et donc ils vont le faire rééditer il faut un mois un mois et demi de délai. 

### File: 2AG0361.tei

 * r-ASSOCIATIVE-jmuzerelle_1344348858498: ['u-MENTION-sduchon_1343479738247', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " Carrefour Echirolles " " Carrefour Meylan " et " **[Géant Casino]** " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

 * r-ASSOCIATIVE-jmuzerelle_1344348864223: ['u-MENTION-sduchon_1343479707016', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " Carrefour Echirolles " **[" Carrefour Meylan]** " et " Géant Casino " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

 * r-ASSOCIATIVE-jmuzerelle_1344348870635: ['u-MENTION-sduchon_1343479702422', 'u-MENTION-sduchon_1343467442975'] 

	 alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " **[Carrefour Echirolles]** " " Carrefour Meylan " et " Géant Casino " **[qui]** sont desservis par des bus faut demander aux TAG juste là. 

 * s-CHAIN-0: ['u-MENTION-sduchon_1343467555153', 'u-MENTION-sduchon_1343467390227', 'u-MENTION-sduchon_1343479747613', 'u-MENTION-sduchon_1343479771016'] 

	 je voulais savoir quel était **[le bus]** **[qui]** pourrait me conduire à une grande surface e style e Casino " Géant Casino " des choses comme ça. alors je pense qu' il y a e il faut demander e aux TAG faut demander e ben il y a " Carrefour Echirolles " " Carrefour Meylan " et " Géant Casino " qui sont desservis par **[des bus]** faut demander aux TAG juste là. d' accord. c' est **[les bus]**. 

 * s-CHAIN-2: ['u-MENTION-sduchon_1343479818953', 'u-MENTION-sduchon_1343467494872'] 

	 autrement je voulais savoir e au niveau des **[des hôtels]** **[qui]** existent à Chamonix est ce que pouvez vous avez quelque chose ou. 

### File: 1AP0137.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1340555158183', 'u-MENTION-sduchon_1340554955003'] 

	 je voudrais quelques renseignements j' ai fait cet été un stage dans **[une entreprise]** e **[qui]** a pour le tourisme et le transport. 

### File: 1AP0078.tei

 * s-CHAIN-1: ['u-MENTION-jmuzerelle_1330952606009', 'u-MENTION-jmuzerelle_1330952589603'] 

	 est ce qu' il existe un petit fascicule contenant le nom d' **[endroits]** **[où]** l' on peut faire des réceptions. 

 * s-CHAIN-7: ['u-MENTION-yrives_1330423018984', 'u-MENTION-yrives_1330418439296', 'u-MENTION-yrives_1330423123875', 'u-MENTION-yrives_1330418494234', 'u-MENTION-yrives_1330418530593', 'u-MENTION-yrives_1330418620703', 'u-MENTION-yrives_1330418558609', 'u-MENTION-yrives_1330418708015'] 

	 vous savez les les vous voyez ce que c' est c' est des des espèces d' énormes bâtisses dans un milieu un peu ça c' est sympa aussi ça peut être sympa par contre les gîtes ruraux c' est **[un guide]** **[qui]** est en vente hein.. [...] ça peut être sympa. c' est **[un guide]**. oui e sur tout le département de l' Isère **[qui]** coûte 30 francs donc sachez qu' **[il]** existe et que on **[l']** a nous à ici à l' office un jour si vous êtes décidée à. librairie **[ça]**. vous **[l']** avez aussi. 

 * s-CHAIN-7: ['u-MENTION-yrives_1330423018984', 'u-MENTION-yrives_1330418439296', 'u-MENTION-yrives_1330423123875', 'u-MENTION-yrives_1330418494234', 'u-MENTION-yrives_1330418530593', 'u-MENTION-yrives_1330418620703', 'u-MENTION-yrives_1330418558609', 'u-MENTION-yrives_1330418708015'] 

	 vous savez les les vous voyez ce que c' est c' est des des espèces d' énormes bâtisses dans un milieu un peu ça c' est sympa aussi ça peut être sympa par contre les gîtes ruraux c' est **[un guide]** **[qui]** est en vente hein.. [...] ça peut être sympa. c' est **[un guide]**. oui e sur tout le département de l' Isère **[qui]** coûte 30 francs donc sachez qu' **[il]** existe et que on **[l']** a nous à ici à l' office un jour si vous êtes décidée à. librairie **[ça]**. vous **[l']** avez aussi. 

 * s-CHAIN-9: ['u-MENTION-yrives_1330421254859', 'u-MENTION-jmuzerelle_1340008630619', 'u-MENTION-yrives_1330421304406'] 

	 non c' est pas le mieux des fré des e où on peut pas faire des réceptions quoi que si on peut bon parce que c' est quand même de de **[l' hôtellerie]** hein.. [...] oui bien sûr. e qui ré et **[qui]** **[qui]** reçoit mais on a pas un guide spécial d' insertion non quoi que vous devriez peut être e passer à la Chambre de Commerce et de l' Industrie à Grenoble. 

 * s-CHAIN-9: ['u-MENTION-yrives_1330421254859', 'u-MENTION-jmuzerelle_1340008630619', 'u-MENTION-yrives_1330421304406'] 

	 non c' est pas le mieux des fré des e où on peut pas faire des réceptions quoi que si on peut bon parce que c' est quand même de de **[l' hôtellerie]** hein.. [...] oui bien sûr. e qui ré et **[qui]** **[qui]** reçoit mais on a pas un guide spécial d' insertion non quoi que vous devriez peut être e passer à la Chambre de Commerce et de l' Industrie à Grenoble. 

 * s-CHAIN-11: ['u-MENTION-yrives_1330420869953', 'u-MENTION-yrives_1330420957609', 'u-MENTION-yrives_1330417577812', 'u-MENTION-jmuzerelle_1330952851319', 'u-MENTION-jmuzerelle_1369138815798'] 

	 hum il y a " **[les logis de France]** " vous connaissez " **[les logis de France]** ". ça n' existe pas. c' est pas **[eux]** **[qui]** le c' est. non c' est pas le mieux des fré des e où on peut pas faire des réceptions quoi que si on peut bon parce que **[c']** est quand même de de l' hôtellerie hein. 

### File: 1AG0565.tei

 * s-CHAIN-2: ['u-MENTION-sduchon_1329836106444', 'u-MENTION-jmuzerelle_1368784642899', 'u-MENTION-sduchon_1329836123347', 'u-MENTION-sduchon_1329836281944', 'u-MENTION-sduchon_1329836149369', 'u-MENTION-sduchon_1329836159873'] 

	 **[au TAG]** **[qu']** il faut s' adresser. mais c' est pas c' est **[les TAG]** **[qui]** s' occupent de leur prospectus. comment. il faut voir avec **[les TAG]**. ah **[les TAG]**. 

### File: 1PF0420.tei

 * r-ASSOCIATIVE-gpascault_1353062004214: ['u-MENTION-gpascault_1353061267103', 'u-MENTION-gpascault_1353061561586'] 

	 je voudrais savoir **[quel bus]** faut prendre pour aller jusqu' à Meylan. alors vous allez voir la TAG mademoiselle parce que e je veux pas vous dire de bêtises je crois que c' est **[le quarante-et-un]** hein vous leur demandez voyez c' est ils ont carrément des plans là bas hein ma collègue Prénom va vous dire ça. 

 * s-CHAIN-1: ['u-MENTION-gpascault_1353061267103', 'u-MENTION-jmuzerelle_1370880442373', 'u-MENTION-jmuzerelle_1369228630721'] 

	 je voudrais savoir **[quel bus]** faut prendre pour aller jusqu' à Meylan. alors vous allez voir la TAG mademoiselle parce que e je veux pas vous dire de bêtises je crois que **[c']** est le quarante-et-un hein vous leur demandez voyez c' est ils ont carrément des plans là bas hein ma collègue Prénom va vous dire **[ça]**. 

### File: 1PF0162.tei

 * s-CHAIN-1: ['u-MENTION-gpascault_1351086578391', 'u-MENTION-gpascault_1351086611277', 'u-MENTION-gpascault_1351086783510', 'u-MENTION-gpascault_1351086943181'] 

	 ça c' est fait par e le " Grenoble contact " ça c' est " le petit bulletin " et nous nous avons **[une affiche]** **[qui]** est produit Office du Tourisme **[qui]** a rien avoir encore avec ça et **[qui]** est mensuelle. 

 * s-CHAIN-1: ['u-MENTION-gpascault_1351086578391', 'u-MENTION-gpascault_1351086611277', 'u-MENTION-gpascault_1351086783510', 'u-MENTION-gpascault_1351086943181'] 

	 ça c' est fait par e le " Grenoble contact " ça c' est " le petit bulletin " et nous nous avons **[une affiche]** **[qui]** est produit Office du Tourisme **[qui]** a rien avoir encore avec ça et **[qui]** est mensuelle. 

 * s-CHAIN-1: ['u-MENTION-gpascault_1351086578391', 'u-MENTION-gpascault_1351086611277', 'u-MENTION-gpascault_1351086783510', 'u-MENTION-gpascault_1351086943181'] 

	 ça c' est fait par e le " Grenoble contact " ça c' est " le petit bulletin " et nous nous avons **[une affiche]** **[qui]** est produit Office du Tourisme **[qui]** a rien avoir encore avec ça et **[qui]** est mensuelle. 

### File: 2AP0261.tei

 * s-CHAIN-8: ['u-MENTION-adrouin_1331031045190', 'u-MENTION-adrouin_1331131585344', 'u-MENTION-adrouin_1331031269362'] 

	 et est ce qu' il est possible d' avoir des grandes affiches est ce que vous vendez ou est ce que vous donnez **[des anciennes affiches publicitaires]** ou des. de de quelle e. ben soit de cinéma soit de **[des anciennes publicités]** **[qui]** sont hum voilà assez grandes. 

 * s-CHAIN-9: ['u-MENTION-jmuzerelle_1331220789470', 'u-MENTION-adrouin_1331031718595', 'u-MENTION-adrouin_1331032068868'] 

	 non parce que e moi je pourrai les avoir mais que demain puisque là e alors il faudrait que j' aille directement à e c' est des des **[des amis à nous organisateurs]** **[qui]** nous fournissent ça. hum hum. [...] et moi je peux pas aller là bas chez. vous donneront pas **[ils]** vous donneront pas e non mais il il faudrait c' est aujourd'hui ou jamais. 

### File: 1SB0379.tei

 * s-CHAIN-1: ['u-MENTION-gpascault_1352717875722', 'u-MENTION-gpascault_1352717928766', 'u-MENTION-gpascault_1352718143037', 'u-MENTION-gpascault_1352718159705', 'u-MENTION-gpascault_1352718067610', 'u-MENTION-gpascault_1352724965173'] 

	 est ce que vous avez excusez moi un un document quelque chose sur lequel figure le nouveau logo de Grenoble ce sera un peu gros c' est ma j' ai **[une fille]** **[qui]** fait un exposé là dessus à l' école **[elle]** l' a **[elle]** le mais en petit comme ça e.. **[elle]** l' a. c' est le logo qu' il y a qu' il y a que de l' hôtel de ville celui qu' il a sorti dernièrement là. [...] on le ah moi j' ai vu. ah oui mais ça **[elle]** l' a déjà. 

### File: 1PF0048.tei

 * s-CHAIN-0: ['u-MENTION-gpascault_1350915163115', 'u-MENTION-gpascault_1350915278242', 'u-MENTION-gpascault_1350915298485', 'u-MENTION-gpascault_1350915313684'] 

	 e je voudrais rencontrer **[Prénom Nom]** pour avoir quelques renseignements sur les dépots-vente e possibles. **[Prénom Nom]** c' est e **[la mademoiselle]** **[qui]** est là. 

### File: 2AG0578.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1343588078271', 'u-MENTION-sduchon_1343587921233'] 

	 bonjour je voudrais savoir si vous auriez des documents sur **[les évènements]** **[qui]** vont se passer pour la " science en fête ". 

### File: 1AG0543.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329683063150', 'u-MENTION-sduchon_1329683183426'] 

	 e non j' ai peut être **[l' association]** **[qui]** s' occupe de voilà de clubs de vélo. 

### File: 1AP0079.tei

 * s-CHAIN-0: ['u-MENTION-yrives_1330434637734', 'u-MENTION-yrives_1330434868343', 'u-MENTION-yrives_1330433728453'] 

	 j' aurais voulu savoir si vous faites des les billets à **[ce guichet là]**. sur. les billets e si vous vendez des des tickets de concert ici ou s' il faut que j' aille faire la queue à côté. non e ah ici e **[le guichet billetterie]** **[qui]** est là hein mais ils ont pas tous les toutes les billetteries dans. 

### File: 1AG0618.tei

 * s-CHAIN-2: ['u-MENTION-sduchon_1329932450072', 'u-MENTION-sduchon_1329933129433'] 

	 vous verrez il y a **[un monsieur]** **[qui]** vend des fleurs et il y a Afflelou et juste à côté il y a la discothèque. 

### File: 1SB0408.tei

 * s-CHAIN-0: ['u-MENTION-gpascault_1353072197502', 'u-MENTION-gpascault_1353072300036', 'u-MENTION-gpascault_1353072440683', 'u-MENTION-gpascault_1353072515659', 'u-MENTION-gpascault_1353072557198'] 

	 bonjour je vous appelle à l' aide **[dernière affiche du travail et de la culture]** **[qui]** est superbe puis un paquet de.. [...] ah ben très volontiers oui oui oui génial merci beaucoup. **[le]** voilà **[celle là]** celle **[celle de la rentrée]**. 

### File: 1AP0233.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1343682568213', 'u-MENTION-adrouin_1343683511818', 'u-MENTION-adrouin_1343683584976', 'u-MENTION-adrouin_1343683689287'] 

	 alors oui e le problème enfin le problème la seule chose l' exigence de l' office c' est que on comme tous les offices on fonctionne sous forme d' **[adhésion]** hein. oui. pour pouvoir tourner et pour pouvoir avoir un fichier de d' informations e donc la plupart des associations de Grenoble sont adhérentes à l' office la plupart les écoles les bon tous ceux qu' on veut donc c' est **[une adhésion]** **[qui]** vous coûte trois cent cinquante francs à l' année **[qui]** vous permet donc de figurer parmi nos fichiers informatiques donc dès qu' on a des demandes hop de retranscrire sur vous d' orienter sur vos votre association de déposer librement posters dépliants tout ce que vous jugez nécessaire pour l' information pour mieux vous faire connaître vous avez des prix très très préférentiels après si vous voulez faire une de nos vitrines pour vous présenter vous avez des réductions vos adhérents ont ont une réduction sur des sites touristiques hum des entrées des aux sites si vous recevez des personnes étrangères vous avez droit à deux cent exemplaires de documents gratuits par an alors que nos exemplaires sont gratuits à partir des dix exemplaires. 

 * s-CHAIN-2: ['u-MENTION-adrouin_1343682568213', 'u-MENTION-adrouin_1343683511818', 'u-MENTION-adrouin_1343683584976', 'u-MENTION-adrouin_1343683689287'] 

	 alors oui e le problème enfin le problème la seule chose l' exigence de l' office c' est que on comme tous les offices on fonctionne sous forme d' **[adhésion]** hein. oui. pour pouvoir tourner et pour pouvoir avoir un fichier de d' informations e donc la plupart des associations de Grenoble sont adhérentes à l' office la plupart les écoles les bon tous ceux qu' on veut donc c' est **[une adhésion]** **[qui]** vous coûte trois cent cinquante francs à l' année **[qui]** vous permet donc de figurer parmi nos fichiers informatiques donc dès qu' on a des demandes hop de retranscrire sur vous d' orienter sur vos votre association de déposer librement posters dépliants tout ce que vous jugez nécessaire pour l' information pour mieux vous faire connaître vous avez des prix très très préférentiels après si vous voulez faire une de nos vitrines pour vous présenter vous avez des réductions vos adhérents ont ont une réduction sur des sites touristiques hum des entrées des aux sites si vous recevez des personnes étrangères vous avez droit à deux cent exemplaires de documents gratuits par an alors que nos exemplaires sont gratuits à partir des dix exemplaires. 

### File: 1AP0507.tei

 * s-CHAIN-1: ['u-MENTION-sduchon_1343146486080', 'u-MENTION-jmuzerelle_1343654354505', 'u-MENTION-sduchon_1343145826370', 'u-MENTION-sduchon_1343147275517', 'u-MENTION-sduchon_1343146305942', 'u-MENTION-sduchon_1343146321408'] 

	 e ça se passe comment des c' est **[ma collègue]** **[qu']** il faudrait voir mais **[elle]** est en visite donc e je sais pas je sais pas si je vais pouvoir vous renseigner mais bon e.. [...] le jour même. voilà on vous appelle la **[notre collègue]** **[qui]** est guide et puis elle **[elle]** prend les inscriptions. 

 * s-CHAIN-3: ['u-MENTION-sduchon_1343146822097', 'u-MENTION-jmuzerelle_1343654529569'] 

	 et à mesure des sorties d' accord bon on se présente ici ou **[au lieu]** **[où]** on nous indique et puis vous savez combien de temps ça dure comment ça se passe par exemple quand on a la première c' est promenade de littéraire de Grenoble. 

 * s-CHAIN-8: ['u-MENTION-sduchon_1343147794481', 'u-MENTION-jmuzerelle_1343654888358'] 

	 oui quand vous savez vous venez hein il y **[en]** a même **[qui]** s' inscrivent sur place mais enfin c' est toujours à partir du moment où il y a pas de de de réservations dans l- dans les restaurants de chose comme ça. 

 * s-CHAIN-9: ['u-MENTION-sduchon_1343147184190', 'u-MENTION-jmuzerelle_1370877701434'] 

	 oui quand vous savez vous venez hein il y en a même qui s' inscrivent sur place mais enfin c' est toujours à partir **[du moment]** **[où]** il y a pas de de de réservations dans l- dans les restaurants de chose comme ça. 

### File: 1PF0457.tei

 * s-CHAIN-0: ['u-MENTION-agoudjo_1330000416346', 'u-MENTION-agoudjo_1330001203146', 'u-MENTION-agoudjo_1330001217746'] 

	 e nous -n on distribue des contremarques mais il faudrait demander à **[ma collègue Prénom]** là parce que j' ai su qu' on avait des qu' on avait des tickets e de de de réduction de choses comme ça mais demandez à **[Prénom]** **[qui]** est à côté. 

### File: 1AG0570.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329855725973', 'u-MENTION-sduchon_1329855803755', 'u-MENTION-sduchon_1329855917744'] 

	 bonjour c' est serait pour **[les sports]** sur Grenoble e c' est où que je peux me renseigner e musculation le. **[quels sports]**. e ça c' est les clubs de **[sport]** voilà je vous laisse consulter. 

### File: 1AP0229.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1343424416713', 'u-MENTION-adrouin_1343424443309'] 

	 est ce que vous avez une liste **[des hôpitaux]** **[qui]** se trouvent dans les DOM TOM. 

### File: 1AG0513.tei

 * s-CHAIN-2: ['u-MENTION-sduchon_1329581427350', 'u-MENTION-sduchon_1329581727455'] 

	 hum voilà c' est est est **[3 clubs]** **[qui]** s' occupent de sinon vous allez à l' Office Municipal des Sports vous savez où c' est. 

 * s-CHAIN-4: ['u-MENTION-sduchon_1329581490210', 'u-MENTION-sduchon_1329581516121', 'u-MENTION-sduchon_1329581823495'] 

	 voyez **[la place Saint-André]** **[la place]** **[où]** il y a le palais de justice il y a un petit passage qui s' appelle le passage du palais de justice au 3 il y a l' OMS Office Municipal des Sports ils ont votre adresse. 

 * s-CHAIN-6: ['u-MENTION-sduchon_1329581191125', 'u-MENTION-sduchon_1329581332748', 'u-MENTION-jmuzerelle_1330363485667', 'u-MENTION-jmuzerelle_1330363621858'] 

	 je voudrais faire est ce que vous avez quelque chose sur **[les sports]** sur Grenoble alentours de Grenoble. e **[quels sports]** en particulier. parapente e. hum voilà c' est est est 3 clubs qui s' occupent de sinon vous allez à l' Office Municipal **[des Sports]** vous savez où c' est.. non. voyez la place Saint-André la place où il y a le palais de justice il y a un petit passage qui s' appelle le passage du palais de justice au 3 il y a l' OMS Office Municipal **[des Sports]** ils ont votre adresse. 

 * s-CHAIN-7: ['u-MENTION-sduchon_1329581579757', 'u-MENTION-sduchon_1329581841768', 'u-MENTION-sduchon_1329581592125'] 

	 voyez la place Saint-André la place où il y a le palais de justice il y a **[un petit passage]** **[qui]** s' appelle **[le passage du palais de justice]** au 3 il y a l' OMS Office Municipal des Sports ils ont votre adresse. 

### File: 2SB0166.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1338403456268', 'u-MENTION-adrouin_1338403611317', 'u-MENTION-adrouin_1338403767036', 'u-MENTION-adrouin_1338403909058', 'u-MENTION-adrouin_1338403922038', 'u-MENTION-adrouin_1338403945531', 'u-MENTION-adrouin_1338403628820', 'u-MENTION-jmuzerelle_1371051211809'] 

	 sauriez vous où se trouve **[la place Louis Jouvet]**. non. non. non mais on va regarder sur le plan plus détaillé **[place Louis Jouvet]** M dix-neuf place Louis Jouvet **[place]** avenue de Malherbe alors rue Malherbe avenue de Malherbe **[c']** est ici **[c']** est **[cette petite place là]**. **[ça]** doit être ici. hum d' accord. **[où]** il y a l' église Saint Marc. 

### File: 1AP0219.tei

 * s-CHAIN-3: ['u-MENTION-adrouin_1343423409166', 'u-MENTION-adrouin_1343423476650'] 

	 et puis voir avec **[la Chambre de Commerce et d' Industrie de Grenoble]** **[qui]** pourra peut être vous fournir le reste voilà. 

### File: 1PF0429.tei

 * s-CHAIN-0: ['u-MENTION-agoudjo_1329392324247', 'u-MENTION-agoudjo_1329392510669', 'u-MENTION-agoudjo_1329393727932', 'u-MENTION-jmuzerelle_1329733355479', 'u-MENTION-jmuzerelle_1370937782702'] 

	 j' aurais besoin d' **[un plan de Grenoble]**. **[un plan de Grenoble]** voilà. merci bien. [...] il y a les rues dedans. **[un plan]** e **[qui]** n' est pas exhaustif hein c' est **[un plan si vous voulez d' approche touristique gratuit]** après il faut que vous vous munissiez d' un plan qu' on vend ici. 

### File: 1AG0155.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329156962410', 'u-MENTION-sduchon_1329403186913'] 

	 bonjour je voudrais avoir un renseignement je ne suis pas d' ici je cherche un **[des restaurants]** **[où]** l' on puisse écouter de la musique des choses comme ça où est ce que je pourrais avoir tout ça. 

### File: 1AP0228.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1343424109118', 'u-MENTION-adrouin_1343424172945'] 

	 le programme **[des films]** s' il vous plaît. " le petit bulletin ". e **[qui]** se passe ici. 

### File: 2AP0259.tei

 * s-CHAIN-3: ['u-MENTION-adrouin_1330977826650', 'u-MENTION-adrouin_1330978026673', 'u-MENTION-jmuzerelle_1371041887348', 'u-MENTION-adrouin_1330978059074', 'u-MENTION-adrouin_1331029799390', 'u-MENTION-adrouin_1331029818375'] 

	 bon et il y a **[un tram]** aussi qui e **[qui]** pour repartir là **[qui]**. **[les trams]** **[ils]** font ça hein. **[ils]** font ça ah d' accord. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1330977826650', 'u-MENTION-adrouin_1330978026673', 'u-MENTION-jmuzerelle_1371041887348', 'u-MENTION-adrouin_1330978059074', 'u-MENTION-adrouin_1331029799390', 'u-MENTION-adrouin_1331029818375'] 

	 bon et il y a **[un tram]** aussi qui e **[qui]** pour repartir là **[qui]**. **[les trams]** **[ils]** font ça hein. **[ils]** font ça ah d' accord. 

### File: 1AG0534.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329673116854', 'u-MENTION-jmuzerelle_1330365485708', 'u-MENTION-jmuzerelle_1330365497649'] 

	 **[au TAG]** là **[où]** il y a beaucoup de monde qui attend. **[où]** il y a beaucoup de monde. 

 * s-CHAIN-0: ['u-MENTION-sduchon_1329673116854', 'u-MENTION-jmuzerelle_1330365485708', 'u-MENTION-jmuzerelle_1330365497649'] 

	 **[au TAG]** là **[où]** il y a beaucoup de monde qui attend. **[où]** il y a beaucoup de monde. 

 * s-CHAIN-1: ['u-MENTION-sduchon_1329672987682', 'u-MENTION-sduchon_1329673010199', 'u-MENTION-sduchon_1329673033389'] 

	 au TAG là où il y a beaucoup **[de monde]** **[qui]** attend. où il y a beaucoup **[de monde]**. 

### File: 1AP0217.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1343422591088', 'u-MENTION-adrouin_1343422724932'] 

	 bonjour c' était pour savoir e si vous savez **[quel bus]** s' arrête aux Véoux. non il faut voir avec la TAG ça hein s' occupe du réseau **[bus]** et tramway. 

### File: 2AP0092.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1330701024749', 'u-MENTION-adrouin_1330184029563'] 

	 madame je viens de la part de **[mon père]** le docteur Nom **[qui]** a reçu ça en fait c' est pour avoir un livre enfin c' est expliqué quoi. 

 * s-CHAIN-4: ['u-MENTION-adrouin_1330701225293', 'u-MENTION-adrouin_1330294360398', 'u-MENTION-adrouin_1330294418134', 'u-MENTION-adrouin_1330294513668'] 

	 et e on peut en avoir un en français et en anglais parce qu' en fait on a une **[une fille du Rotary]** **[qui]** est à la maison **[qui]** est américaine et donc c' était pour **[elle]**. 

 * s-CHAIN-4: ['u-MENTION-adrouin_1330701225293', 'u-MENTION-adrouin_1330294360398', 'u-MENTION-adrouin_1330294418134', 'u-MENTION-adrouin_1330294513668'] 

	 et e on peut en avoir un en français et en anglais parce qu' en fait on a une **[une fille du Rotary]** **[qui]** est à la maison **[qui]** est américaine et donc c' était pour **[elle]**. 

### File: 1AG0521.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329671128750', 'u-MENTION-sduchon_1329671291523'] 

	 bonjour je voudrais l' adresse de **[clubs de montagne]** **[qui]** organisent des randonnées e en montagne. 

### File: 1AP0142.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1340726432310', 'u-MENTION-sduchon_1340726822952'] 

	 je voudrais faire de la danse plutôt du modern jazz est ce que vous avez la liste **[des endroits]** **[où]** on peut en faire. 

### File: 1AG0364.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1329166597658', 'u-MENTION-sduchon_1329165831669'] 

	 dites est ce que vous avez un des informations chez **[des expositions]** **[qui]** sont à la bibliothèque actuellement il y a quelque chose sur la Salette et les horaires j' ai vu ça sur un journal c' est pas forcément tous les jours. 

### File: 1PF0470.tei

 * s-CHAIN-4: ['u-MENTION-agoudjo_1330338025709', 'u-MENTION-agoudjo_1330338100958'] 

	 Alpexpo Grand' place comme ça vous pouvez pas vous tromper et alors la CAF il y a deux grands bâtiments blancs et la **[Sécurité Sociale]** **[qui]** est un building assez haut et juste en face un un hum immeuble plus bas qui est blanc aussi qui est la CAF. 

 * s-CHAIN-5: ['u-MENTION-agoudjo_1330338241910', 'u-MENTION-agoudjo_1330338275438', 'u-MENTION-agoudjo_1330338331254'] 

	 Alpexpo Grand' place comme ça vous pouvez pas vous tromper et alors la CAF il y a deux grands bâtiments blancs et la Sécurité Sociale qui est un building assez haut et juste en face un **[un hum immeuble plus bas]** **[qui]** est blanc aussi **[qui]** est la CAF. 

 * s-CHAIN-5: ['u-MENTION-agoudjo_1330338241910', 'u-MENTION-agoudjo_1330338275438', 'u-MENTION-agoudjo_1330338331254'] 

	 Alpexpo Grand' place comme ça vous pouvez pas vous tromper et alors la CAF il y a deux grands bâtiments blancs et la Sécurité Sociale qui est un building assez haut et juste en face un **[un hum immeuble plus bas]** **[qui]** est blanc aussi **[qui]** est la CAF. 

### File: 1PF0464.tei

 * s-CHAIN-2: ['u-MENTION-agoudjo_1330331997382', 'u-MENTION-agoudjo_1330332028126'] 

	 peu importe c' est **[les prix]** **[qui]** le détermineront. 

 * s-CHAIN-3: ['u-MENTION-agoudjo_1330331639173', 'u-MENTION-agoudjo_1330332312662', 'u-MENTION-agoudjo_1330332374621', 'u-MENTION-jmuzerelle_1369665354907', 'u-MENTION-agoudjo_1330332422805', 'u-MENTION-agoudjo_1330332576486', 'u-MENTION-jmuzerelle_1330619298306', 'u-MENTION-agoudjo_1330333075853', 'u-MENTION-agoudjo_1330333097022'] 

	 comment il y a les gîtes ruraux mais les locations de chalets ou d' **[appartements]** enfin. et dans quelles stations monsieur. peu importe c' est les prix qui le détermineront. chalets c' est en général les gîtes hein e **[appartements]** **[ça]** **[c']** est autre chose hein **[ça]** a rien à voir.. ouais. donc e **[appartements]** **[c']** est Cléconfort. il faut f- si je vous donne e le nom d' une e d' un village est ce que comment est ce qu' il y a un catalogue comment ça se passe quoi je. [...] de l' Isère seulement. après il faut appeler e il faut appeler les chaque chaque station pour qu' ils vous communiquent leur leur leur liste de leur liste donc de **[d' appartements]** **[qui]** sont à louer ou de chalets sinon après il y a le catalogue des gîtes qui comprend tout le département et qui sont e chalets uniquement. 

 * s-CHAIN-5: ['u-MENTION-jmuzerelle_1330619086116', 'u-MENTION-agoudjo_1330331906086', 'u-MENTION-agoudjo_1330332966253'] 

	 e j' aurais voulu savoir comment est ce qu' on e comment procéder pour avoir des adresses de de de chalets pour cet hiver pour la fin du mois ce sont **[des stations]** de la. ça c' est les gîtes ruraux ça. comment il y a les gîtes ruraux mais les locations de chalets ou d' appartements enfin. et dans **[quelles stations]** monsieur. peu importe c' est les prix qui le détermineront. [...] de l' Isère seulement. après il faut appeler e il faut appeler les chaque **[chaque station]** pour qu' ils vous communiquent leur leur leur liste de leur liste donc de d' appartements qui sont à louer ou de chalets sinon après il y a le catalogue des gîtes qui comprend tout le département et qui sont e chalets uniquement. 

 * s-CHAIN-6: ['u-MENTION-agoudjo_1330333250373', 'u-MENTION-agoudjo_1330333297080', 'u-MENTION-agoudjo_1330333390013', 'u-MENTION-agoudjo_1330333735669', 'u-MENTION-agoudjo_1330333755565', 'u-MENTION-agoudjo_1330333777870', 'u-MENTION-agoudjo_1330333860717', 'u-MENTION-agoudjo_1330334224725', 'u-MENTION-jmuzerelle_1369665762578'] 

	 après il faut appeler e il faut appeler les chaque chaque station pour qu' ils vous communiquent leur leur leur liste de leur liste donc de d' appartements qui sont à louer ou de chalets sinon après il y a **[le catalogue des gîtes]** **[qui]** comprend tout le département et **[qui]** sont e chalets uniquement.. [...] ouais je sais à l' avance. l' avance ah ben non non non parce que e ils ont **[leur catalogue]** **[qui]** est propre quoi **[qui]** est en vente par les gîtes ruraux **[que]** nous on a en vente d' ailleurs au même tarif qu' eux parce que je vous fais voir. ouais. [...] d' accord. **[ça]** **[c']** est l' I- l' Isère alors vous avez tout dessus je vous laisse feuilleter. 

 * s-CHAIN-6: ['u-MENTION-agoudjo_1330333250373', 'u-MENTION-agoudjo_1330333297080', 'u-MENTION-agoudjo_1330333390013', 'u-MENTION-agoudjo_1330333735669', 'u-MENTION-agoudjo_1330333755565', 'u-MENTION-agoudjo_1330333777870', 'u-MENTION-agoudjo_1330333860717', 'u-MENTION-agoudjo_1330334224725', 'u-MENTION-jmuzerelle_1369665762578'] 

	 après il faut appeler e il faut appeler les chaque chaque station pour qu' ils vous communiquent leur leur leur liste de leur liste donc de d' appartements qui sont à louer ou de chalets sinon après il y a **[le catalogue des gîtes]** **[qui]** comprend tout le département et **[qui]** sont e chalets uniquement.. [...] ouais je sais à l' avance. l' avance ah ben non non non parce que e ils ont **[leur catalogue]** **[qui]** est propre quoi **[qui]** est en vente par les gîtes ruraux **[que]** nous on a en vente d' ailleurs au même tarif qu' eux parce que je vous fais voir. ouais. [...] d' accord. **[ça]** **[c']** est l' I- l' Isère alors vous avez tout dessus je vous laisse feuilleter. 

 * s-CHAIN-6: ['u-MENTION-agoudjo_1330333250373', 'u-MENTION-agoudjo_1330333297080', 'u-MENTION-agoudjo_1330333390013', 'u-MENTION-agoudjo_1330333735669', 'u-MENTION-agoudjo_1330333755565', 'u-MENTION-agoudjo_1330333777870', 'u-MENTION-agoudjo_1330333860717', 'u-MENTION-agoudjo_1330334224725', 'u-MENTION-jmuzerelle_1369665762578'] 

	 après il faut appeler e il faut appeler les chaque chaque station pour qu' ils vous communiquent leur leur leur liste de leur liste donc de d' appartements qui sont à louer ou de chalets sinon après il y a **[le catalogue des gîtes]** **[qui]** comprend tout le département et **[qui]** sont e chalets uniquement.. [...] ouais je sais à l' avance. l' avance ah ben non non non parce que e ils ont **[leur catalogue]** **[qui]** est propre quoi **[qui]** est en vente par les gîtes ruraux **[que]** nous on a en vente d' ailleurs au même tarif qu' eux parce que je vous fais voir. ouais. [...] d' accord. **[ça]** **[c']** est l' I- l' Isère alors vous avez tout dessus je vous laisse feuilleter. 

 * s-CHAIN-6: ['u-MENTION-agoudjo_1330333250373', 'u-MENTION-agoudjo_1330333297080', 'u-MENTION-agoudjo_1330333390013', 'u-MENTION-agoudjo_1330333735669', 'u-MENTION-agoudjo_1330333755565', 'u-MENTION-agoudjo_1330333777870', 'u-MENTION-agoudjo_1330333860717', 'u-MENTION-agoudjo_1330334224725', 'u-MENTION-jmuzerelle_1369665762578'] 

	 après il faut appeler e il faut appeler les chaque chaque station pour qu' ils vous communiquent leur leur leur liste de leur liste donc de d' appartements qui sont à louer ou de chalets sinon après il y a **[le catalogue des gîtes]** **[qui]** comprend tout le département et **[qui]** sont e chalets uniquement.. [...] ouais je sais à l' avance. l' avance ah ben non non non parce que e ils ont **[leur catalogue]** **[qui]** est propre quoi **[qui]** est en vente par les gîtes ruraux **[que]** nous on a en vente d' ailleurs au même tarif qu' eux parce que je vous fais voir. ouais. [...] d' accord. **[ça]** **[c']** est l' I- l' Isère alors vous avez tout dessus je vous laisse feuilleter. 

### File: 1SB0111.tei

 * s-CHAIN-0: ['u-MENTION-mgodefroy_1329572248639', 'u-MENTION-mgodefroy_1329572289484'] 

	 bonjour j' habite dans le quartier de la rue Thiers je voulais savoir s' il y avait **[une M J C]** **[qui]** faisait des cours de de gym de n' importe quoi. 

### File: 2AP0280.tei

 * s-CHAIN-1: ['u-MENTION-adrouin_1331033063259', 'u-MENTION-adrouin_1331033091417'] 

	 e est ce que je pourrais consulter le classeur **[des activités]**. oui pour **[quelles activités]**. 

### File: 1SB0284.tei

 * s-CHAIN-0: ['u-MENTION-mgodefroy_1331829890597', 'u-MENTION-mgodefroy_1331829908337', 'u-MENTION-mgodefroy_1331830113118'] 

	 s' il vous plaît j' allais vous demander ce e le **[quel bus]** **[il]** amène à Général Mangin. faut voir avec la TAG c' est eux qui s' **[en]** occupent hein. 

 * s-CHAIN-1: ['u-MENTION-mgodefroy_1331830007394', 'u-MENTION-mgodefroy_1331829969847'] 

	 faut voir avec la TAG c' est **[eux]** **[qui]** s' en occupent hein. 

### File: 1SB0311.tei

 * r-ASSOCIATIVE-jmuzerelle_1332236869619: ['u-MENTION-mgodefroy_1331836403396', 'u-MENTION-mgodefroy_1331836462601'] 

	 bonjour ce serait pour un renseignement je cherche un appartement la semaine prochaine j' aimerais savoir **[quel jour]** sort " le 38 ".. " le 38 " nous est livré **[le lundi]**. 

### File: 2AG0535.tei

 * r-ASSOCIATIVE-jmuzerelle_1344352409392: ['u-MENTION-sduchon_1343585903404', 'u-MENTION-sduchon_1343585914795'] 

	 e ça dépend pour **[quelles destinations]**. pas **[l' extérieur de Grenoble]** e. 

 * s-CHAIN-3: ['u-MENTION-sduchon_1343585903404', 'u-MENTION-sduchon_1343586235833'] 

	 e ça dépend pour **[quelles destinations]**. pas l' extérieur de Grenoble e. [...] ouais il y a il y a pas un horaire des V F D e complet non. si ils le donnent pas nous on l' a à consulter mais e voilà autocars ou gares hôtelières donc voilà vous avez e pour **[toutes ces destinations]** je vous laisse regarder. 

### File: 1AP0061.tei

 * s-CHAIN-7: ['u-MENTION-sduchon_1330032036854', 'u-MENTION-sduchon_1330034021049'] 

	 ça leur donne **[un support]** **[qui]** nous permet à nous de bien sûr merci au revoir. 

### File: 1SB0403.tei

 * s-CHAIN-2: ['u-MENTION-gpascault_1353138633202', 'u-MENTION-gpascault_1353139428804', 'u-MENTION-jmuzerelle_1353332951821'] 

	 est ce que vous avez **[un plan de Grenoble]** avec le plan du quartier Europôle. j' ai le plan du Grenoble avec e l' indication du quartier Europôle. ouais mais e vous n' avez pas **[un plan]** **[où]** il y aurait les immeubles c' est nul même en petit. 

### File: 4SB0209.tei

 * s-CHAIN-0: ['u-MENTION-adrouin_1338586026290', 'u-MENTION-jmuzerelle_1338888139422', 'u-MENTION-adrouin_1338586210540', 'u-MENTION-adrouin_1338586323802'] 

	 je voudrais e un plan de Grenoble et pour avoir **[des hôtels pension complète]** **[tout ça]**.. [...] pardon. il y a il y a beaucoup **[d' hôtels]** **[qui]** font demi-pension mais pas pension complète il faut regarder. 

 * s-CHAIN-5: ['u-MENTION-adrouin_1338586622298', 'u-MENTION-adrouin_1338586689483'] 

	 là vous avez **[tous les musées]** **[qui]** peuvent se voir. 

### File: 1NR0591.tei

 * s-CHAIN-0: ['u-MENTION-gpascault_1350568993184', 'u-MENTION-gpascault_1350569124897', 'u-MENTION-gpascault_1350569271023'] 

	 est ce que vous avez par hasard un plan de **[l' Isle-d'Abeau]** **[qui]** est dans l' Isère mais **[qui]** n' est pas à Grenoble. 

 * s-CHAIN-0: ['u-MENTION-gpascault_1350568993184', 'u-MENTION-gpascault_1350569124897', 'u-MENTION-gpascault_1350569271023'] 

	 est ce que vous avez par hasard un plan de **[l' Isle-d'Abeau]** **[qui]** est dans l' Isère mais **[qui]** n' est pas à Grenoble. 

### File: 1PF0455.tei

 * s-CHAIN-2: ['u-MENTION-agoudjo_1329999398554', 'u-MENTION-agoudjo_1329999427458'] 

	 il y a **[des gens]** **[qui]** vivent en l' air aussi mais bon. 

### File: 2AG0584.tei

 * s-CHAIN-0: ['u-MENTION-sduchon_1343638467669', 'u-MENTION-sduchon_1343637735281', 'u-MENTION-sduchon_1343637749009', 'u-MENTION-sduchon_1343637809271', 'u-MENTION-sduchon_1343637766122', 'u-MENTION-sduchon_1343637813327'] 

	 j' ai e **[trois amies anglaises]** **[qui]** voudraient venir e passer une année en France. hum. donc dans la région peut être mais **[qui]** voudraient trouver un travail **[elles]** sont.. **[elles]** sont e étudiantes. **[elles]** sont étudiantes. 

 * s-CHAIN-0: ['u-MENTION-sduchon_1343638467669', 'u-MENTION-sduchon_1343637735281', 'u-MENTION-sduchon_1343637749009', 'u-MENTION-sduchon_1343637809271', 'u-MENTION-sduchon_1343637766122', 'u-MENTION-sduchon_1343637813327'] 

	 j' ai e **[trois amies anglaises]** **[qui]** voudraient venir e passer une année en France. hum. donc dans la région peut être mais **[qui]** voudraient trouver un travail **[elles]** sont.. **[elles]** sont e étudiantes. **[elles]** sont étudiantes. 

 * s-CHAIN-2: ['u-MENTION-sduchon_1343638694022', 'u-MENTION-sduchon_1343638783691', 'u-MENTION-sduchon_1343637860689'] 

	 faut voir au CRIJ vous descendez **[rue Voltaire]** au huit C R I J CRIJ oui c' est là entre les deux immeubles il y a **[une rue]** **[qui]** descend. 

### File: 1PF0641.tei

 * s-CHAIN-0: ['u-MENTION-agoudjo_1330360297064', 'u-MENTION-agoudjo_1330360311895', 'u-MENTION-agoudjo_1330360339325', 'u-MENTION-agoudjo_1330360367850'] 

	 e ça serait e pour les stations de ski e donc les l' année dernière quand j' avais vu **[un catalogue]** **[qui]** s' appelait **[" neige "]** et **[qui]** avait les répertoires des petites stations avec des Offices de Tourisme pour la location et caetera. 

 * s-CHAIN-0: ['u-MENTION-agoudjo_1330360297064', 'u-MENTION-agoudjo_1330360311895', 'u-MENTION-agoudjo_1330360339325', 'u-MENTION-agoudjo_1330360367850'] 

	 e ça serait e pour les stations de ski e donc les l' année dernière quand j' avais vu **[un catalogue]** **[qui]** s' appelait **[" neige "]** et **[qui]** avait les répertoires des petites stations avec des Offices de Tourisme pour la location et caetera. 

 * s-CHAIN-3: ['u-MENTION-agoudjo_1330361006145', 'u-MENTION-agoudjo_1330361035865', 'u-MENTION-agoudjo_1330361073238', 'u-MENTION-agoudjo_1330361183899', 'u-MENTION-agoudjo_1330361270490', 'u-MENTION-agoudjo_1330361288247', 'u-MENTION-agoudjo_1330361320028'] 

	 bon il y a **[un catalogue]** **[qui]** est plus général **[où]** il y a tous les départements mais je **[l']** ai pas en ce moment. vous **[l']** avez pas **[celui-là]** donc merci. on va **[l']** avoir hein comme c' est début octobre. 

 * s-CHAIN-3: ['u-MENTION-agoudjo_1330361006145', 'u-MENTION-agoudjo_1330361035865', 'u-MENTION-agoudjo_1330361073238', 'u-MENTION-agoudjo_1330361183899', 'u-MENTION-agoudjo_1330361270490', 'u-MENTION-agoudjo_1330361288247', 'u-MENTION-agoudjo_1330361320028'] 

	 bon il y a **[un catalogue]** **[qui]** est plus général **[où]** il y a tous les départements mais je **[l']** ai pas en ce moment. vous **[l']** avez pas **[celui-là]** donc merci. on va **[l']** avoir hein comme c' est début octobre. 

### File: 1PF0305.tei

 * r-ASSOCIATIVE-gpascault_1351184234507: ['u-MENTION-gpascault_1351178967535', 'u-MENTION-gpascault_1351179053342'] 

	 il faudrait que vous envoyez rapidement à je vous fais un package aussi comme ça vous voyez ce qu' on a à l' Office vous êtes **[quelle société]**. eh ce au fait c' est pas c' est pas moi qui suis de la société c' est c' est moi qui qui mène e c' est **[Thomson C S F]** Thomson C S F. 

 * s-CHAIN-11: ['u-MENTION-gpascault_1351178967535', 'u-MENTION-gpascault_1351179025781', 'u-MENTION-jmuzerelle_1365667036780'] 

	 il faudrait que vous envoyez rapidement à je vous fais un package aussi comme ça vous voyez ce qu' on a à l' Office vous êtes **[quelle société]**. eh ce au fait c' est pas c' est pas moi qui suis de **[la société]** c' est c' est moi qui qui mène e **[c']** est Thomson C S F Thomson C S F. 

 * s-CHAIN-16: ['u-MENTION-gpascault_1351155750494', 'u-MENTION-jmuzerelle_1352206324964'] 

	 e j' étais venu me renseigner sur quelque chose mais j' ai perdu **[l' adresse]** **[où]** on téléphone c' était pour des balades en hélicoptère. 

### File: 2SB0008.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1337978945540', 'u-MENTION-adrouin_1337978959440'] 

	 ainsi qu' un livre de cuisine avec des recettes simples pour **[la personne]** **[qui]** a pas le temps de cuisiner avec l' apport calorique de chaque recette. 

 * s-CHAIN-4: ['u-MENTION-adrouin_1337979178526', 'u-MENTION-adrouin_1337979205078', 'u-MENTION-adrouin_1337979240505'] 

	 j' ai **[des collègues]** là j' ai il y **[en]** a **[qui]** font attention. 

### File: 1PF0416.tei

 * s-CHAIN-0: ['u-MENTION-gpascault_1352471812034', 'u-MENTION-gpascault_1352471917340', 'u-MENTION-gpascault_1352714494659'] 

	 monsieur il y a **[des associations]** de e **[qui]** s' occupent de e de logements pour les étudiants ou. ben je vais vous donner un petit bouquin e que que nous distribuons qui qui sont en fait e ces livres sont adressés à la vie estudiantine. oui. et bon ils permettent de vous donner un certain nombre de e d' adresses d' **[associations]** e. 

 * s-CHAIN-1: ['u-MENTION-gpascault_1352472100845', 'u-MENTION-gpascault_1352472123577', 'u-MENTION-gpascault_1352472178209', 'u-MENTION-gpascault_1352714124609', 'u-MENTION-gpascault_1352714328474'] 

	 ben je vais vous donner **[un petit bouquin]** e que **[que]** nous distribuons qui **[qui]** sont en fait e **[ces livres]** sont adressés à la vie estudiantine. oui. et bon **[ils]** permettent de vous donner un certain nombre de e d' adresses d' associations e. 

### File: 2AP0295.tei

 * s-CHAIN-5: ['u-MENTION-adrouin_1333311423508', 'u-MENTION-adrouin_1333311462129', 'u-MENTION-jmuzerelle_1333361840643', 'u-MENTION-adrouin_1333312332246', 'u-MENTION-adrouin_1333312361378'] 

	 alors ça c' est **[l' Office Municipal des Sports]** l' O M S **[qui]** vous donnera une brochure ils sont e au jardin de ville trois passage du palais de justice. **[il]** est où. du jardin de ville et pour tout ce qui e est chorale. oui alors chorale c' est un classeur qu' on consulte ici sur place hein par contre **[l' O M S]** **[c']** est ouvert que l' après midi de quinze à dix-neuf heures hein. 

### File: 2AP0307.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1335792250489', 'u-MENTION-adrouin_1335792368893', 'u-MENTION-adrouin_1335792383932', 'u-MENTION-adrouin_1335792418673', 'u-MENTION-adrouin_1335792739596'] 

	 si vous voulez nous on a e les **[le guide des gîtes ruraux du département d' Isère]** mais **[c']** est **[un guide]** en vente hein **[qui]** coûte trente francs sinon après il faut vous adresser de toute façon c' est la chambre d' agriculture qui nous **[les]** fournit hein sinon après voir avec eux directement chambre d' agriculture. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1335792557934', 'u-MENTION-adrouin_1335792701017', 'u-MENTION-adrouin_1335792803150', 'u-MENTION-adrouin_1337441309328', 'u-MENTION-adrouin_1337441349442', 'u-MENTION-adrouin_1337441396413', 'u-MENTION-jmuzerelle_1365667811651', 'u-MENTION-adrouin_1337441433356', 'u-MENTION-adrouin_1337442021635'] 

	 si vous voulez nous on a e les le guide des gîtes ruraux du département d' Isère mais c' est un guide en vente hein qui coûte trente francs sinon après il faut vous adresser de toute façon c' est **[la chambre d' agriculture]** **[qui]** nous les fournit hein sinon après voir avec eux directement **[chambre d' agriculture]**. ah d' accord. [...] ce que je souhaite c' est avoir un numéro de téléphone pour pouvoir contacter les des gîtes parce que. **[la Chambre d' Agriculture]** passez par **[la Chambre d' Agriculture]**. un organisme quoi. d' accord. alors regardez **[elle]** doit être indiquée je pense **[la Chambre d' Agriculture]** voilà **[Chambre d' Agriculture]** il est là le numéro. avenue Marcelin Berthelot c' est où. [...] si je peux me déplacer e. voilà D D A c' est ça **[la Chambre d' Agriculture]** on est là le tramway qui passe hein. 

 * s-CHAIN-7: ['u-MENTION-adrouin_1337441619545', 'u-MENTION-adrouin_1337441818131', 'u-MENTION-adrouin_1337441766652', 'u-MENTION-adrouin_1337441852365', 'u-MENTION-adrouin_1337441865556', 'u-MENTION-adrouin_1337442126107'] 

	 **[avenue Marcelin]** Berthelot **[c']** est où. Berthelot **[c']** est **[l' avenue]** **[qui]** est là. si je peux me déplacer e. voilà D D A c' est ça la Chambre d' Agriculture on est là le tramway qui passe hein. ah oui c' est e **[elle]** est praticable par en voiture aussi. 

 * s-CHAIN-8: ['u-MENTION-adrouin_1337442061529', 'u-MENTION-adrouin_1337442075163'] 

	 voilà D D A c' est ça la Chambre d' Agriculture on est là **[le tramway]** **[qui]** passe hein. 

### File: 2AP0292.tei

 * s-CHAIN-2: ['u-MENTION-adrouin_1332083145344', 'u-MENTION-adrouin_1332083221129', 'u-MENTION-adrouin_1332083825239'] 

	 alors bon nous on est là " le 38 " donc ils sont deux rue de Narvik **[la rue]** **[qui]** est là et le " Dauphiné Libéré " ils sont trente-cinq avenue Alsace - Lorraine ça fait à peu près par là trente-cinq. d' accord en suivant toujours tout droit je tourne juste par là. [...] ah d' accord. qui passe devant sinon pour **[la rue de Narvik]** également le tramway vous descendez Albert premier de Belgique par exemple et puis là vous y êtes tout de suite. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1332083519635', 'u-MENTION-adrouin_1332083534455', 'u-MENTION-adrouin_1332083598883', 'u-MENTION-adrouin_1332083630286', 'u-MENTION-adrouin_1332083640675', 'u-MENTION-adrouin_1332083798781', 'u-MENTION-adrouin_1332083926842'] 

	 e oui e là il y a **[le tramway]** **[qui]** vous y mène ah c' est **[le tramway]** c' est **[le tramway]** **[qui]** s' arrête en plein sur l' avenue Alsace - Lorraine.. ah d' accord. **[qui]** passe devant sinon pour la rue de Narvik également **[le tramway]** vous descendez Albert premier de Belgique par exemple et puis là vous y êtes tout de suite. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1332083519635', 'u-MENTION-adrouin_1332083534455', 'u-MENTION-adrouin_1332083598883', 'u-MENTION-adrouin_1332083630286', 'u-MENTION-adrouin_1332083640675', 'u-MENTION-adrouin_1332083798781', 'u-MENTION-adrouin_1332083926842'] 

	 e oui e là il y a **[le tramway]** **[qui]** vous y mène ah c' est **[le tramway]** c' est **[le tramway]** **[qui]** s' arrête en plein sur l' avenue Alsace - Lorraine.. ah d' accord. **[qui]** passe devant sinon pour la rue de Narvik également **[le tramway]** vous descendez Albert premier de Belgique par exemple et puis là vous y êtes tout de suite. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1332083519635', 'u-MENTION-adrouin_1332083534455', 'u-MENTION-adrouin_1332083598883', 'u-MENTION-adrouin_1332083630286', 'u-MENTION-adrouin_1332083640675', 'u-MENTION-adrouin_1332083798781', 'u-MENTION-adrouin_1332083926842'] 

	 e oui e là il y a **[le tramway]** **[qui]** vous y mène ah c' est **[le tramway]** c' est **[le tramway]** **[qui]** s' arrête en plein sur l' avenue Alsace - Lorraine.. ah d' accord. **[qui]** passe devant sinon pour la rue de Narvik également **[le tramway]** vous descendez Albert premier de Belgique par exemple et puis là vous y êtes tout de suite. 

### File: 1AP0384.tei

 * s-CHAIN-6: ['u-MENTION-sduchon_1343062707611', 'u-MENTION-sduchon_1343061219987', 'u-MENTION-jmuzerelle_1370875570739'] 

	 pas les thèmes des expos e mais même je sais pas si non plus le musée vous m' avez dit aussi bien le musée ils nous ont pas laissé leur e d' habitude ils nous envoient une sorte de dossier avec tous **[tous les imprimés]** **[qui]** concernent les expos **[qu']** on n' a pas encore eus. 

### File: 2PF0049.tei

 * s-CHAIN-3: ['u-MENTION-adrouin_1337632410072', 'u-MENTION-adrouin_1337632435702', 'u-MENTION-adrouin_1337632450023', 'u-MENTION-adrouin_1337632501441', 'u-MENTION-adrouin_1337632514014', 'u-MENTION-adrouin_1337632552219'] 

	 j' ai prêté les deux classeurs il faudrait vous mettre d' accord avec **[le monsieur]** **[qui]** est là voyez **[qui]** est en train de penser genre Rodin faudrait que vous mettiez d' accord avec **[lui]** parce qu' **[il]** a les deux classeurs. ah bon je vais aller voir avec **[lui]**. 

 * s-CHAIN-3: ['u-MENTION-adrouin_1337632410072', 'u-MENTION-adrouin_1337632435702', 'u-MENTION-adrouin_1337632450023', 'u-MENTION-adrouin_1337632501441', 'u-MENTION-adrouin_1337632514014', 'u-MENTION-adrouin_1337632552219'] 

	 j' ai prêté les deux classeurs il faudrait vous mettre d' accord avec **[le monsieur]** **[qui]** est là voyez **[qui]** est en train de penser genre Rodin faudrait que vous mettiez d' accord avec **[lui]** parce qu' **[il]** a les deux classeurs. ah bon je vais aller voir avec **[lui]**. 

### File: 3AP0272.tei

 * s-CHAIN-6: ['u-MENTION-adrouin_1338495785819', 'u-MENTION-adrouin_1338495843502', 'u-MENTION-adrouin_1338495879184', 'u-MENTION-adrouin_1338495906202', 'u-MENTION-adrouin_1338495919759'] 

	 alors les gîtes c' est **[un dépliant]** **[qui]** est en vente hein **[c']** est **[un catalogue]** e **[qui]** coûte trente francs sur le département de l' Isère après on a les hôtels donc. 

 * s-CHAIN-6: ['u-MENTION-adrouin_1338495785819', 'u-MENTION-adrouin_1338495843502', 'u-MENTION-adrouin_1338495879184', 'u-MENTION-adrouin_1338495906202', 'u-MENTION-adrouin_1338495919759'] 

	 alors les gîtes c' est **[un dépliant]** **[qui]** est en vente hein **[c']** est **[un catalogue]** e **[qui]** coûte trente francs sur le département de l' Isère après on a les hôtels donc. 

### File: 1PF0650.tei

 * s-CHAIN-4: ['u-MENTION-agoudjo_1330367243474', 'u-MENTION-agoudjo_1330367259298'] 

	 il faudrait voir peut être avec e " la maison de la randonnée " au premier étage " info montagne " **[le bureau]** **[qui]** vient de s' ouvrir. 

