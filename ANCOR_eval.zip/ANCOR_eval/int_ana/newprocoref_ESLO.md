### File: 026_C-5.tei

 * s-CHAIN-109: ['u-MENTION-jmuzerelle_1357753538860', 'u-MENTION-jmuzerelle_1357753898769', 'u-MENTION-jmuzerelle_1357753907505', 'u-MENTION-jmuzerelle_1357753994849', 'u-MENTION-jmuzerelle_1357753973851', 'u-MENTION-jmuzerelle_1357754007267', 'u-MENTION-jmuzerelle_1357754046485', 'u-MENTION-jmuzerelle_1357754033256', 'u-MENTION-jmuzerelle_1357753696779', 'u-MENTION-jmuzerelle_1357753706108'] 

	 et **[quel genre de choses]** y cherchez- vous le plus souvent ? l' orthographe et le sens ou des renseignements l' histoire euh ?. **[n' importe quoi]** au fond. **[n' importe quoi]**. si on parle d' un événement si on parle **[ça]** peut aussi bien être géographie que vous comprenez euh pour situer quelque chose sur une carte moi **[ça]** serait peut-être **[ça]** serait le plus plus souvent moi **[ça]** pour **[ça]** pour des choses de géographie ou on situe mal quelquefois quand on parle d' événements ou quand on parle de je crois que ça serait surtout ben oui. des **[des dates]**. **[des dates]** ou des dates d' auteurs ou des. 

### File: 026_C-4.tei

 * s-CHAIN-63: ['u-MENTION-jmuzerelle_1357654206974', 'u-MENTION-jmuzerelle_1357654362564', 'u-MENTION-jmuzerelle_1357654375244'] 

	 et vous aviez **[quel âge]** à cette époque -là à peu près ?. **[ça]** devait être oh là oh là là je vais retrouver **[ça]** devait être treize ans. 

### File: 012_C-3.tei

 * s-CHAIN-21: ['u-MENTION-jmuzerelle_1361898544809', 'u-MENTION-jmuzerelle_1361898552234', 'u-MENTION-jmuzerelle_1361898692116'] 

	 lesquels dans **[quel journal]** dans **[quel journal]** ?. oui. oh **[n' importe lequel]** et de préférence dans le Canard Enchaîné vous connaissez le Canard Enchaîné ?. 

### File: 029_C-2.tei

 * s-CHAIN-34: ['u-MENTION-jmuzerelle_1363615773941', 'u-MENTION-jmuzerelle_1363615801341', 'u-MENTION-jmuzerelle_1363616242412', 'u-MENTION-jmuzerelle_1363615959151', 'u-MENTION-jmuzerelle_1363615983691', 'u-MENTION-jmuzerelle_1363616067992', 'u-MENTION-jmuzerelle_1363616080562'] 

	 euh dans **[quelles matières]** est- il bon qu' un enfant soit fort à l' école est -ce qu' il y a **[des matières]** **[qui]** vous semblent plus importantes que les autres ou non. certainement pas non certainement pas moi j' apprécie beaucoup l' élève qui est doué en français je me dis qu' il est fin mais en fait c' est un tort c' est un tort parce que je pense que chaque euh chaque enfant ou peut être bon dans **[n' importe quelle matière]** peu importe à partir du moment où il est bon dans **[une matière]** je pense qu' il y a beaucoup plus d' espoir que lorsqu' il est moyen euh dans **[toutes les matières]**.. **[toutes les matières]** hum hum oui d' accord. 

 * s-CHAIN-53: ['u-MENTION-jmuzerelle_1363618002446', 'u-MENTION-jmuzerelle_1363618029777', 'u-MENTION-jmuzerelle_1363618037218', 'u-MENTION-jmuzerelle_1363618044238', 'u-MENTION-jmuzerelle_1363618052397', 'u-MENTION-jmuzerelle_1363618371666', 'u-MENTION-jmuzerelle_1363618411976', 'u-MENTION-jmuzerelle_1363618542608', 'u-MENTION-jmuzerelle_1363619147765', 'u-MENTION-jmuzerelle_1363619244610'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études enfin est -ce qu' il y a **[un âge euh limite]** est -ce que vous voyez **[un âge limite]** ou enfin **[un âge idéal]** ?. mais je crois que c' est pas tellement **[l' âge]** enfin si bien sûr je pense que la loi euh oblige l' enfant à aller jusqu' à seize ans maintenant je crois en France. je crois oui. à seize ans mais il y a des enfants qui n' aiment pas les études et à partir de ce moment -là il n' est pas question d' **[âge]** qu' on les fasse aller jusqu' à seize ans et qu' après on leur fasse faire autre chose puisque mais enfin je sais pas si c' est une question d' **[âge]** joue tellement enfin je sais que j' aurais des enfants personnellement je ferais n' importe quoi pour qu' ils fassent des études euh le plus longtemps possible à la condition que ça les intéresse s' ils ont envie de faire de la danse qu' ils fassent de la danse s' ils sont heureux en faisant de la danse.. [...] hum oui d' accord oui bien sûr. alors c' est pas tellement une question d' **[âge]** c' est une question de de goût de goût et d' aptitudes probablement d' aptitudes probablement avant le goût.. [...] oui enfin oui. oui bien à seize ans **[c']** est très bien. seize ans. seize ans **[c']** est bien non pas dix-huit ans quatorze ans non plus seize ans je trouve que c' est une bonne limite. 

### File: 021_C-6.tei

 * s-CHAIN-0: ['u-MENTION-jmuzerelle_1356685731608', 'u-MENTION-jmuzerelle_1356685841556'] 

	 madame lorsque vous étiez encore à l' école dans **[quelle matière]** étiez vous le plus fort ?. ah **[c']** était littérature. 

### File: 025_C-2.tei

 * s-CHAIN-41: ['u-MENTION-jmuzerelle_1353341132659', 'u-MENTION-jmuzerelle_1353341386339'] 

	 dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh là c' est tellement vieux ah **[c']** était la géographie puis la science. 

### File: 006_C-3.tei

 * s-CHAIN-49: ['u-MENTION-jmuzerelle_1353491245895', 'u-MENTION-jmuzerelle_1353491510917'] 

	 oui enfin dans **[quelle matière français]** étiez- vous le plus fort vous même à l' école monsieur ?. géographie histoire géographie. [...] oui. mais à l' époque **[c']** était pas poussé comme maintenant. 

### File: 013_C-1.tei

 * s-CHAIN-32: ['u-MENTION-jmuzerelle_1366964777232', 'u-MENTION-jmuzerelle_1366965088999', 'u-MENTION-jmuzerelle_1366965449670'] 

	 hm hm et euh oui alors vous commencez vers **[quelle heure]** par exemple le matin ?. ça dépend des jours euh trois jours par semaine à cette époque-ci **[c']** est trois heures moins le quart deux heures et demie trois heures moins lequart de nuit. hm hm. ma femme **[c']** est plus tard elle se lève à six heures six heures et quart mais enfin euh la plupart du temps je fais en moyenne seize heures par jour au moins. 

 * s-CHAIN-91: ['u-MENTION-jmuzerelle_1366979433032', 'u-MENTION-jmuzerelle_1366979448335', 'u-MENTION-jmuzerelle_1366980239588', 'u-MENTION-jmuzerelle_1366980395542', 'u-MENTION-jmuzerelle_1366980492324'] 

	 personnellement vous trouvez que qu' un enfant enfin devrait être à l' école jusqu' à **[quel âge]** ? enfin en général. je crois qu' on n' en sait jamais assez. hm qu' est -ce qui vous paraît euh enfin **[un âge normal de fin de scolarité]** ?. je crois que maintenant dans n' importe quel métier le Certificat d' Etudes est insuffisant je pense que le niveau de troisième ce serait un. [...] par contre il y en a d' autres qui pourraient et puis qui peuvent pas qui peuvent pas y arriver parce que les parents ne peuvent pas les pousser aux études maintenant je sais pas il y a il y a certainement une euh des professeurs qui devraient peut-être plus je sais bien qu' il y a de plus en plus d' élèves dans la classe chaque cas particulier c' est très difficile. évidemment mais en dehors des questions euh financières et caetera vous pensez quand même qu' il serait bon qu' un enfant aille davantage à l' école qu' avant ? vous verriez quoi comme comme **[âge minimum]** enfin ? **[auquel]**. seize ans c' est bien. [...] même chose enfin. je parle de **[l' âge minimum]** euh je ne dis pas que ce serait bien pour tout le monde. 

### File: 019_C-1.tei

 * s-CHAIN-42: ['u-MENTION-jmuzerelle_1365429327932', 'u-MENTION-jmuzerelle_1365429551839', 'u-MENTION-jmuzerelle_1365429701256'] 

	 alors dans **[quelle matière]** aimeriez- vous que les enfants soient forts ? est -ce que vous avez des des z- des avis là-dessus ?. non. [...] enfin. aujourd'hui **[c']** est peut-être la chimie et la physique peut-être. peut-être oui. [...] oui avec les avances techniques n' est -ce pas ?. ça oui tout ça **[c']** est peut-être ça qui serait. 

### File: 096_C-1.tei

 * s-CHAIN-37: ['u-MENTION-jmuzerelle_1363013165111', 'u-MENTION-jmuzerelle_1363013771020'] 

	 et vous personnellement dans **[quelle matière]** vous aimeriez que vos enfants soient forts à l' école ?. **[c']** est les mathématiques euh je crois n- oui. 

 * s-CHAIN-96: ['u-MENTION-jmuzerelle_1363019869583', 'u-MENTION-jmuzerelle_1363019929550', 'u-MENTION-jmuzerelle_1363019946881', 'u-MENTION-jmuzerelle_1363020143021'] 

	 c' est **[quel genre de choses]** ?. c' est quelque ch- je m' **[en]** souviens. vous vous souvenez plus pour **[quel genre de choses]** ? je m' **[en]** rappelle plus moi Ici Paris. 

### File: 024_C-4.tei

 * s-CHAIN-21: ['u-MENTION-agoudjo_1337776303085', 'u-MENTION-agoudjo_1337776424029'] 

	 et vous à l' école vous étiez le plus fort à **[quelle matière]** ?. ah **[c']** était l' ort- euh l' orthographe. 

### File: 019_C-3.tei

 * s-CHAIN-30: ['u-MENTION-jmuzerelle_1365681255608', 'u-MENTION-jmuzerelle_1365681289855'] 

	 et dans **[quelle matière]** étiez- vous le plus fort à l' école ?. euh moi **[c']** était dans le euh l' orthographe les oui. 

### File: 030_C-4.tei

 * s-CHAIN-98: ['u-MENTION-jmuzerelle_1367594345784', 'u-MENTION-jmuzerelle_1376656402890'] 

	 ah oui et dans **[quelles matières]** est- il bon qu' un enfant soit fort ?. moi **[ça]** m' est égal enfin. 

### File: 079_C-2.tei

 * s-CHAIN-6: ['u-MENTION-jmuzerelle_1350050047250', 'u-MENTION-jmuzerelle_1350050059028', 'u-MENTION-jmuzerelle_1350050219303', 'u-MENTION-jmuzerelle_1350050288676', 'u-MENTION-jmuzerelle_1350050365522', 'u-MENTION-jmuzerelle_1350050556310'] 

	 non ? et pour bien apprendre le français **[quels gens]** devrait- il fréquenter ? y a **[des gens]** **[qu']** il devrait fréquenter d' autres qu' il devrait éviter par exemple ?. non je pense pas qu' y ait des personnes à éviter spécialement.. et **[des personnes]** à côtoyer ? pour bien apprendre. je crois qu' il vaut mieux côtoyer **[les personnes]** **[qui]** aient des des connaissances tout de même suffisantes pour leur apprendre quelque chose de d' intelligent. 

### File: 015_C-2.tei

 * s-CHAIN-138: ['u-MENTION-jmuzerelle_1368024158835', 'u-MENTION-jmuzerelle_1368024241048', 'u-MENTION-jmuzerelle_1368024293624'] 

	 hm hm et est -ce que euh enfin pour bien apprendre **[quels gens]** est -ce qu' il faudrait fréquenter ? qui est -ce qu' il faudrait voir ?. **[tout]**. tout **[tout]** ? oui il y a il y a des. 

### File: 025_C-1.tei

 * s-CHAIN-71: ['u-MENTION-agoudjo_1337890168796', 'u-MENTION-agoudjo_1337890804296', 'u-MENTION-agoudjo_1337890857234'] 

	 euh un étranger un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est- il bon qu' il aille d' après vous ?. pour apprendre le français ?. [...] maintenant ça reste à le prouver je sais pas. oui alors Orléans hein pourquoi ? vous croyez qu' il y a vous voyez **[une région]** euh ?. non moi j' **[en]** vois pas. 

### File: 018_C-1.tei

 * s-CHAIN-15: ['u-MENTION-jmuzerelle_1366099541807', 'u-MENTION-jmuzerelle_1366099549763', 'u-MENTION-jmuzerelle_1366099708602', 'u-MENTION-jmuzerelle_1366099714655'] 

	 oh les différences sociales sont je crois les mêmes partout en France vous savez euh il y a ça dépend d' ailleurs quelle couche euh **[quel critère]** sur **[quel critère]** on veut se baser mais si **[c']** est l' argent si **[c']** est la situation c' est je crois que c' est un peu semblable partout en France. 

### File: 078_C-2.tei

 * s-CHAIN-127: ['u-MENTION-jmuzerelle_1358261228124', 'u-MENTION-jmuzerelle_1358261322834', 'u-MENTION-jmuzerelle_1358261331804'] 

	 hm hm hm hm mais euh oui et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. **[c']** est encore variable **[ça]** dépend euh de des des des aptitudes des enfants si un enfant est très doué moi j' estime qu' il ne faut pas hésiter il faut le pousser gratuitement très loin. 

### File: 007_C-1.tei

 * s-CHAIN-83: ['u-MENTION-gpascault_1354809163062', 'u-MENTION-gpascault_1354809389458'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que les enfants continuent leurs études ?. **[tout ça]** dépend si ils réussissent ou non si ils ne réussissent pas je pense que c' est vraiment du temps perdu de vouloir à toute force qu' ils restent en classe pour dire euh ils sont étudiants ou ils sont lycéens d' autre part si ils sont des enfants doués si les parents ont les moyens ce qui est aussi. 

### File: 096_C-2.tei

 * s-CHAIN-74: ['u-MENTION-jmuzerelle_1363095053541', 'u-MENTION-jmuzerelle_1377262766754'] 

	 on vous l' avait offert ? ou on à **[quelle occasion]** ?.. oh **[c']** était pour un Noël ou le Jour de l' an comme ça. 

 * s-CHAIN-75: ['u-MENTION-jmuzerelle_1363103955880', 'u-MENTION-jmuzerelle_1377266041386', 'u-MENTION-jmuzerelle_1377266162026'] 

	 et ils avaient été à l' école dans une des dans quel euh dans **[quel type d' école]** c' était une école publique privée ?. **[c']** était une petite école de campagne sûrement. oui. [...] une école publique oui. oh oui et vous **[c']** était une école publique oui oui oui. 

### File: 020_C-2.tei

 * s-CHAIN-49: ['u-MENTION-jmuzerelle_1360836351016', 'u-MENTION-jmuzerelle_1360836377954', 'u-MENTION-jmuzerelle_1360836649608', 'u-MENTION-jmuzerelle_1360836657141'] 

	 et jusqu' à **[quel âge]** est -ce que vous pensez qu' il faudrait que les enfants continuent leurs études je veux dire **[l' âge euh minimum]** ?. alors je crois que maintenant **[c']** est seize ans hein ? seize ans je crois que c' est c' est pas mal seize ans et parce que. **[c']** est seize ans oui voilà seize ans. 

### File: 030_C-2.tei

 * s-CHAIN-87: ['u-MENTION-jmuzerelle_1367422171702', 'u-MENTION-jmuzerelle_1367422833356', 'u-MENTION-jmuzerelle_1367423027307', 'u-MENTION-jmuzerelle_1367423044427', 'u-MENTION-jmuzerelle_1367423096757', 'u-MENTION-jmuzerelle_1367423191947'] 

	 un étranger veut venir en France pour apprendre le français dans **[quelle région]** est -ce que vous est -ce qu' il doit aller d' après vous ?. je vais vous dire la région du Val-de-Loire parce qu' on soit disant l' accent est le meilleur enfin l' accent est le le français est le mieux parlé oui non je pense que à Paris quand même une ville assez idéale pour euh un étranger. [...] oui. pourquoi ? non je trouve que tout est intéressant mais il faudrait mieux ne pas se limiter à **[une région de France]**. hm hm. [...] interview to be continued on the twenty-fourth of june the first part of the interview was on the twentieth of june. la dernière fois à enfin **[les endroits de France]** **[où]** devrait aller un étranger. oui. [...] oui. alors euh nous avions dit je crois vous aviez dit Paris comme **[ville]** euh. comme priorité oui. oui et j' avais dit enfin je vous avais demandé s' il y avait des endroits à éviter euh je ne sais pas si vous n' en voyez pas si. à éviter non pour moi non mais je pense qu' il vaut mieux ne pas se cantonner à **[un seul endroit de la France]** par exemple il vaut mieux pour avoir une meilleure idée puis si c' est pour l' accent ça dépend enfin si c' est pour l' accent il vaut mieux aussi euh peut-être être dans le centre de la France enfin. 

### File: 019_C-2.tei

 * s-CHAIN-50: ['u-MENTION-jmuzerelle_1365597836590', 'u-MENTION-jmuzerelle_1365597859132'] 

	 oui oui oui et depuis depuis quand est -ce que vous l' avez eu ? à **[quelle occasion]** est -ce que vous vous souvenez ?. oh ma foi non je m' **[en]** souviens pas oh non il date de vingt-trois ou vingt-quatre je crois. 

 * s-CHAIN-52: ['u-MENTION-jmuzerelle_1365598083929', 'u-MENTION-jmuzerelle_1365598117126'] 

	 ah bon ? et alors **[quel genre de choses]** y cherchez- vous le plus souvent ? **[c']** est l' orthographe le sens du mot s- ou quoi ?. 

### File: 026_C-3.tei

 * s-CHAIN-42: ['u-MENTION-jmuzerelle_1357569591153', 'u-MENTION-jmuzerelle_1357569672749', 'u-MENTION-jmuzerelle_1357569845816', 'u-MENTION-jmuzerelle_1357570581241', 'u-MENTION-jmuzerelle_1357570813904'] 

	 euh un étranger veut venir en France madame pour apprendre le français euh dans **[quelle région de la France]** est -ce que ?. vous pouvez arrêter non un petit peu ?. oui oui pardon. non parce que si vous avez dans **[quelle région]** oui vous reposez votre question. un étranger qui veut venir en France pour apprendre le français. hm. euh dans **[quelle région]** est -ce qu' il doit aller d' après vous ?. en France on prétend que c' est à Tours surtout dans l' Indre-et-Loire et peut -être l' Orléanais. [...] oui oui. dans **[un endroit]** **[où]** y a susceptible d' entendre parler correctement le français. 

### File: 007_C-2.tei

 * s-CHAIN-99: ['u-MENTION-gpascault_1359644325422', 'u-MENTION-jmuzerelle_1372411721073'] 

	 très peu de temps libre euh je leur demande déjà **[quel jour]** il pourrait être libre. hm hm. si ça **[ça]** pouvait correspondre avec euh les horaires de mon mari et les miens je leur dis que j' aurais plaisir à les recevoir euh un peu pas trop longtemps. 

### File: 026_C-2.tei

 * s-CHAIN-16: ['u-MENTION-jmuzerelle_1357209839204', 'u-MENTION-jmuzerelle_1376406159681', 'u-MENTION-jmuzerelle_1357210528788', 'u-MENTION-jmuzerelle_1357210515200', 'u-MENTION-jmuzerelle_1357210533624', 'u-MENTION-jmuzerelle_1357210540785', 'u-MENTION-jmuzerelle_1357210549848', 'u-MENTION-jmuzerelle_1357210555059', 'u-MENTION-jmuzerelle_1357210563405'] 

	 et jusqu' à **[quel âge]** est -ce qu' il faudrait que l' enfant euh continue ses études ?. en France maintenant c' est obligatoirement seize ans. [...] mais en France de toute façon c' est obligatoire maintenant c' est seize ans. oui et vous enfin je crois que y a un projet en France ici pour augmenter enfin pour euh **[l' âge de la fin de la sco- scolarité]** oui mais ils n' ont pas un projet pour euh **[le]** mettre à s- à dix-huit ans ?. **[c']** est seize ans. **[c']** était quatorze ans et **[c']** est passé seize ans. **[c']** est **[c']** était quatorze ans ici. **[c']** était quatorze ans. 

### File: 024_C-3.tei

 * s-CHAIN-76: ['u-MENTION-agoudjo_1337676539162', 'u-MENTION-agoudjo_1337676601471'] 

	 bien il s' est passé un un malaise qui a pris qui a commencé à prendre euh par les intellectuels euh c' est eux qui ont commencé à à faire euh du chambard quoi puis qui se sont mis en grève puis ça s' est enchaîné dans les ouvriers je sais pas dans **[quel sens]** j' **[en]** sais rien. 

 * s-CHAIN-84: ['u-MENTION-agoudjo_1337678643062', 'u-MENTION-agoudjo_1337678758283', 'u-MENTION-agoudjo_1337679076652', 'u-MENTION-agoudjo_1337679246258', 'u-MENTION-jmuzerelle_1376040267216', 'u-MENTION-agoudjo_1337679311338', 'u-MENTION-jmuzerelle_1376040402328'] 

	 euh un étranger veut venir en France pour apprendre le français euh dans **[quelle région]** est il est -ce qu' il doit aller ? d' après vous dans quelle ville ou **[coin]** ?. un étranger qui voudrait apprendre la langue française ?. [...] oui. **[quelle région]** ça vous savez. non ?. non je suis incapable de vous répondre. il n' y a pas **[d' endroit]** **[qu']** il devrait éviter ?. hm non plus je vois pas hein. non enfin il n' y a pas **[de régions]** où vous croyez **[qu']** il apprendrait un enfin un meilleur français que que dans d' autres. 

### File: 008_C-2.tei

 * s-CHAIN-47: ['u-MENTION-jmuzerelle_1365760185072', 'u-MENTION-jmuzerelle_1365760531462', 'u-MENTION-jmuzerelle_1365760552212', 'u-MENTION-jmuzerelle_1365760684472'] 

	 je lui dis euh ça dépend qui euh si c' est ça dépend **[quelle personne]** évidemment mais venez donc prendre l' apéritif ou venez donc nous dire bonjour ou venez. c' est ça c' est. [...]. alors ça dépend encore de **[la personne]**. oui aussi euh évidemment euh si **[c']** est un ami ben je lui dit ben passe donc à la maison quoi euh. hm hm hm. si **[c']** est quelqu'un ben venez donc prendre le café euh mais. 

### File: 008_C-1.tei

 * s-CHAIN-87: ['u-MENTION-gpascault_1360325992557', 'u-MENTION-jmuzerelle_1372686618601', 'u-MENTION-jmuzerelle_1372686632091'] 

	 et dans **[quelle matière]** est- il bon qu' un enfant soit fort ?. ben maintenant moi à mon avis je pense que euh **[ce]** serait pour l' avenir je pense pour les les enfants de maintenant **[ce]** serait plutôt les mathématiques plus qu' ils se dirigent vers la science c' est là quand même le meilleur débouché. 

### File: 023_C.tei

 * s-CHAIN-13: ['u-MENTION-agoudjo_1335459976093', 'u-MENTION-agoudjo_1335460013578', 'u-MENTION-agoudjo_1335460030968', 'u-MENTION-agoudjo_1335460252812', 'u-MENTION-agoudjo_1335460644875', 'u-MENTION-agoudjo_1335460696546', 'u-MENTION-agoudjo_1335517530093', 'u-MENTION-agoudjo_1335517641625'] 

	 ah oui ce serait **[quel nom]** euh ?. **[c']** était **[Ligneaux]** et puis du reste y a la rue **[aux Ligneaux]** au bout de la un peu plus bas. ah bon. il y avait beaucoup de **[Ligneaux]** par ici. oui. et **[ce nom-là]** euh figurent dans les registres de des paroisses à ce moment -là c' était des paroisses alors à ce moment -là si on regarde les registres de paroisses depuis des siècles je.. [...]. ah bon c' est très intéressant le le mot **[Ligneaux]** ça veut dire quelque chose ou bien ? c' est seulement **[un nom]** alors vos euh vos grands parents par exemple qu' est -ce qu' ils faisaient ?. 

### File: 078_C-4.tei

 * s-CHAIN-25: ['u-MENTION-jmuzerelle_1358413538634', 'u-MENTION-jmuzerelle_1358413783221'] 

	 hm hm hm hm et euh dans **[quelle matière]** étiez- vous le plus fort à l' école ?. oh j' étais fort en maths **[c']** est surtout en maths que j' étais. 

 * s-CHAIN-40: ['u-MENTION-jmuzerelle_1358416565481', 'u-MENTION-jmuzerelle_1358416762829', 'u-MENTION-jmuzerelle_1358416583833'] 

	 vous savez pas à **[quel âge]** vous avez eu votre ?. eh bien j' ai eu mon premier stylo euh je m' en souviens très bien **[c']** était à **[l' âge]** de je parle stylo hein je ne parle pas de de plume parce qu' on écrivait à la plume gauloise. 

### File: 029_C-5.tei

 * s-CHAIN-46: ['u-MENTION-jmuzerelle_1363959464379', 'u-MENTION-jmuzerelle_1363959661710', 'u-MENTION-jmuzerelle_1363959845347'] 

	 et à la suite de **[quelle circonstance]** avez- vous possédé un stylo à plume pour la première fois ? est -ce que vous vous souvenez ?. je me souviens pas. [...] dix ans. oui environ oui ça je pense pas trop me tromper **[la circonstance]** **[c']** était probablement qu' on m' avait dit qu' on écrivait mal avec un stylo à bille. 

 * s-CHAIN-83: ['u-MENTION-jmuzerelle_1363963999445', 'u-MENTION-jmuzerelle_1363964040754'] 

	 oui oui et pour **[quel genre de choses]** surtout ? **[c']** était des enfin des fautes de français ou. 

### File: 015_C-1.tei

 * s-CHAIN-59: ['u-MENTION-jmuzerelle_1367848666970', 'u-MENTION-jmuzerelle_1367859307540'] 

	 oh oui pourquoi pas ? euh enfin euh mettons que si vous aviez des enfants dans **[quelles matières]** est -ce que vous aimeriez qu' ils soient forts ?. en français. [...] ah bon. alors je crois que **[c']** est le le français parce que j' ai je préfère quand même ça enfin le français en général pas le la langue. 

### File: 133_C-4.tei

 * s-CHAIN-47: ['u-MENTION-jmuzerelle_1365152398436', 'u-MENTION-jmuzerelle_1365152962071'] 

	 oui quand même oui mais c' est commode oui alors à la suite de quelles circonstances avez- vous possédé pour la première fois un stylo à plume ? c'est-à-dire à **[quel âge]** ? si vous pouvez. j' aime pas beaucoup. [...] un stylo encre la première ou c' était. oui mes douze ans quoi onze ans quoi **[quelque chose]** comme ça. 

