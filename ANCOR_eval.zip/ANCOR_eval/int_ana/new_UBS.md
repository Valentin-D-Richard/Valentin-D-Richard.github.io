### File: 083_00000054.tei

 * r-ASSOCIATIVE-jmuzerelle_1339688416198: ['u-MENTION-adrouin_1339070059809', 'u-MENTION-adrouin_1339070091093'] 

	 je vais rechercher je vais regarder s' il est dans son bureau et dans **[quelle filière]** il travaille. e il travaille e **[au niveau informatique]**. 

### File: 068_00000045.tei

 * r-ASSOCIATIVE-jmuzerelle_1378303203486: ['u-MENTION-jmuzerelle_1378302768821', 'u-MENTION-jmuzerelle_1378302817088'] 

	 d' accord et vous rep- et vous reprenez à **[quelle heure]**.. oh moi je m' arrête une demie heure de midi à **[midi et demie]** hein. 

### File: 037_00000026.tei

 * r-ASSOCIATIVE-gpascault_1349947242882: ['u-MENTION-gpascault_1349707731355', 'u-MENTION-jmuzerelle_1349788729862'] 

	 e conservez je vais demander à qu- à partir de **[quelle heure]** ce soir. c' est à **[dix huit heure]**. 

### File: 079_00000050.tei

 * r-ASSOCIATIVE-jmuzerelle_1378305124438: ['u-MENTION-jmuzerelle_1378304678492', 'u-MENTION-jmuzerelle_1378304687103'] 

	 oui en **[quelle filière]**. elle est en **[licence professionnelle gestion des Ressources Humaines]** dans les PMO. 

### File: 053_00000036.tei

 * r-ASSOCIATIVE-jmuzerelle_1378223276209: ['u-MENTION-jmuzerelle_1378222891908', 'u-MENTION-jmuzerelle_1378223051629'] 

	 oui bonjour j' aurais aimé savoir si **[les diplômes]** de qui a été envoyé au rectorat pour des modifications était arrivé ou pas. e j' ai pas compris vous p- oui. [...] ouais ben ouais ouais ouais. et en **[quelle filière]**. 

 * r-ASSOCIATIVE-jmuzerelle_1378223299179: ['u-MENTION-jmuzerelle_1378223051629', 'u-MENTION-jmuzerelle_1378223061479'] 

	 et en **[quelle filière]**. **[A E S]** de deux mille deux. 

### File: 073_0000004a.tei

 * r-ASSOCIATIVE-jmuzerelle_1343835975178: ['u-MENTION-adrouin_1341137130053', 'u-MENTION-adrouin_1341137283713'] 

	 e oui qu' avez v- dans **[quelle filière]**. e je je en fait j' ai reçu un un appel sur mon portable par ce que je je donne des cours et c' est j' aurais voulu la personne qui s' occupe en maîtrise de **[droit publique]** de de collecter les notes alors je c' est sur un portable c' est très mal indiqué je j' arrive pas à comprendre le nom. 

### File: 024_00000019.tei

 * r-ASSOCIATIVE-jmuzerelle_1378216757764: ['u-MENTION-jmuzerelle_1378214623790', 'u-MENTION-jmuzerelle_1378214637760'] 

	 il est **[quelle heure]** là **[deux heures]** e deux heures. 

### File: 101_00000066.tei

 * r-ASSOCIATIVE-jmuzerelle_1378308973398: ['u-MENTION-jmuzerelle_1378308401298', 'u-MENTION-jmuzerelle_1378308432030'] 

	 oui au site à Lorient à **[quel numéro]**. **[au 0 2 97 87. 

### File: 058_0000003b.tei

 * r-ASSOCIATIVE-jmuzerelle_1378224895325: ['u-MENTION-jmuzerelle_1378224550221', 'u-MENTION-jmuzerelle_1378224555603'] 

	 oui bonjour madame madame Nom de Brest je vous appelle pour savoir si vous faîtes la capacité en **[droit]**. en **[quelle filière]**. 

