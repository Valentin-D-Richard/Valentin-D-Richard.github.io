### File: 1PF0420.tei

 * s-CHAIN-1: ['u-MENTION-gpascault_1353061267103', 'u-MENTION-jmuzerelle_1370880442373', 'u-MENTION-jmuzerelle_1369228630721'] 

	 je voudrais savoir **[quel bus]** faut prendre pour aller jusqu' à Meylan. alors vous allez voir la TAG mademoiselle parce que e je veux pas vous dire de bêtises je crois que **[c']** est le quarante-et-un hein vous leur demandez voyez c' est ils ont carrément des plans là bas hein ma collègue Prénom va vous dire **[ça]**. 

### File: 1SB0284.tei

 * s-CHAIN-0: ['u-MENTION-mgodefroy_1331829890597', 'u-MENTION-mgodefroy_1331829908337', 'u-MENTION-mgodefroy_1331830113118'] 

	 s' il vous plaît j' allais vous demander ce e le **[quel bus]** **[il]** amène à Général Mangin. faut voir avec la TAG c' est eux qui s' **[en]** occupent hein. 

### File: 1PF0305.tei

 * s-CHAIN-11: ['u-MENTION-gpascault_1351178967535', 'u-MENTION-gpascault_1351179025781', 'u-MENTION-jmuzerelle_1365667036780'] 

	 il faudrait que vous envoyez rapidement à je vous fais un package aussi comme ça vous voyez ce qu' on a à l' Office vous êtes **[quelle société]**. eh ce au fait c' est pas c' est pas moi qui suis de **[la société]** c' est c' est moi qui qui mène e **[c']** est Thomson C S F Thomson C S F. 

