 * 0: ['0']
	est vraiment euh vraiment je suis né là-dedans.
	 oui.
	 et puis alors y a quelques années euh j' ai voulu étendre un peu mon activité et c' est à ce moment -là que j' ai une entreprise d créée peinture décoration mais euh si vous voulez y a quand même un certain un rapport parce que euh je fais pas euh quarante logements euh tous pareils euh je travaille que pour des particuliers et on arrange un salon ou euh enfin c' est vraiment de la décoration donc si vous voulez ça reste un petit peu dans mon premier élément et puis très souvent ça se complète si je fais un appartement il est possible que je fasse un vitrail en même temps enfin voilà c' est pour ça.
	 oui alors c' est euh l' agencement total ?.
	 oui et puis alors j' aime beaucoup la les meubles anciens les choses comme ça alors très souvent aussi je je fais acheter par mes clients euh certains meubles euh pour pour compléter la décoration.
	 ah oui euh dans ce cas -là évidemment il y il y a énormément de de choix personnel et de personnalité qui entre oui.
	 là-dedans.
	 ben oui si vous voulez mais enfin il faut tenir compte aussi du goût du client alors il faut il faut les orienter il faut les pousser faut même les violer de temps en temps parce que enfin bon enfin on y arrive **[quoi]**.
	 enfin j' allais vous demander quelle était la personnalité dominante à la fin du processus est -ce que c' était celle du client ou la vôtre ?.
	 j' ai assez de chance euh mettez à quatre-vingt-dix pour cent c' est c' est la mienne mais il y a toujours les fameux dix pour cent où là on se trouve un peu désarmé quoi.
	 ah bon oui.
	 vous ça ça arrive ça arrive.
	 hm euh votre métier euh est -ce qu' il y a des études précises euh pour devenir peintre-verrier ?.
	 non non non il faut il faut bon l' apprentissage pour la partie technique oui mais la partie artistique bon ben vous savez c' est le c' est l' école classique hein ? les beaux-arts ou moi j' ai fait un peu les beaux-arts j' ai fait le Centre d' Art Sacré.
	 venu tout seul ?.
	 puis j' aurais dû vous le demander euh vous vous avez fait les beaux-arts ?.
	 oui oui.
	 euh à Paris ?.
	 non à Orléans au départ après j' ai fait le Centre d' Art Sacré à Paris.
	 Orléans.
	 ah le Centre d' A- d' Art d' Art Sacré.
	 Place Furstemberg.
	 Sacré c' est une je je sais pas oui vous connaissez ? charmante.
	 j' ai j' ai habité à côté pendant deux ans et j' avais jamais remarqué.
	
 * 1: ['1']
	puis alors y a quelques années euh j' ai voulu étendre un peu mon activité et c' est à ce moment -là que j' ai une entreprise d créée peinture décoration mais euh si vous voulez y a quand même un certain un rapport parce que euh je fais pas euh quarante logements euh tous pareils euh je travaille que pour des particuliers et on arrange un salon ou euh enfin c' est vraiment de la décoration donc si vous voulez ça reste un petit peu dans mon premier élément et puis très souvent ça se complète si je fais un appartement il est possible que je fasse un vitrail en même temps enfin voilà c' est pour ça.
	 oui alors c' est euh l' agencement total ?.
	 oui et puis alors j' aime beaucoup la les meubles anciens les choses comme ça alors très souvent aussi je je fais acheter par mes clients euh certains meubles euh pour pour compléter la décoration.
	 ah oui euh dans ce cas -là évidemment il y il y a énormément de de choix personnel et de personnalité qui entre oui.
	 là-dedans.
	 ben oui si vous voulez mais enfin il faut tenir compte aussi du goût du client alors il faut il faut les orienter il faut les pousser faut même les violer de temps en temps parce que enfin bon enfin on y arrive quoi.
	 enfin j' allais vous demander **[quelle]** était la personnalité dominante à la fin du processus est -ce que **c'** était **celle du client** ou **la vôtre** ?.
	 j' ai assez de chance euh mettez à quatre-vingt-dix pour cent c' est c' est la mienne mais il y a toujours les fameux dix pour cent où là on se trouve un peu désarmé quoi.
	 ah bon oui.
	 vous ça ça arrive ça arrive.
	 hm euh votre métier euh est -ce qu' il y a des études précises euh pour devenir peintre-verrier ?.
	 non non non il faut il faut bon l' apprentissage pour la partie technique oui mais la partie artistique bon ben vous savez c' est le c' est l' école classique hein ? les beaux-arts ou moi j' ai fait un peu les beaux-arts j' ai fait le Centre d' Art Sacré.
	 venu tout seul ?.
	 puis j' aurais dû vous le demander euh vous vous avez fait les beaux-arts ?.
	 oui oui.
	 euh à Paris ?.
	 non à Orléans au départ après j' ai fait le Centre d' Art Sacré à Paris.
	 Orléans.
	 ah le Centre d' A- d' Art d' Art Sacré.
	 Place Furstemberg.
	 Sacré c' est une je je sais pas oui vous connaissez ? charmante.
	 j' ai j' ai habité à côté pendant deux ans et j' avais jamais remarqué.
	 si si y avait le Centre d' Art Sacré qui avait été fondé par Maurice Denis.
	
 * 2: ['2']
	 oui.
	 on a besoin de de sortir de de l' uniformité ça c' est c' est ça quoi.
	 c' est primordial.
	 sans ça on va en crever ça je sais pas comment c' est en Angleterre mais en France ça devient terrible vous allez dans n' importe quelle ville euh avait euh chaque ville son caractère ça c' était agréable on allait à Toulouse bon on savait que c' était une ville comme ça on al- euh maintenant on retrouve les mêmes bâtiments euh les mêmes constructions les mêmes lignes les mêmes matériaux et puis alors c' est plus la peine d' aller à Marseille ou à Tombouctou ça sera tout pareil hein ? et je crois que les gens réagissent comme ça pour se créer un petit un petit luxe à eux quoi.
	 oui.
	 voyez- vous ?.
	 enfin **[quelle]** est l' attitude envers le vitrail ? étant donné que oh un tableau on sait très bien que c' est exécuté entièrement par la personne qui le conçoit alors que le vitrail.
	 ou c' est exécuté entièrement euh moi j' en fais j' en crée **je les exécute complètement** mais euh oh vous savez ça le client euh ignore absolument comment se fait un vitrail ça alors là c' est le.
	 hm.
	 même des architectes qui sont censés euh nous diriger sur certains travaux le vitrail c' est le mystère absolu enfin alors là ils se figurent qu' on travaille encore comme au douzième siècle euh on en est pas loin remarquez mais enfin ils savent que c' est du verre du plomb mais en dehors de ça vraiment ils ignorent hein ?.
	 ah vous utilisez toujours les techniques traditionnelles ?.
	 bien sûr le verre coloré dans la masse soufflé à la bouche euh euh les baguettes de plomb enfin il y a d' autres techniques puisqu' on fait aussi des vitraux dans le dans le ciment armé on fait des vitraux dans les baguettes de cuivre on fait mais enfin on a toujours la technique euh du Moyen Âge quoi.
	 hm ah je me demandais s' il y avait des expériences ou s' il y avait de possibles innovations dans la technologie de la chose.
	 oui oui on cherche ben on cherche beaucoup sur les polyesters actuellement les les liants en polyester même le remplacer le verre par le polyester.
	 ah oui.
	 oui euh on fait des verres collés ce qu' on ne faisait pas avant qui sont pas du vitrail qui sont pas du verre coloré c' est euh mais enfin le vitrail traditionnel existe toujours et je moi je suis persuadé qu' on le fera encore dans quatre ou cinq cents ans enfin je l' espère je l' espère.
	 hm est -ce que vous pourriez me décrire la réalisation ?.
	 d' un vitrail ah oui oui c' est enfin je vais schématiser hein ? bon alors évidemment on fait d' abord on étudie un projet pour chaque problème posé parce que vous n' avez jamais exactement le même problème tel que ça peut varier d' éclairage de forme de de fenêtre de style si c' est un édifice euh.
	 d' un vitrail ?.
	
 * 3: ['3']
	hm est -ce que de ce côté -là du moment qu' il faut passer par une commission est -ce que évidemment ça ça implique un retard mais est -ce que ça pose d' autres problèmes est -ce qu' il y a des pro- problèmes stylistiques là-dedans ?.
	 oui euh on peut jusqu' à maintenant j' ai de la chance mais euh la commission peut refuser le projet purement et simplement pour des raisons euh extrêmement valables d' ailleurs ou ou non valables je n' en sais rien mais enfin vous savez le on ne peut pas plaire à tout le monde le style d' un peintre ou d' un verrier peut plaire à à cinquante pour cent des gens et puis puis les autres euh le trouvent épouvantable ça.
	 il est entendu que c' est une question de réaction personnelle.
	 oui mais enfin comme c' est en commission alors euh il y a tout de même d- il y a des avis pour il y a des avis contre euh ça peut arriver oui on peut vous demander de modifier un projet ça ça m' est arrivé de de dans un sens ou dans un autre enfin ça c' est à discuter aussi avec euh avec les architectes ou alors dans quand on travaille pour les municipalités euh euh dans des dans des édifices non classés alors là euh.
	 hm.
	 euh on en général c' est c' est avec le prêtre quoi.
	 ah bon.
	 et puis la commission nationale d' Art Sacré quand même.
	 euh enfin la commission c' est euh c' est **[quoi]** exactement ? ça fait partie de la hiérarchie ?.
	 ce sont **de vénérables ecclésiastiques** qui ont pas toujours une formation artistique très développée mais qu' on a qu' on a nommé euh membres de la commission d' Art Sacré et alors ils jugent.
	 ah bon.
	 voilà.
	 vous n' êtes pas là pour euh.
	 ah si on peut présenter son projet personnellement bien sûr oui oui on peut défendre euh pas toujours mais enfin.
	 enfin vous avez quand même la possibilité de les convaincre.
	 oui oui Dieu merci oui oui on peut dire moi je l' ai vu de telle façon pour telle raison voilà.
	 oui.
	 si si.
	 enfin la maison vous l' avez héritée de votre père ?.
	 ça oui.
	 de sorte que du côté des vitraux c' est il y a une tendance à à des dynasties bon je pense à votre père je pense aux par exemple euh.
	 un métier.
	 c' est un métier tellement inhabituel si vous voulez que à moins d' avoir une vocation comme certains jeunes tout d' un coup se découvrent la vocation de verrier c' est arrivé j' ai un de mes excellents amis qui est verrier aussi et qui a toujours rêvé de faire du vitrail depuis sa plus tendre enfance bon ben il s' est débrouillé il a appris à droite et à gauche et et il crée des vitraux qui sont fort beaux d' ailleurs bon mais ça c' est un cas spécial mais euh sans ça dans les vieux ateliers qu' est -ce que vous voulez quand on naît dans une ambiance i- il surtout une ambiance comme celle-ci il est difficile de de ne de changer de métier enfin moi c' est c' est ce qui s' est produit pour moi tout au moins.
	 alors c' est à cause d' avoir grandi ?.
	
 * 4: ['4']
	est triste même.
	 ben oui c' est triste oui c' est triste.
	 y a il y a un cas précis j' aimerais votre opinion.
	 oui.
	 je pense à cette église qui est sur le boulevard de Québec.
	 oui.
	 je la connais très bien oui oui.
	 euh moi aussi j' en suis très impressionné.
	 oui.
	 mais c' est **[quoi]** au juste comme technique ?.
	 c' est **du polyester**.
	 oui enfin.
	 qui sont fait par oui qui sont créées par un de mes amis justement avec qui je fais beaucoup de vitraux.
	 extérieures.
	 hm euh et s' il fallait classer ce travail ce serait dans quelle catégorie ?.
	 au point de vue artistique ou au point de vue technique ?.
	 les deux étant donné que c' est tout le bâtiment qui est ça comprend tout le bâtiment.
	 moi je trouve ça très intéressant c' est peut-être qu' une expérience.
	 oui.
	 tout du moins au point de vue polyester hein ?.
	 oui euh je crois qu' on arrivera à à pousser ces techniques -là et à avoir des résultats satisfaisants mais là c' est plutôt une expérience oui.
	 au point de vue durée dans le temps je sais pas ce que ça va donner.
	 ah oui.
	 mais enfin je trouve ça intéressant d' avoir des des grands murs translucides euh moi j' aime bien.
	 ah oui ç- il y a ça crée une atmosphère très spéciale.
	 oui.
	
 * 5: ['5']
	s oui ça c' est certain.
	 hm.
	 ça c' est certain.
	 ça s' est produit en Angleterre et on peut imputer ça à une série d' émissions.
	 mais bien sûr.
	 précise.
	 mais bien sûr.
	 y a quelques années.
	 je le crois volontiers.
	 hm.
	 euh vous savez elle cette bon sang de télévision si on vous répète tous les jours ab- achetez la pâte euh je sais pas **[quoi]** eh bien je suis persuadé qu' au bout de qu' au bout de deux ans ou d' un an ou de six mois soixante pour cent des gens achèteront les pâtes euh je sais pas quoi ben l' archéologisme c' est un peu ça hein ?.
	 oui.
	 j' exagère un peu mais.
	 mais donc c' est le côté positif de la télévision.
	 ben oui oui oui oui oui oui certainement oui.
	 hm.
	 oui.
	 est -ce que enfin pour regard à Orléans puisque sur le plan social c' est très structuré est -ce qu' il y a des cloisons étanches entre.
	 moins mais y en a encore.
	 ah bon.
	 voyez je suis orléanais vous le savez euh je suis donc d' une famille enfin je veux pas avoir l' air prétentieux mais enfin relativement aisée connue et cetera et dans ma jeunesse on ne sortait qu' entre jeunes de même euh euh de même niveau si vous voulez euh de genre de famille et cetera maintenant ça existe moins mais y a quand même de petits clans y a euh y en a qui ne sortiront jamais avec les autres parce que euh euh le y en a un qui est directeur d' usine euh dont les parents sont directeurs d' usine et l' autre n' est que contremaître ou des choses comme ça ç- ça ça tend à diminuer mais enfin il y a encore un vieux fond d' esprit comme ça.
	 ah bon.
	 que je trouve parfaitement ridicule d' ailleurs mais enfin.
	 donc ces ces groupes ces clans c' est constitué un peu en fonction des des parents ?.
	 des conditions sociales oui.
	 hm.
	 mais enfin ça t- ça tend à disparaître je crois encore grâce au à l' apport de de beaucoup de gens de l' extérieur.
	 hm oui.
	
