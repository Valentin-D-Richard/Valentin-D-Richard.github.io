 * 0: ['0']
	.
	 on part.
	 oui oui.
	 mais on s' éloigne pas tellement.
	 oui.
	 c' est à peu près tout oui je vois pas d' autres choses à vous dire.
	 qu' est -ce que vous avez fait par exemple euh dimanche dernier ?.
	 eh bah nous sommes allés jusqu' à Fontainebleau voyez- vous.
	 oui.
	 n' est -ce pas euh on est allé jusqu' à Fontainebleau et puis euh on a fait un tour dans le parc et puis on mon dieu on est revenu **[quoi]** parce qu' il faisait mauvais d' abord.
	 oui.
	 n' est -ce pas mais ça a fait un bout euh nous sommes partis à deux heures et demie trois heures euh à six heures et demie s ept heures on est sept heures et demie on était de retour.
	 oui oui oui.
	 voilà à peu près l' emploi de nos dimanches quoi.
	 oui.
	 je ferais un détour pour aller à Chambord je ferais un détour vous voyez ça c' est c' est c' est c' est sans doute dans mon tempérament vous comprenez ça c' est c' est c' est personnel ça.
	 hum oui.
	 c' est faut pas que vous vous savez c' est comme l' Anglais qui descend à Calais et qui voit une femme rousse hein faut pas croire parce que je dis ça que tous les bouchers sont sont dans mon genre vous comprenez toutes les Françaises sont pas rousses hein non mais moi je vous dis ce que je ressens personnellement.
	 oui oui oui c' est ce qu' on vous demande d' ailleurs.
	 oui.
	 et.
	 pendant vos prochaines vacances d' été qu' est -ce que vous comptez faire ?.
	 ah malheureusement c' est que je ne peux pas prendre depuis huit ans depuis que j' ai mes pilotes là je ne peux pas prendre de vacances.
	 oui oui oui oui.
	 parce que on a un métier qui se perd on trouve plus de personnel.
	 oui.
	 alors je donne du congé à mes gars moi je ferme ma boucherie pendant trois semaines et je remplace mes gars pendant les trois semaines.
	 ah oui.
	
 * 1: ['1']
	dans les langues euh bien euh c' est dommage il devait venir Jacques mon fils euh il parle l' anglais euh assez facilement.
	 oui.
	 assez facilement oui.
	 qu' est -ce qui fait d' après vous que les enfants réussissent ou ne réussissent pas à l' école ?.
	 euh je crois pas tellement vous savez à la super-intelligence hein enfin euh si je juge d' après mes mes enfants.
	 oui.
	 n' est -ce pas euh ils sont d' un bon niveau mais enfin c' est pas des des grands cerveaux seulement à côté de ça ce sont des travailleurs.
	 oui.
	 ils ont jamais fait d' éclat.
	 oh là.
	 oui **[où]** est -ce qu' on en était ? ah oui.
	 je vous demandai **qu' est -ce qui fait qu' ils réussissent ?**.
	 moi je crois que c' est surtout le la la volonté euh d' arriver on peut faire euh on est un élément moyen mais on peut quand même arriver moi si je vous le répète si je juge d' après mes enfants et d' après moi-même bah euh évidemment si on juge euh en faire des intellectuels ça c' est autre chose.
	 oui.
	 hein ?.
	 oui.
	 mais on on peut faire des bons manuels moi vous vous me direz que j' en reviens toujours à cette question mais enfin y a des bons métiers manuels et on euh un élément moyen peut faire un un bon manuel tout de même et il gagne sa vie.
	 oui oui.
	 alors d' après vous euh jusqu' à quel âge est -ce qu' il faut que les enfants euh fassent des études ?.
	 je suis d' accord pour aller jusqu' à seize ans quand même c' est un minimum de bagages qu' il faut parce que moi j' en souffre de ça.
	 oui.
	 comprenez- vous moi j' ai été à l' école jusqu' à mon Certificat d' Etudes j' avais douze ans et demi et ça j' en ai toujours souffert.
	 oui.
	 n' est -ce pas mais j' estime que c' est valable qu' un gosse aille à l' école jusqu' à treize ans.
	 oui.
	 comprenez- vous ? mais alors là quoi à ce moment -là quoi qu' on dise carrément bon ben ça suffit hein parce un élé- un gosse je pense qu' à seize ans il s' est révélé ou alors euh euh c' est pas la peine.
	 oui.
	 y en a qui se révèlent tard mais enfin quand même je trouve qu' à seize ans euh un gosse s' est révélé s' il est valable pour faire un intellectuel euh un cadre ou enfin même un un un comment dirais- je un responsable euh assez haut placé mais sinon à seize ans bah qu' est -ce que vous voulez à ce moment -là qu' il prenne un bon métier manuel euh j' en reviens toujours avec mes questions.
	 et pour vous d' après vous ce serait la même chose pour les garçons et pour les filles ?.
	
 * 2: ['2']
	vous voulez dire euh personnellement ?.
	 oui c' est ça.
	 non moi je ne me trouve pas mal admi- administré qu' est -ce t' en penses toi Denis ? tu te trouves pas mal administré ?.
	 oui c'est-à-dire que les que la mentalité peut-être euh n' est pas assez jeune justement dans la municipalité.
	 des jeunes hein qui se posent.
	 oui.
	 oui oui oui euh mais alors quand on dit la municipalité.
	 hum.
	 **[qui]** est -ce que ça représente enfin quelles personnes ?.
	 bah **le maire** et **ses administrés**.
	 ah moi euh je vois le maire et les adjoints après qu' est -ce vous voulez c' est un petit peu plus flou pour moi hein.
	 oui.
	 mais je connais pas mal de conseillers municipaux mais enfin remarquez que je leur fais entière confiance je je c' est des gens très honnêtes et certainement très dévoués hein.
	 oui oui.
	 parce que moi-même si vous voulez dans une plus petite sphère j' ai été président de chez nous et tout ça je connais les inconvénients de mener des du monde c' est pas commode hein.
	 oui oui.
	 et puis de gérer c' est pas commode.
	 oui.
	 la critique la critique est toujours facile hein.
	 oui oui.
	 n' est -ce pas ? non moi je je me plains pas de la municipalité sauf ça je vous répète que euh au point de vue équipements sportifs vraiment ça ça laisse à désirer et puis alors y des lacunes quoi euh comme celle que je viens de vous signaler.
	 oui.
	 en dehors de ces la municipalité est -ce qu' il y a d' autres personnes qui comptent euh qui ont de l' influence à Orléans ?.
	 bah voilà voyez toujours pareil euh c' est -ce qui prouve quand même j' admire le professeur le le recteur Antoine par exemple.
	 oui oui.
	 hein ? euh Maurice Genevoix j' estime que c' est un homme de notre terroir c' est un homme de chez nous si vous voulez.
	 oui oui.
	 hein ? voilà des gens que j' admire j' aime entendre par exemple à sur la comment dirais- je euh en moyenne fréquence vous savez euh à entendre j' ai entendu l' autre jour une causerie justement sur l' Orléanais qui était débattue entre Maurice Genevoix euh Secrétain et le prof- le recteur Antoine je me souviens pas le quatrième responsable ah oui euh le président Le- Le- Leguet président de la Chambre de Commerce bah là j' ai bu du petit lait ça c' est des hommes que j' admire parce que justement ils défendent mon terroir.
	
 * 3: ['3']
	depuis toujours pratiquement.
	 oui.
	 le Larousse je l' ai depuis toujours le Littré je l' ai acheté après euh parce que je l' ai jugé un petit peu plus mieux approfondi si vous voulez un peu plus fouillé.
	 oui quand est -ce que vous l' avez vous l' avez acheté euh est -ce que vous vous souvenez ?.
	 y a une quinzaine d' années oui.
	 oui et comment est -ce que vous l' avez vous avez euh acheté enfin l' un ou l' autre de ces dictionnaires enfin.
	 le le le dictionnaire euh Larousse y avait pas de problèmes je l' avais euh apprécié à l' école alors j' ai continué c' est un Larousse tout ce qu' il y a de primaire.
	 oui oui.
	 après j' ai demandé l' avis à un d' un libraire.
	 oui oui bien **[qui]** est -ce qui s' en sert le plus souvent à la maison ?.
	 bah un peu **tous** hein des fois quand on a quelque chose à débattre bah on c' est le Larousse qui nous départage ou le ou le Littré.
	 oui oui oui oui et vous est -ce que vous vous en servez euh ?.
	 oui parce que je je vous l' ai répété comme euh tout à l' heure je vous le disais là du fait que ayant quitté l' école à treize ans hein je bute sur pas mal de choses hein.
	 oui.
	 et alors je suis content de le trouver pour pouvoir me m' éclairer.
	 oui en moyenne enfin combien de fois par mois est -ce que vous seriez susceptible de.
	 je sais pas peut-être euh deux ou trois fois par mois ça dépend des moments je vais l' employer des fois dans la même semaine trois quatre fois puis je vais être un mois sans m' en servir.
	 oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à quel euh sujet ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 c' était Jacques.
	 la denture et la dentition.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans quelle catégorie vous cherchez le plus souvent entre orthographe euh le sens des mots l' histoire ou la géographie ?.
	 l' orthographe.
	 l' orthographe oui.
	
 * 4: ['4']
	 oui oui.
	 d' ailleurs on n' est pas la euh la vallée de la Loire pour rien hein.
	 oui bien euh hum enfin c' est différent ce qui existe quand même entre euh différentes catégories est -ce que d' après vous euh elles seraient très importantes importantes ou peu importantes ?.
	 peu importantes.
	 oui bien.
	 est -ce que d' après vous les gens parleraient de mieux en mieux de plus en plus mal ou sans changement ?.
	 ah non de mieux en mieux.
	 de mieux en mieux oui et à quoi cela tient d' après vous ?.
	 bah justement parce que je crois que l' éducation est un petit peu plus poussée l' instruction est un peu plus poussée.
	 oui.
	 parmi vos vos connaissances **[quelle]** est la personne qui parle le mieux le français ? des personnes que vous connaissez ?.
	 il faut que je vous cite **son** nom ?.
	 euh euh la profession enfin plutôt.
	 c' est euh oui oui mais enfin entre autres euh **c'** est **madame Assone**.
	 tu trouves ?.
	 ah oui.
	 c' est qui ?.
	 madame plus.
	 madame Cannone madame Assone ce sont euh justement la la femme qui qui est mariée avec un colonel américain une Française d' ailleurs.
	 oui.
	 bon madame Blocker.
	 madame Blocker oui oui si hein quand même hum.
	 oui.
	 et euh parmi les gens que vous êtes amené à entendre euh parler euh sans forcément les connaître.
	 hum.
	 qui est -ce qui vous avez entendu qui vous semblait parler le mieux ?.
	 euh vous parlez euh.
	
 * 5: ['5']
	 oui.
	 pour faire un speaker ou une speakerine.
	 d' accord aujourd'hui euh.
	 à votre avis euh est -ce que l' orthographe et la correction de la langue sont bien enseignées euh bon mieux ou moins bien que du temps où vous étiez vous-même à l' école ? par exemple l' orthographe est -ce qu' elle est aussi bien mieux ou moins bien en- moins bien enseignée d' après vous ?.
	 j' ai l' impression qu' elle est mieux enseignée hein c' est plus condensé que lorsque j' allais à l' école d' après mes enfants.
	 oui et la correction de la langue en général ?.
	 je peux pas vous répondre oh non franchement je peux pas vous répondre.
	 et le le fait que l' orthographe soit mieux enseignée ça tient à **[quoi]** d' après vous ?.
	 parce que je crois que **les études ont été plus poussées** et puis qu' on aperçoit maintenant que **les enfants ont une facilité beaucoup plus grande** euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans quelle matière étiez -vous le plus fort à l' école ?.
	 bah c' est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un une autre matière deuxième matière aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de quelle circonstance est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	 ça fait partie ça.
	
 * 6: ['6']
	le le fait que l' orthographe soit mieux enseignée ça tient à quoi d' après vous ?.
	 parce que je crois que les études ont été plus poussées et puis qu' on aperçoit maintenant que les enfants ont une facilité beaucoup plus grande euh que l' on croyait pour pouvoir euh euh comment dirais- je.
	 assimiler.
	 assimiler oui assimiler la.
	 euh dans quelle matière étiez -vous le plus fort à l' école ?.
	 bah c' est peut-être ça quand même l' orthographe.
	 oui.
	 c' est peut-être un paradoxe mais enfin.
	 et un une autre matière deuxième matière aurait été **[quoi]** ?.
	 **l' histoire**.
	 **l' histoire** oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de quelle circonstance est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	 ça fait partie ça.
	 depuis toujours ça veut dire depuis votre enfance ?.
	 oui depuis depuis dix-huit vingt ans quoi enfin de de pas depuis ma sortie de l' école bien sûr mais enfin dès que j' ai pu euh avoir l' occasion d' écrire un rapport j' ai estimé bon d' avoir un stylo à encre.
	 euh hum.
	 depuis quand n' avez- vous pas écrit ? maintenant est -ce que.
	 huit quinze jours y a pas de semaines que.
	 et la dernière fois est -ce que je peux vous demander pourquoi vous aviez écrit ?.
	 c' était pour un un camarade à Paris un de mes amis à Paris une lettre une lettre oui.
	
 * 7: ['7']
	 euh quel instrument est -ce que vous utilisez pour écrire à vos amis ?.
	 un stylo.
	 stylo à encre stylo à bille ? stylo à encre oui euh hum quel type de papier utilisez- vous ?.
	 stylo à encre.
	 le quadrillé.
	 quadrillé oui euh hum.
	 si vous devez écrire un ou deviez écrire une lettre euh d' un mot d' excuse à l' école est -ce que vous feriez un brouillon ?.
	 ah oui.
	 oui vous feriez attention à l' orthographe ?.
	 ah oui plus que jamais oui.
	 vous utiliseriez **[quel]** euh quel euh instrument ?.
	 même chose **stylo à encre**.
	 ah oui.
	 oui.
	 d' accord et quel papier ?.
	 euh le papier quadrillé aussi.
	 d' accord.
	 et si vous devez écrire à votre supérieur dans le travail est -ce que vous feriez un brouillon ?.
	 ah oui sûr.
	 oui vous feriez attention aux orthographes ?.
	 aussi oui.
	 vous utiliseriez le même.
	 papier.
	 instrument et le même papier bon euh hum.
	 est -ce que vous utilisez euh d' autre papier pour vos autre chose ? non d' accord c' est bête si ces bandes sont un peu courtes et j' ai toujours peur que.
	 vous avez.
	 dommage.
	 ça vienne à.
	 finir que je serais obligé de retourner mais enfin c' est c' est pas de toute façon comme c' est un questionnaire un peu fermé on pourra revenir dessus.
	
 * 8: ['8']
	r l' orthographe.
	 orthographe oui mais de dans la façon de parler ?.
	 oui il bah il admettait mal que que ce soit mal conjugué enfin si vous voulez.
	 d' accord y a autre chose non ?.
	 non c' est tout ce que je vois.
	 non est -ce qu' il prenait des sanctions quelquefois ?.
	 oh oui assez ça.
	 oui pour.
	 il était assez sévère.
	 **[quelles]** quelles sanctions.
	 **les lignes** **les lignes** **les lignes**.
	 oui.
	 et pour quel genre de choses ?.
	 ah bah si on avait mal conjugué un verbe vous étiez sûr d' avoir deux cent deux cent fois à le faire.
	 bon bon ça je crois que on y a réussi euh en y allant très très vite à.
	 vous allez.
	 à mettre tout sur la bande.
	
