 * 0: ['0']
	 est -ce qu' il y a ? vous avez des défauts dans le dans l' instrumentation ?.
	 j' espère que non je suis très content que vous m' ayez posé cette question ça m' a permis de vérifier le niveau du son.
	 bon.
	 j' ai l' impression que nous sommes dans la bonne position.
	 bon.
	 or ce dont il s' agit pardon c' est une ville charmante que vous habitez.
	 **[où]** ? **ici** ?.
	 oui.
	 **ici** vous trouvez ?.
	 ah non non pas la pas **la pièce** **la ville**.
	 ah oui la ville oui oui oui oui oui oui enfin en ce moment il fait assez froid oui.
	 Orléans.
	 mais enfin du moment qu' il y a du soleil c' est c' est encourageant.
	 est -ce que vous êtes toujours vous êtes à Orléans depuis toujours ou ?.
	 non je suis arrivé je suis arrivé à Orléans en en décembre dix-neuf cent soixante-deux.
	 hm oui.
	 et j' ai commencé mon activité professionnelle de d' ophtalmologiste en février soixante-trois alors ça me fait donc euh six ans.
	 ah bon ?.
	 ça fait donc six ans que je suis à Orléans.
	 est -ce qu' il y avait des raisons particulières pour choisir Orléans ?.
	 je me suis installé à Orléans parce que euh d' une part j' aime j' aime bien la vallée de la Loire et que c' est c' est un pays qui me semble relativement équilibré qui depuis toujours euh m' attirait et je je suis originaire d' Amiens dans la Somme.
	 oui.
	 et c' est une ville euh que je trouvais grise euh où le seul charme pour moi est enfin tout de même cette vallée de somme où y a y a des brouillards qui sont assez appréciables et puis la cathédrale d' Amiens mais enfin l' ambiance générale ne me plaisait pas beaucoup je préfère mieux le le nord de la France franchement le département du Nord et le département du Pas-de-Calais où les gens me semblent plus plus affables disons euh avec qui j' ai on a plus facilement des des rapports agréables et puis alors sur le plan professionnel il m' était difficile de m' installer à Amiens où il avait dans ma profession finalement euh trop de monde voyez- vous ? alors euh je s- j' étais passé très souvent dans la vallée de la Loire et ça m' attirait et en plus de ça ici s- il semblait qu' il y avait de la place et je me suis installé ici à Orléans comme cela en.
	 oui oui.
	 plantant ma plaque devant ma porte.
	 j' espère que ça a réussi.
	 oui pas trop mal pas trop mal.
	
