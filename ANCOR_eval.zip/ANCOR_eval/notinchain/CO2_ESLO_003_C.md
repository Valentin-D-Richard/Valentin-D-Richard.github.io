 * [u-MENTION-jmuzerelle_1296132866992]
	pourtant il doit vous arriver d' avoir un peu de temps libre ?.
	 oui.
	 est -ce que vous avez des intérêts particuliers pour ces temps libres ?.
	 bah des intérêts particuliers pour ces temps libres enfin je suis je suis libre je ne travaille pas le mercredi le mercredi matin je vais à je vais dans euh à l' hôpital donc et l' après-midi bah je vais euh volontiers voir euh des expositions de de peinture.
	 hm hm.
	 euh euh des expositions avant des ventes euh je vais au cinéma je vais très peu au théâtre j' aime j' aime beaucoup lire je lis souvent le le soir mais j' ai relativement peu le temps de lire je voudrais lire des des livres professionnels et y en a toute une pile ici qui traîne que je n' ai pas le temps de lire et j' aime beaucoup les livres d' histoire parce que ça me ça me relaxe ça n' est pas ça ne présente pas un caractère euh euh disons actuel et parfois dramatique comme les les romans qui peuvent rappeler des situations plus ou moins pénibles ou euh donc ça me les livres d' histoire me détendent et j' aime les les lire et puis j' ai- j' adore la musique j' ai une discothèque peut-être pas très importante mais enfin tout de même et c' est pour moi un très grand délassement que d' écouter des disques.
	 est -ce que je peux vous demander euh comment vous avez passé dimanche dernier ? on est vendredi c' est déjà un peu loin.
	 oui eh dimanche dernier nous sommes allés à nous sommes allés à Chartres nous sommes allés à Chartres euh euh parce que j' ai été conduire mes enfants qui prenaient le le car pour aller aux sports d' hiver ils y vont avec une association de de loisirs de Chartres alors j' ai été les conduire à à Chartres et j' en ai profité pour aller voir des des amis qui sont euh Chartrains et euh cet am- cet ami est photographe nous avons discuté photos et euh j' ai passé une après-midi avec eux ces gens qui sont des gens très très affables qui euh reçoivent avec euh le le coeur sur la main et.
	 hm hm.
	 chez qui on peut tomber à **[n' importe quel moment]** qui ont des qu- des qualités d' accueil exceptionnelles.
	 et est -ce que vous avez des projets pour les vacances d' été ?.
	 ah pour les vacances d' été je vais aller euh je vais aller comme tous les ans au Guilvinec qui est un petit port euh breton où y a beaucoup plus de d' autochtones que de touristes c'est-à-dire que sur la ville qui a qui fait trois mille cinq cents habitants y a peut-être au mois d' août mille touristes ce qui fait que on est quand même euh euh dans une ville qui a une unité qui est qui est qui est une ville bretonne un petit port breton et c' est pas c' est pas cette immense transhumance si vous voulez euh que l' on trouve dans des dans des plages à la mode et moi je m' y trouve fort bien euh je vais sur la plage un peu mes enfants y sont eux tout le temps et je je fais de la pêche en mer avec des professionnels et je joue au tennis.
	 hm hm.
	 c' est euh relaxe ça dure un mois.
	 enfin je promets on va enlever le nom de la ville pour que ça ne soit pas envahi.
	 si vous voulez oui.
	 euhm.
	 vous vous allez pas être publiés cette histoire non ?.
	 enfin ça dépend euh.
	 vous avez une voiture évidemment ?.
	 oui.
	 euh.
	 quel modèle qu' est -ce que vous avez comme voiture ?.
	 j' ai une Peugeot quatre cent quatre à injection.
	 euh.
	 et une autre deux-chevaux que j' ai depuis trois jours.
	 ah bon ?.
	 oui.
	 pourquoi est -ce que vous avez choisi ces modèles ?.
	
 * [u-MENTION-jmuzerelle_1296832073159]
	 -ce qu' il vous arrive parfois d' utiliser du papier à carreaux ?.
	 non non.
	 ensuite des renseignements factuels.
	 factuels.
	 pour la statistique tout simplement des renseignements sur euh sur vous sur votre femme.
	 ah bon oui.
	 euh vous avez quatre enfants profession euh.
	 votre euh femme est française et vos parents aussi.
	 hm hm.
	 hein ?.
	 et euhm vous-même enfin vous-même vous êtes euh enfin vous ce sont vos parents euhm vos parents ont continué leurs études jusqu' à **[quel âge]** ? à peu près.
	 mon père est a dû poursuivre des études jusque il était licencié en droit euh il a du poursuivre ses études jusque je ne sais pas oui trois ans.
	 sa licence en droit c' est pas et euh alors qu' il est euh qu' il était euh.
	 marchand de chaussures.
	 ah bon ? et votre mère ?.
	 euh ma mère n' a pas son baccalauréat mais c' est une personne fort intelligente.
	 ah bah.
	 parce qu' elle euh bénéficiait elle a bénéficié d' un enseignement religieux.
	 ah oui ?.
	 et un peu rétrograde où le baccalauréat était une institution républicaine euh qui qui était qu' on ne devait pas passer.
	 oui.
	 ça c' est vraiment du nouveau et euh vos grand-pères ? est -ce que vous pouvez au moins me dire leurs professions ?.
	 ah bah mon grand-père vendait des chaussures.
	 oui côté paternel ?.
	 côté paternel et mon grand-père maternel était médecin euh oto-rhino-laryngologiste.
	 oui et euh madame vous avez dit elle est.
	 ma femme ?.
	 oui.
	 elle est psychologue.
	
 * [u-MENTION-jmuzerelle_1297089962669]
	.
	 euhm quel genre d' émissions surtout ?.
	 bah j' écoute les informations sur Europe numéro Un.
	 hm.
	 et à par ça j' écoute France Musique.
	 oui.
	 pour écouter de la musique.
	 oui.
	 la télévision ?.
	 oui peu.
	 euh encore une fois des des émissions préférées ? **[quel genre euh d' émissions]** ?.
	 j' aime beaucoup j' aime beaucoup **les émissions sportives**.
	 oui.
	 beaucoup les émissions sportives à la télévision et puis bah ma foi euh **les films**.
	 oui.
	 **pièces de théâtre** il y a quelquefois des choses remarquables à la télévision en pièces de théâtre.
	 oui.
	 et le cinéma vous avez dit que vous y allez.
	 oui pas très souvent pas très souvent.
	 encore une fois la même question euh les préférences ?.
	 dans quel euh sens ?.
	 de préférence quel genre de film ?.
	 ou est -ce que vous avez des goûts variés.
	 bah j' aime euh j' aime bien les disons les euh le ciné- le cinéma actuel euh le cinéma euh euh un petit symbolique euh qui a été euh enfin euh qui a commencé en Italie enfin qui a fait un petit peu en France euh j' aime beaucoup ce cinéma moderne.
	 à votre avis est -ce que ces ces médias la radio le cinéma la télévision peuvent être des du comment dirais- je ? des instruments de culture ?.
	 oh sûrement oui.
	 est -ce que vous vous faites de la photo ?.
	
 * [u-MENTION-jmuzerelle_1297090483817]
	 encore une fois des des émissions préférées ? quel genre euh d' émissions ?.
	 j' aime beaucoup j' aime beaucoup les émissions sportives.
	 oui.
	 beaucoup les émissions sportives à la télévision et puis bah ma foi euh les films.
	 oui.
	 pièces de théâtre il y a quelquefois des choses remarquables à la télévision en pièces de théâtre.
	 oui.
	 et le cinéma vous avez dit que vous y allez.
	 oui pas très souvent pas très souvent.
	 encore une fois la même question euh les préférences ?.
	 dans **[quel euh sens]** ?.
	 **de préférence quel genre de film** ?.
	 ou est -ce que vous avez des goûts variés.
	 bah j' aime euh j' aime bien les disons les euh le ciné- le cinéma actuel euh le cinéma euh euh un petit symbolique euh qui a été euh enfin euh qui a commencé en Italie enfin qui a fait un petit peu en France euh j' aime beaucoup ce cinéma moderne.
	 à votre avis est -ce que ces ces médias la radio le cinéma la télévision peuvent être des du comment dirais- je ? des instruments de culture ?.
	 oh sûrement oui.
	 est -ce que vous vous faites de la photo ?.
	 oui.
	 oui ?.
	 beaucoup même.
	 et quel genre ?.
	 bah des photos de de mes gosses euh des photos de paysages euh.
	 les photos qu' il y a dans votre salle d' attente ?.
	 c' est moi qui les ai prises oui oui.
	
 * [u-MENTION-jmuzerelle_1297091847446]
	 j' aime euh j' aime bien les disons les euh le ciné- le cinéma actuel euh le cinéma euh euh un petit symbolique euh qui a été euh enfin euh qui a commencé en Italie enfin qui a fait un petit peu en France euh j' aime beaucoup ce cinéma moderne.
	 à votre avis est -ce que ces ces médias la radio le cinéma la télévision peuvent être des du comment dirais- je ? des instruments de culture ?.
	 oh sûrement oui.
	 est -ce que vous vous faites de la photo ?.
	 oui.
	 oui ?.
	 beaucoup même.
	 et **[quel genre]** ?.
	 bah **des photos de de mes gosses** euh **des photos de paysages** euh.
	 les photos qu' il y a dans votre salle d' attente ?.
	 c' est moi qui les ai prises oui oui.
	 il s' agit là de voitures de course.
	 oui oui oui oui oui j' ai été au vingt-quatre heures du Mans l' année dernière et et j' ai pris des ces ces photos et sur un grand nombre il y en avait deux de bonnes et c' est celle -là parce que c' est pas tellement facile.
	 eff- effectivement.
	 et la peinture je vois que vous vous y intéressez.
	 non enfin si je m' y intéresse oui mais enfin euh pas euh non je peux passer à la maison oui oui oui.
	 vous en faites ?.
	 non.
	 et est -ce que vous des peintres euh ou des écoles qui vous touchent par- particulièrement ?.
	 oui hm hm pourquoi vous voulez des noms ?.
	 je peux vous demander ?.
	 euh.
	 oui parmi les parmi les contemporains parmi les les anciens enfin je sais pas quoi si vous voulez me de- si vous voulez que je vous dise que euh le peintre sûrement que que j' aime le pe- l- le plus c' est Cézanne.
	
