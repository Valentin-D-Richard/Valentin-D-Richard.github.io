 * [u-MENTION-jmuzerelle_1293384614244]
	ès j' ai demandé l' avis à un d' un libraire.
	 oui oui bien qui est -ce qui s' en sert le plus souvent à la maison ?.
	 bah un peu tous hein des fois quand on a quelque chose à débattre bah on c' est le Larousse qui nous départage ou le ou le Littré.
	 oui oui oui oui et vous est -ce que vous vous en servez euh ?.
	 oui parce que je je vous l' ai répété comme euh tout à l' heure je vous le disais là du fait que ayant quitté l' école à treize ans hein je bute sur pas mal de choses hein.
	 oui.
	 et alors je suis content de le trouver pour pouvoir me m' éclairer.
	 oui en moyenne enfin combien de fois par mois est -ce que vous seriez susceptible de.
	 je sais pas peut-être euh deux ou trois fois par mois ça dépend des moments je vais l' employer des fois dans la même semaine trois quatre fois puis je vais être un mois sans m' en servir.
	 oui c' est ça oui oui oui est -ce que vous vous souvenez de la dernière fois que vous l' avez regardé ?.
	 qu' est -ce qu' on a regardé ? à **[quel euh sujet]** ?.
	 oh y a pas longtemps.
	 hum oh une huitaine peut-être si vous voulez.
	 et vous vous souvenez de ce que vous avez cherché ?.
	 **c'** était **Jacques**.
	 **la denture et la dentition**.
	 oui je me souviens oui.
	 hum.
	 bon euh là s' il s' agit de dire dans dans quelle catégorie vous cherchez le plus souvent entre orthographe euh le sens des mots l' histoire ou la géographie ?.
	 l' orthographe.
	 l' orthographe oui.
	 le sens des mots aussi.
	 le sens des mots aussi oui.
	 oui et est -ce que vous avez aussi euh une ou des encyclopédies ?.
	 non.
	 non.
	 est -ce que vous possédez d' autres dictionnaires euh du genre euh par exemple Larousse ménager Larousse médical Larousse gastronomique ?.
	 euh ma femme a un Larousse ménager oui.
	 oui.
	 est -ce que vous possédez un livre euh sur euh l' art de parler ou la sur la prononciation ?.
	
 * [u-MENTION-jmuzerelle_1293647918149]
	ame plus.
	 madame Cannone madame Assone ce sont euh justement la la femme qui qui est mariée avec un colonel américain une Française d' ailleurs.
	 oui.
	 bon madame Blocker.
	 madame Blocker oui oui si hein quand même hum.
	 oui.
	 et euh parmi les gens que vous êtes amené à entendre euh parler euh sans forcément les connaître.
	 hum.
	 **[qui]** est -ce qui vous avez entendu qui vous semblait parler le mieux ?.
	 euh vous parlez euh.
	 des gens qui qui vous avez entendu parler en public euh . y compris la télévision ou autre.
	 la télévision ou autre euh ?.
	 la télévision ah **c'** est **maître Floriot** moi je crois.
	 oui.
	 est -ce qu' il y a en France un organisme qui di- qui décide si un mot ou une expression fait partie ou non du français ?.
	 ah oui.
	 oui lequel ?.
	 eh bien c' est le l' Académie Française je crois.
	 est -ce que vous trouvez que c' est très utile utile ou sans utilité ?.
	 ah c' est utile.
	 utile.
	 non très utile.
	 très utile.
	 très utile oui d' accord.
	 on dit quelquefois que la langue française se dégrade qu' en pensez- vous ? est -ce que vous pensez que c' est juste ?.
	 pense pas non d' après ce que je viens de vous dire puisque moi je trouve quand même que les gens s' expriment de mieux en mieux quand même.
	 oui.
	 si vous voulez y a trente ans que je suis établi eh bien si je compare par exemple euh mes clientes euh qui ont alors soixante-cinq ou soixante-dix ans bon bah on parle un langage moins quand même euh beaucoup plus commun euh hein avec beaucoup plus de fautes d' orthographe que que les jeunes actuellement.
	 oui.
	
 * [u-MENTION-jmuzerelle_1294145921084]
	.
	 c' est peut-être un paradoxe mais enfin.
	 et un une autre matière deuxième matière aurait été quoi ?.
	 l' histoire.
	 l' histoire oui.
	 est -ce que vous avez habituellement euh quelque chose pour écrire sur vous ?.
	 non.
	 non.
	 est -ce que vous avez un stylo à encre ?.
	 ah oui.
	 oui euh à la suite de **[quelle circonstance]** est -ce que vous avez eu pour la première fois un stylo à encre ?.
	 oh depuis toujours ça je trouve que ça.
	 oui.
	 ça fait partie ça.
	 depuis toujours ça veut dire depuis votre enfance ?.
	 oui depuis depuis dix-huit vingt ans quoi enfin de de pas depuis ma sortie de l' école bien sûr mais enfin dès que j' ai pu euh avoir **l' occasion d' écrire un rapport** j' ai estimé bon d' avoir un stylo à encre.
	 euh hum.
	 depuis quand n' avez- vous pas écrit ? maintenant est -ce que.
	 huit quinze jours y a pas de semaines que.
	 et la dernière fois est -ce que je peux vous demander pourquoi vous aviez écrit ?.
	 c' était pour un un camarade à Paris un de mes amis à Paris une lettre une lettre oui.
	 une lettre.
	 oui.
	 oui.
	 je m' excuse de presser ça mais euh.
	 ça va aller au bout ?.
	 ça va aller au bout oh ça ne fait rien on pourra retourner mais.
	 oui.
	
 * [u-MENTION-jmuzerelle_1294224839673]
	t ça c' est moi.
	 eh bien parce que là ça fait partie de de la partie commerciale un peu alors évidemment ça c' est mon domaine ça me concerne.
	 et qui de vous deux possède la meilleure orthographe ? d' après vous ?.
	 je crois que c' est ma femme.
	 oui la plus belle écriture ?.
	 toi.
	 peut-être oui.
	 hum.
	 oui et d' après vous **[qui]** est -ce qui des deux parle le meilleur français ? parle le meilleur français ?.
	 **ma femme**.
	 oui et écrit euh dans le meilleur français ?.
	 oui je lui demanderais son avis souvent pour euh écrire un mot si j' ai la la fainéantise de me déplacer pour prendre le dictionnaire je lui dirai crois- tu que tel mot ça s' écrit comme ci ou comme ça ?.
	 oui oui oui.
	 et c' est valable en général.
	 oui oui euh.
	 pour votre travail combien de lettres écrivez -vous en moyenne par mois ?.
	 oh huit dix euh par mois ?.
	 par mois oui.
	 oh oui une trentaine.
	 une trentaine oui et euh en dehors de votre travail ?.
	 ah non alors pas puisque c' est ma femme qui s' en occupe à part les papiers administratifs ou commerciaux.
	 d' accord oui euh hum.
	 est -ce que vous conservez les lettres qu' on vous envoie toujours très souvent souvent assez rarement rarement ou jamais ?.
	 rarement.
	 rarement mais vous en conservez quand même.
	
