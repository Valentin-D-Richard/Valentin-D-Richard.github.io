 * [u-MENTION-aboyer_1295380578534]
	combien de volumes ?.
	 un un euh assez épais mais enfin un volume.
	 j' y suis et euh où est -ce que vous le gardez à la maison dans quelle pièce ?.
	 euh dans la bibliothèque.
	 et vous l' avez depuis quand ?.
	 ça vous savez euh oui enfin oh depuis une dizaine d' années certainement oui.
	 euh c' était un cadeau vous l' avez acheté.
	 non j' ai dû l' acheter pour l' étude de mes enfants certainement en.
	 et **[qui]** est -ce qui s' en sert le plus souvent ?.
	 **mes enfants**.
	 hum hum et vous-même ?.
	 de temps en temps oui bien sûr.
	 est -ce que vous vous rappelez la la dernière fois que vous l' avez consulté ?.
	 euh non aucune idée alors là franchement non.
	 enfin vous cherchez quel genre de choses le plus souvent ?.
	 un un mot ou quelquefois un mot peu usuel alors on cherche l' orthographe ou le sens exact pour avoir vraiment tous les sens d' un mot ou quelque chose comme ça.
	 et du côté des encyclopédies ?.
	 non.
	 non euh.
	 par exemple les ouvrages de référence sur le français sur euh l' art d' écrire les difficultés du français l' usage ?.
	 non.
	 non ?.
	 c' est un tort d' ailleurs.
	 ah bon ? comment ça ?.
	 oui je je devr- c' est toujours utile ah oui d' en posséder.
	 est -ce que vous faites des mots-croisés ?.
	 rarement rarement quelquefois quand je me trouve dans le train ou ou ou un dimanche après-midi où je sais vraiment plus quoi faire.
	 ah bon.
	
 * [u-MENTION-jmuzerelle_1300739009468]
	.
	 accent et tout.
	 ah bon.
	 en général même avec l' accent un peu de travers je veux dire l' accent l' orthographe.
	 faut bien que vous importiez quelque chose.
	 est -ce que d' après vous euh il y a des différences dans la façon de parler selon le milieu social ?.
	 oh certainement ça ça certainement.
	 ces ces différences sont très grandes ou.
	 oui oui je pense.
	 et **[quel genre de différences]** surtout ?.
	 bien vous savez euh justement je crois qu' **une personne qui a étudié le latin dès dès son enfance euh a un français beaucoup plus beaucoup mieux construit** beaucoup plus châtié si j' ose dire.
	 oui.
	 et euh c' est pas péjoratif hein ce que je vous dis mais je crois que beaucoup d' ouvriers emploient énormément d' argot et cetera quoique euh on l' emploie un peu dans toutes les classes mais par snobisme.
	 oui.
	 est -ce que vous trouvez que les gens parlent de mieux en mieux ou de plus en plus mal ou ?.
	 plus mal.
	 ah bon ?.
	 de quoi s' agit- il ?.
	 de l' argot.
	 ah bon.
	 et puis d' un laisser-aller général j' ai l' impression enfin c' est personnel hein mon impression.
	 oui mais ce qui nous intéresse c' est votre opinion personnelle.
	 je pense.
	 quand est -ce que vous avez écrit pour la dernière fois ?.
	 de littéral dire littéralement écrit.
	 écrit.
	 oui.
	
 * [u-MENTION-aboyer_1296393544544]
	.
	 hm.
	 hélas et en français c' est très difficile.
	 ah quel genre de difficultés ?.
	 euh c' est nous avons des des complications des mots qui s' écrivent euh oh y a quelquefois on ne sait pas s' ils sont masculins ou féminins y a un tas de choses comme ça.
	 je dois dire mon rêve ce serait d' abolir le genre des règles de grammaire étant donné que ça n' existe pas en anglais.
	 ben oui oui vous êtes des petits c' est dur favorisés hein oh oui oui ça ne m' étonne pas.
	 un tel travail.
	 est -ce que vous seriez favorable à une réforme de l' orthographe ?.
	 certainement oui oh oui je pense si on arrivait à simplifier oui.
	 et euh entre vous et votre femme **[qui]** est -ce qui écrit habituellement à vos amis communs ?.
	 ah c' est très compliqué parce que ma femme n' est pas française.
	 ah bon.
	 ma femme est italienne alors quand il s' agit d' écrire en Italie automatiquement évidemment euh **c'** est **elle** qui écrit et en France **c'** est **moi**.
	 ah bon donc répartition des tâches selon la langue.
	 oui.
	 voilà.
	 elle parle le français bien sûr moi je parle italien mais enfin chacun écrit dans sa langue maternelle c' est normal.
	 on a toujours plus de facilité en fin de compte donc ça c' est vous qui qui vous occupez des papiers administratifs ?.
	 c' est ça.
	 hm hm et dans ce cas -là là donc y a une différence de langue maternelle là que la question suivante ne s' applique pratiquement pas parce qu' il s' agit de savoir à votre avis qui entre vous deux manie le français avec le plus de facilité.
	 problème est résolu d' avance.
	 problème.
	 et vous-même combien de lettres est -ce que vous écrivez en moyenne par mois pour votre travail d' un côté et sur le plan personnel de l' autre ?.
	 oh sur le plan personnel j' écris très rarement hein ? pour mon travail évidemment je j' envoie plusieurs lettres par jour certainement.
	 euh évidemment les les lettres ou la correspondance ayant rapport à votre travail vous gardez mais est -ce que vous gardez les lettres qu' on vous envoie ?.
	 non.
	 les lettres personnelles non ?.
	 non non non.
	 euh enfin vous m' avez déjà dit que parfois vous faites le brouillon avant de dicter.
	
 * [u-MENTION-jmuzerelle_1300998821095]
	est -ce que euh est -ce que vous prenez des sanctions ?.
	 oui enfin.
	 je rêve pas.
	 faut que je pose la question.
	 je réagis.
	 bon.
	 et est -ce que vos parents faisaient attention à votre façon de.
	 ah oui.
	 oui c' était c' était surtout votre père ou votre mère ?.
	 les deux.
	 les deux et pour **[quel genre de choses]** ?.
	 à peu près pour **la même raison** mais seulement c' était moins développé dans mon temps enfin c' était une impression à moi j' ai l' impression que c' était moins développé que maintenant.
	 ah bon.
	 hm hm ce laisser-aller.
	 euh est -ce qu' on prenait des sanctions ?.
	 oh oui.
	 quel genre ?.
	 je sais pas selon l' âge euh quand j' étais très jeune ça on vous privait de dessert euh euh évidemment quand on est plus âgé euh ça euh c- c' est surtout des réprimandes mais enfin y avait une réaction très nette.
	 bien bien bien alors maintenant ah oui euh italienne.
	 euh vous avez combien d' enfants ?.
	 quatre.
	 quatre enfants.
	 et euh votre profession ça s' appelle comment ?.
	 ah c' est compliqué je fais des vitraux.
	 oui.
	 je suis peintre-verrier.
	 c' est le mot que je cherchais.
	 et en même temps j' ai une entreprise de peinture euh décoration peinture en bâtiments décoration.
	 et euh vous êtes à Orléans depuis quand ?.
	 depuis ma naissance.
	 oui.
	
 * [u-MENTION-jmuzerelle_1301000962143]
	n sûr.
	 hm euh est -ce que vous l' écoutez beaucoup ?.
	 non.
	 non enfin la chaîne préférée ?.
	 alors ç- je sais pas c' est toujours la même chaîne c' est la celle où y a le plus de musique.
	 hm hm.
	 mais j- elle est toujours réglée je tourne le bouton et.
	 ah bon.
	 euh la télévision ?.
	 oui.
	 vous regardez ou écoutez je sais jamais **[quel verbe]** employer.
	 euh les deux.
	 euh eh bien euh pas souvent non hm j' essaie de trier un peu les programmes qui sont pas toujours intéressants hélas.
	 enfin quel genre d' émissions est -ce que vous choisissez ?.
	 quand il y a un bon film euh quelques variétés mais faut pas en abuser.
	 et le cinéma vous y allez ?.
	 c' est très bizarre.
	 hum ?.
	 je peux rester un an sans aller au cinéma puis nous irons trois semaines de suite.
	 hm euh quel genre de films ?.
	 je suis l' homme très très pacifique mais je vais voir des films de guerre.
	 faut maintenir l' équilibre.
	 sans doute oui.
	 est -ce que à votre avis la radio la télévision le cinéma ce sont des instruments de culture ?.
	 oui je pense si c' est bien employé oui.
	
 * [u-MENTION-aboyer_1298371211388]
	hm est -ce qu' il y a des polarisations ?.
	 oui ben c' est toujours ma ma manie je lis énormément de de livres sur la dernière guerre euh euh mais en dehors en dehors justement de de ces revues d' art ou des choses comme ça oui.
	 et une question à laquelle vous répondez par oui ou par non.
	 hm hm.
	 ou à laquelle vous ne répondez pas.
	 hm hm.
	 est -ce qu' il y a un parti politique qui représente vos opinions ?.
	 non.
	 non est -ce que je peux vous demander de **[quel côté]** vous vous placez politiquement dans le spectre ?.
	 je fais pas du tout de politique mais enfin je penche plutôt vers **le centre**.
	 hm.
	 **le centre gauche** si vous voulez si vous voulez des nuances.
	 j' adore les nuances surtout lorsque elles en sont contradictoires bon voilà pour les questions fermées.
	 oui.
	 maintenant on peut passer aux choses sérieuses aux choses plus intéressantes.
	 ah oui.
	 vous m' avez dit tout à l' heure que vous êtes né à Orléans.
	 oui.
	 et que vous avez cette entreprise d' un côté de la peinture décoration et de l' autre côté euh de.
	 vitraux.
	 vitraux.
	 qu' est -ce qui vous a amené dans ce dans ce métier ?.
	 bien voyez- vous euh.
	 ou profession ah je ne sais plus quel mot employer.
	 ce métier.
	 mon père avant moi n' est -ce pas ?.
	 oui.
	 je suis donc né je suis né là-dedans.
	
 * [u-MENTION-aboyer_1298395437362]
	.
	 maintenant on peut passer aux choses sérieuses aux choses plus intéressantes.
	 ah oui.
	 vous m' avez dit tout à l' heure que vous êtes né à Orléans.
	 oui.
	 et que vous avez cette entreprise d' un côté de la peinture décoration et de l' autre côté euh de.
	 vitraux.
	 vitraux.
	 qu' est -ce qui vous a amené dans ce dans ce métier ?.
	 bien voyez- vous euh.
	 ou profession ah je ne sais plus **[quel mot]** employer.
	 ce métier.
	 mon père avant moi n' est -ce pas ?.
	 oui.
	 je suis donc né je suis né là-dedans.
	 hm hm.
	 n' est -ce pas ? et ça les vitraux par exemple m' ont toujours toujours toujours passionné.
	 oui.
	 c' est vraiment euh vraiment je suis né là-dedans.
	 oui.
	 et puis alors y a quelques années euh j' ai voulu étendre un peu mon activité et c' est à ce moment -là que j' ai une entreprise d créée peinture décoration mais euh si vous voulez y a quand même un certain un rapport parce que euh je fais pas euh quarante logements euh tous pareils euh je travaille que pour des particuliers et on arrange un salon ou euh enfin c' est vraiment de la décoration donc si vous voulez ça reste un petit peu dans mon premier élément et puis très souvent ça se complète si je fais un appartement il est possible que je fasse un vitrail en même temps enfin voilà c' est pour ça.
	 oui alors c' est euh l' agencement total ?.
	 oui et puis alors j' aime beaucoup la les meubles anciens les choses comme ça alors très souvent aussi je je fais acheter par mes clients euh certains meubles euh pour pour compléter la décoration.
	 ah oui euh dans ce cas -là évidemment il y il y a énormément de de choix personnel et de personnalité qui entre oui.
	 là-dedans.
	 ben oui si vous voulez mais enfin il faut tenir compte aussi du goût du client alors il faut il faut les orienter il faut les pousser faut même les violer de temps en temps parce que enfin bon enfin on y arrive quoi.
	
 * [u-MENTION-aboyer_1299172384364]
	la connais très bien oui oui.
	 euh moi aussi j' en suis très impressionné.
	 oui.
	 mais c' est quoi au juste comme technique ?.
	 c' est du polyester.
	 oui enfin.
	 qui sont fait par oui qui sont créées par un de mes amis justement avec qui je fais beaucoup de vitraux.
	 extérieures.
	 hm euh et s' il fallait classer ce travail ce serait dans **[quelle catégorie]** ?.
	 au point de vue artistique ou au point de vue technique ?.
	 les deux étant donné que c' est tout le bâtiment qui est ça comprend tout le bâtiment.
	 moi je trouve ça très intéressant c' est peut-être qu' une expérience.
	 oui.
	 tout du moins au point de vue polyester hein ?.
	 oui euh je crois qu' on arrivera à à pousser ces techniques -là et à avoir des résultats satisfaisants mais là c' est plutôt une expérience oui.
	 au point de vue durée dans le temps je sais pas ce que ça va donner.
	 ah oui.
	 mais enfin je trouve ça intéressant d' avoir des des grands murs translucides euh moi j' aime bien.
	 ah oui ç- il y a ça crée une atmosphère très spéciale.
	 oui.
	 très propice.
	 qui a remué un peu toutes les vieilles dames d' Orléans mais enfin.
	 est -ce qu' on a réagi ?.
	 c' est très curieux c' est ou on est pour ou on est contre.
	 bon signe.
	 oui c' est c' est plutôt bon signe évidemment à partir d' un certain âge on a réagi euh enfin c- ce que je peux dire le mauvais sens on a dit ah c' est plus notre église c' est plus l' église traditionnelle on peut pas prier là-dedans on.
	
