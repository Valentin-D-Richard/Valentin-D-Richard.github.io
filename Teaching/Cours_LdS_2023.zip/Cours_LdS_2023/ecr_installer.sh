#! /bin/bash

# Verifying if ecr is already installed
if [[ -f $HOME/bin/ecr ]]
then
    echo "ecr already installed" >&2
    exit 1
fi

cd ~

# Creating ~/bin directory
if [[ -e bin ]]
then
    [[ -f bin ]] && { echo "Error: exixting bin file" >&2 ; exit 2 ; }
else
    mkdir bin
fi

# Adding ~/bin to path
cd bin
if [[ -f ~/.bashrc ]]
then
    echo 'export PATH=$PATH:'"$HOME/bin" >> ~/.bashrc
else
    echo 'export PATH=$PATH:'"$HOME/bin" > ~/.bashrc
fi

# Downloading ecr command
wget "http://valentin-d-richard.github.io/ecr"
chmod u+x ecr
