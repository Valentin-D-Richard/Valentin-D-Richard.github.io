#!/bin/bash

# Cas sans paramètre
if [[ $# == 0 ]]
then
    echo 1
    exit
fi

# Sur des entiers seulement:
# echo $(( $1 * $2 ))

# Sur les flottants
echo "$1 * $2" | bc
