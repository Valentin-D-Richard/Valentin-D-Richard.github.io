#!/bin/bash

# Test

if [[ $# > 1 ]]
then
    echo "Un seul paramètre est requis" >&2
    exit 1
fi

ls | grep "$1$"
