#! /bin/bash

### Traitement des paramètres

# Cas 1 : un seul paramètre
if (( $# == 1 ))
then
    FICHIER="$1"
    NOMBRE="-1" # Ma convention pour indiqué qu'aucun nombre n'a été donné

# Cas 2 : 2 paramètre : fichier et nombre
elif (( $# == 2 ))
then
    # Cas 2.1 : fichier en premier paramètre et nombre en deuxième paramètre
    # on teste que le deuxième paramètre est
    # un nombre entier positif en base décimale
    # en testant si grep reconnait le motif suivant
    # (cad. renvoie une chaine de caractères non vide)
    if [[ ! -z $(echo "$2" | grep -E "^(0|[1-9][0-9]*)$") ]]
    then
	FICHIER="$1"
	NOMBRE="$2"
	
    # Cas 2.2 : fichier en premier paramètre et nombre en deuxième paramètre
    else
	FICHIER="$2"
	NOMBRE="$1"
    fi
fi


### Vérification des paramètres
if [[ ! -f "$FICHIER" ]]
then
    echo "Le fichier $FICHIER n'existe pas" >&2
    exit 3
fi


### Affichage du résultat
if [[ $NOMBRE == "-1" ]] ## Cas 1
then
    sort "$FICHIER"
    
else # Cas 2
    sort "$FICHIER" | head -n "$NOMBRE"
fi
