#! /bin/bash

### Vérification des paramètres
if [[ ! -f "$1" ]]
then
    echo "Le fichier $1 n'existe pas" >&2
    exit 3
fi


### Traitement des différents cas et affichage du résultat

# Cas 1 : un seul paramètre
if [[ -z $2 ]]
then
    # Tri
    cat "$1" | sort

# Cas 2 : le fichier en premier paramètre et le nombre en deuxième
else
    # Tri puis limitation aux $2 premières lignes
    cat "$1" | sort | head -n "$2"
fi

