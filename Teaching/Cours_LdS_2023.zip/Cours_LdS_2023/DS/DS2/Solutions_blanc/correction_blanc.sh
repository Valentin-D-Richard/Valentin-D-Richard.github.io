#! /bin/bash

# All questions have a maximum number of 6 points.

ED="../../Solutions_blanc" # Evaluation directory
G_FILE="../Notes_blanc.csv" # Grade file
COM_FILE="commentaires.txt"
PARAM="grade" # grade = writes the grade in the grade file
              # show  = shows the answers (buffer is G_FILE)
ARGC=$# # Number of arguments

########## Helping functions

function add () {
    # Adds 6 or $2 points to question n°$1 of current exercise
    
    (( $# != 1 && $# != 2 )) && { echo "Internal error" >&2 ; return 1 ; }

    Q=$(( $1 - 1 ))
    (( $# == 2 )) && GRADE=$2 || GRADE=6

    GRADES[$Q]=$(( ${GRADES[$Q]} + $GRADE ))
}

function initialize_ex () {
    # Initializes exercise n°$1
    
    (( $# != 1 )) && { echo "Internal error" >&2 ; return 1 ; }

    FILE="exo${1}.sh"
    GRADES=(0 0 0 0)

    # Checks whether the files exists, and if so, adds x permission
    if [[ ! -f $FILE ]]
    then
	return 2
    else
	[[ ! -x $FILE ]] && chmod u+x $FILE
	ecr $FILE
    fi
    return 0 # Necessary !!!
}

function results () {
    # Create csv fields displaying the question grades of the current exercise
    # Or displays $G_FILE if option "show" and opens exo$1.sh

    (( $# == 0 )) && { echo "Internal error" >&2 ; return 1 ; }
    
    if [[ $PARAM ==  "grade" ]]
    then
	FIELDS=""
	for GRADE in ${GRADES[@]}
	do
	    FIELDS+="${GRADE},"
	done
	# The last extra field is for code human-check
	if (( $ARGC == 0 )) # If a group name has not been given
	then
	    printf "${FIELDS}," >> ../$G_FILE # puts in the grade file
	else
	    echo "${FIELDS}," # prints to the terminal
	fi
    else # PARAM == "show"
	cat ../$G_FILE
	printf "" > ../$G_FILE # reset $G_FILE
	echo ""

	IDX="0"
	for GRADE in ${GRADES[@]}
	do
	    echo "q$IDX) ${GRADE:-0}/6" >> $COM_FILE
	    IDX=$(($IDX + 1))
	done
	echo "" >> $COM_FILE
	emacs "exo${1}.sh" &
    fi
}

function show () {
    #  If PARAM == "show", prints parameters $n for n>=3, preceeded by
    # "# Question $1 (expected $2)"

    (( $# < 3 )) && { echo "Internal error" >&2 ; return 1 ; }

    if [[ $PARAM == "show" ]]
    then
	echo "# Question $1 (expected $2)"
	shift
	shift
	echo "$@"
    fi
}

function display () {
    # Displays a message that we start correcting exercise n°$1

    (( $# == 0 )) && { echo "Internal error" >&2 ; return 1 ; }

    echo "***** exo$1 *****"
    [[ $PARAM == "show" ]] && echo "***** exo$1 *****" >> $COM_FILE
}

########## Exercises

function exo1 () {
    # Initialises and if file error is encountered, does not assign grades
    initialize_ex 1 || { return 0 ; }

    # Q1
    RESULT=$(timeout 1s ./$FILE 9 2> /dev/null | sed 's/[^0-9]//g')
    ANS="144"
    (( "$RESULT" == $ANS )) && add 1
    show 1 "$ANS" "$RESULT"

    # Q2
    timeout 1s ./$FILE 2> exo1.error > /dev/null
    ERR=$?
    ANS="Message d'erreur et code d'erreur de 1"
    (( $ERR == 1 )) && add 2 3
    RESULT=$(cat exo1.error)
    [[ ! -z "$RESULT" ]] && add 2 3
    show 2 "$ANS" "$RESULT" "$ERR"

    # Q3
    RESULT=$(timeout 1s ./$FILE 7.3 2> /dev/null | sed 's/[^0-9.]//g')
    ANS="116.8"
    [[ "$RESULT" == "$ANS" ]] && add 3
    show 3 "$ANS" "$RESULT"

    # Q4
    RESULT="$(timeout 1s ./$FILE 9 lb 2> /dev/null)"
    ANS="144 oz"
    [[ "$RESULT" == "$ANS" ]] && add 4
    show 4 "$ANS" "$RESULT"
}


function exo2 () {
    # Initialises and if file error is encountered, does not assign grades
    initialize_ex 2 || { return 0 ; }

    # Q1
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval 2> /dev/null)
    ANS='''bouteille
crayon
feuille
livre
ordinateur
pain
souris
téléphone'''
    [[ "$RESULT" == "$ANS" ]] && add 1
    show 1 "$ANS" "$RESULT"

    # Q2
    timeout 1s ./$FILE nonexistantfile 2> exo1.error > /dev/null
    ERR=$?
    ANS="Message d'erreur et code d'erreur de 3"
    (( $ERR == 3 )) && add 2 3
    RESULT=$(cat exo1.error)
    [[ ! -z "$RESULT" ]] && add 2 3
    show 2 "$ANS" "$RESULT" "$ERR"

    # Q3
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval 3 2> /dev/null)
    ANS='''bouteille
crayon
feuille'''
    [[ "$RESULT" == "$ANS" ]] && add 3
    show 3 "$ANS" "$RESULT"

    # Q4
    RESULT=$(timeout 1s ./$FILE 3 $ED/exo2.eval 2> /dev/null)
    ANS='''bouteille
crayon
feuille'''
    [[ "$RESULT" == "$ANS" ]] && add 4
    show 4 "$ANS" "$RESULT"
}




########## Main function
USAGE='USAGE: correction.sh [-s] [student_dir]
Evaluates the student directories
\t-s\t\tprints the notes and answers in the terminal instead of the grade file
\tstudent_dir\tevaluates this directory\n'

# Parameters
if [[ $1 == "--help" ]] ; then printf "$USAGE" ; exit 0 ; fi

if (( $# == 0 ))
then
    TAB=( $(ls) )
    # Initializing grade sheet
    # echo "Nom,1.1,1.2,1.3,1.4,1.v,2.1,2.2,2.3,2.4,2.v,3.1,3.2,3.3,3.4,3.v,Total,Note" > $G_FILE
    # echo "Max,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,=SUM(B2:P2),20" >> $G_FILE
    echo "Nom,1.1,1.2,1.3,1.4,1.v,2.1,2.2,2.3,2.4,2.v,Total,Note" > $G_FILE
    echo "Max,6,6,6,6,6,6,6,6,6,6,=SUM(B2:K2),20" >> $G_FILE
else
    if [[ $1 == "-s" ]] # show the results instead of writing the grades
    then
	PARAM="show"
	G_FILE="buffer"
	printf "" > $G_FILE
	shift
    fi
    TAB=( "$@" )
fi


# Computing students grade
i=0 # counter
for DIR in "${TAB[@]}"
do
    if [[ -d $DIR ]]
    then
	# Append student name
	echo "Notation de $DIR"
	[[ $PARAM == "grade" ]] && printf "${DIR}," >> $G_FILE
	cd "$DIR"
	touch $COM_FILE
	[[ $PARAM == "show" ]] && printf "${DIR}\t/20\n\n" >> $COM_FILE

	display 1
	exo1 >> ../$G_FILE
	results 1

	display 2
	exo2 >> ../$G_FILE
	results 2

	LINE=$(($i + 3))
	#string="=SUM(B${LINE}:P${LINE}),=MIN(20;Q${LINE} / Q\$2 * 20)"
	string="=SUM(B${LINE}:K${LINE}),=MIN(20;L${LINE} / L\$2 * 20)"
	[[ $PARAM == "grade" ]] && echo "$string" >> ../$G_FILE

	emacs $COM_FILE &
	cd ..
	i=$(($i+1))
    fi
done

if [[ $PARAM == "grade" ]]
then
    LINE=$(($i + 2))
    #echo ",Moyenne par question,,,,,,,,,,,,,,,,Moyenne,Max,Min" >> $G_FILE
    #string=",=AVERAGE(B3:B${LINE}),,,,,,,,,,,,,,,,"
    #string+="=AVERAGE(R3:R${LINE}),=MAX(R3:R${LINE}),=MIN(R3:R${LINE})"
    echo ",Moyenne par question,,,,,,,,,,,Moyenne,Max,Min" >> $G_FILE
    string=",=AVERAGE(B3:B${LINE}),,,,,,,,,,,"
    string+="=AVERAGE(M3:M${LINE}),=MAX(M3:M${LINE}),=MIN(M3:M${LINE})"
    echo "$string" >> $G_FILE
fi

echo "$i élève(s) noté(e)(s)"



