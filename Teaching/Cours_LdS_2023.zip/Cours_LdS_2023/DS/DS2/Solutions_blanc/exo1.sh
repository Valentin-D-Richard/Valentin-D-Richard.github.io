#! /bin/bash

# Test sur le nombre de paramètres donnés
if [[ -z "$@" ]]  # ou :  if (( $# == 0 ))
then
    echo "Le programme requiert au moins 1 argument." >&2
    exit 1
fi


# Calcul de la valeur
LIVRES="$1"
ONCES=$(echo "$LIVRES * 16" | bc -l)


# Ajout potentiel de l'unité, et affichage
if [[ ! -z $2 && $2 == "lb" ]] ; then
    echo "$ONCES oz"
else
    echo "$ONCES"
fi
