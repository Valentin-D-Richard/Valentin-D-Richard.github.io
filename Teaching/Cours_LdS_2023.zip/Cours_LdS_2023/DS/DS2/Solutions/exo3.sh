#! /bin/bash

### Vérification des paramètres

if [[ ${1:(-4):4} != ".csv" ]]
then
    echo "Un fichier csv est requis" >&2
    exit 3
fi


# On demande que chaque virgule soit précédée d'un caractère qui n'est pas '\'
# On n'oublie pas de prendre en compte que les deux virgules peuvent se suivre
# Ou que la première peut être en début de chaine de caractères
grep -E "(^|[^\\]),(|.*[^\\])," "$1"
