#! /bin/bash

FICHIER="$1"

### Vérification des paramètres

if [[ -d "$FICHIER" ]]
then
    echo "Le paramètre ne doit pas être un dossier" >&2
    exit 2
fi

# On exclu le cas où le premier caractère est déjà un point
if [[ ${FICHIER:0:1} != "." ]]
then
    mv "$FICHIER" ".$FICHIER"
fi

