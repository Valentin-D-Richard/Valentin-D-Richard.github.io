#! /bin/bash

### Vérification du nombre de paramètres
if (( $# != 1))
then
    echo "Le script requiert exactement 1 paramètre" >&2
    exit 1
fi

# Suppression des espaces avec sed
STRING=$(echo "$1" | sed -E 's/ //g')

echo ${#STRING}
