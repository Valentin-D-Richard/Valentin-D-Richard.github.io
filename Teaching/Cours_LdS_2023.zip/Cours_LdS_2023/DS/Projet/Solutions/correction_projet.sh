#! /bin/bash

# All questions have a maximum number of 6 points.

ED="../../Solutions" # Evaluation directory
G_FILE="../Notes_projet.csv" # Grade file
PARAM="grade" # grade = writes the grade in the grade file
              # show  = shows the answers (buffer is G_FILE)
ARGC=$# # Number of arguments

########## Helping functions

function add () {
    # Adds 6 or $2 points to question n°$1 of current exercise
    
    (( $# != 1 && $# != 2 )) && { echo "Internal error" >&2 ; return 1 ; }

    Q=$(( $1 - 1 ))
    (( $# == 2 )) && GRADE=$2 || GRADE=6

    GRADES[$Q]=$(( ${GRADES[$Q]} + $GRADE ))
}

function initialize_ex () {
    # Initializes exercise n°$1
    
    (( $# != 1 )) && { echo "Internal error" >&2 ; return 1 ; }

    FILE="exo${1}.sh"
    GRADES=(0 0 0 0)

    # Checks whether the files exists, and if so, adds x permission
    if [[ ! -f $FILE ]]
    then
	return 2
    else
	[[ ! -x $FILE ]] && chmod u+x $FILE
	ecr $FILE
    fi
    return 0 # Necessary !!!
}

function results () {
    # Create csv fields displaying the question grades of the current exercise
    # Or displays $G_FILE if option "show" and opens exo$1.sh

    (( $# == 0 )) && { echo "Internal error" >&2 ; return 1 ; }
    
    if [[ $PARAM ==  "grade" ]]
    then
	FIELDS=""
	for GRADE in ${GRADES[@]}
	do
	    FIELDS+="${GRADE},"
	done
	# The last extra field is for code human-check
	if (( $ARGC == 0 )) # If a group name has not been given
	then
	    printf "${FIELDS}," >> ../$G_FILE # puts in the grade file
	else
	    echo "${FIELDS}," # prints to the terminal
	fi
    else
	cat ../$G_FILE
	printf "" > ../$G_FILE # reset $G_FILE
	echo ""
	emacs "exo${1}.sh" &
    fi
}

function show () {
    #  If PARAM == "show", prints parameters $n for n>=3, preceeded by
    # "# Question $1 (expected $2)"

    (( $# < 3 )) && { echo "Internal error" >&2 ; return 1 ; }

    if [[ $PARAM == "show" ]]
    then
	echo "# Question $1 (expected $2)"
	shift
	shift
	echo "$@"
    fi
}

function display () {
    # Displays a message that we start correcting exercise n°$1

    (( $# == 0 )) && { echo "Internal error" >&2 ; return 1 ; }

    echo "***** exo$1 *****"
}

########## Exercises

function exo1 () {
    # Initialises and if file error is encountered, does not assign grades
    initialize_ex 1 || { return 0 ; }

    # Q1
    RESULT=$(timeout 1s ./$FILE abc de0f ghi 2>&1 | head -n 1 | sed 's/[a-z]//g')
    ANS="0"
    [[ "$RESULT" == $ANS ]] && add 1
    show 1 "$ANS" "$RESULT"

    # Q2
    RESULT=$(timeout 1s ./$FILE abc de0f ghi 2>&1| head -n 1)
    ANS="0"
    [[ "$RESULT" == $ANS ]] && add 2
    show 2 "$ANS" "$RESULT"

    # Q3
    RESULT=$(timeout 1s ./$FILE abc de0f ghi 2>&1| sed -n '2p')
    ANS="$LOGNAME"
    [[ "$RESULT" == "$ANS" ]] && add 3
    show 3 "$ANS" "$RESULT"

    # Q4
    timeout 1s ./$FILE abc de0f ghi 2> exo2.error > /dev/null
    RESULT1=$(cat exo2.error | head -n 1)
    ANS="0"
    [[ "$RESULT1" == "$ANS" ]] && add 4 3
    RESULT=$(cat exo2.error | sed -n '2p')
    ANS="$LOGNAME"
    [[ "$RESULT" == "$ANS" ]] && add 4 3
    show 4 "0 et $ANS dans la sortie erreur" "$RESULT1, $RESULT"
}


function exo2 () {
    # Initialises and if file error is encountered, does not assign grades
    initialize_ex 2 || { return 0 ; }

    # Q1
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval.csv 2> /dev/null | cut -d ','  -f 1 | sort | uniq | wc -l)
    ANS='''50'''
    [[ "$RESULT" == "$ANS" ]] && add 1
    show 1 "$ANS" "$RESULT"

    # Q2
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval.csv 2> /dev/null | cut -d ',' -f 1 | sort -n | tail -n 5)
    ANS='''7308000
8598000
9457000
11177000
11440000'''
    [[ "$RESULT" == "$ANS" ]] && add 2
    show 2 "$ANS" "$RESULT"

    # Q3
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval.csv 2> /dev/null | tail -n 5 | cut -d ',' -f 1)
    ANS='''68800
8598000
2149000
64500
67200'''
    [[ "$RESULT" == "$ANS" ]] && add 3
    show 3 "$ANS" "$RESULT"

    # Q4
    RESULT=$(timeout 1s ./$FILE $ED/exo2.eval.csv 2> /dev/null | head -n 10)
    ANS='''10300,Wolfsburg
1600,Freiburg
2100,Stuttgart
2900,Koln
2900,Bayer
2900,Augsburg
2900,Berlin
2900,Hoffenheim
2900,Bochum
2900,Bochum'''
    [[ "$RESULT" == "$ANS" ]] && add 4
    show 4 "$ANS" "$RESULT"
}


function exo3 () {
    # Initialises and if file error is encountered, does not assign grades
    initialize_ex 3 || { return 0 ; }

    # Q1
    RESULT=$(timeout 1s ./$FILE 205 56 79 7 2> /dev/null | head -n 1 | sed -E 's/[^0-9.]//g' | sed -E 's/^(0?[.][0-9]{3}).*$/\1/')
    ANS="0.866"
    [[ $(echo "$RESULT == $ANS" | bc -l) ]] && add 1
    show 1 "$ANS" "$RESULT"

    # Q2
    timeout 1s ./$FILE 205 56 79 > /dev/null 2> exo3.error
    CODE=$?
    RESULT=$(cat exo3.error)
    ANS="3"
    [[ ! -z "$RESULT" ]] && add 2 3
    (( $CODE == $ANS )) && add 2 3
    show 2 "message d'erreur non vide et code de $ANS" "$RESULT, $CODE"

    # Q3
    RESULT=$(timeout 1s ./$FILE --help | sed -E 's/[0-9.]//g')
    [[ ! -z "$RESULT" ]] && add 3
    show 3 "Message non vide" "$RESULT"

    # Q4
    timeout 1s ./$FILE 205 56 79 7 > /dev/null 2> exo3.error
    RESULT=$(cat exo3.error | sed -E 's/[0-9.]//g')
    [[ ! -z "$RESULT" ]] && add 4
    show 4 "Message d'erreur" "$RESULT"
}



########## Main function
USAGE='USAGE: correction.sh [-s] [student_dir]
Evaluates the student directories
\t-s\t\tprints the notes and answers in the terminal instead of the grade file
\tstudent_dir\tevaluates this directory\n'

# Parameters
if [[ $1 == "--help" ]] ; then printf "$USAGE" ; exit 0 ; fi

if (( $# == 0 ))
then
    TAB=( $(ls) )
    # Initializing grade sheet
    echo "Nom,1.1,1.2,1.3,1.4,1.v,2.1,2.2,2.3,2.4,2.v,3.1,3.2,3.3,3.4,3.v,Total,Note" > $G_FILE
    echo "Max,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,=SUM(B2:P2),20" >> $G_FILE
    # echo "Nom,1.1,1.2,1.3,1.4,1.v,2.1,2.2,2.3,2.4,2.v,Total,Note" > $G_FILE
    # echo "Max,6,6,6,6,6,6,6,6,6,6,=SUM(B2:K2),20" >> $G_FILE
else
    if [[ $1 == "-s" ]] # show the results instead of writing the grades
    then
	PARAM="show"
	G_FILE="buffer"
	printf "" > $G_FILE
	shift
    fi
    TAB=( "$@" )
fi


# Computing students grade
i=0 # counter
for DIR in "${TAB[@]}"
do
    if [[ -d $DIR ]]
    then
	# Append student name
	echo "Notation de $DIR"
	[[ $PARAM == "grade" ]] && printf "${DIR}," >> $G_FILE
	cd "$DIR"

	display 1
	exo1 >> ../$G_FILE
	results 1

	display 2
	exo2 >> ../$G_FILE
	results 2

	display 3
	exo3 >> ../$G_FILE
	results 3

	LINE=$(($i + 3))
	string="=SUM(B${LINE}:P${LINE}),=MIN(20;Q${LINE} / Q\$2 * 20)"
	#string="=SUM(B${LINE}:K${LINE}),=MIN(20;L${LINE} / L\$2 * 20)"
	[[ $PARAM == "grade" ]] && echo "$string" >> ../$G_FILE
	
	cd ..
	i=$(($i+1))
    fi
done

if [[ $PARAM == "grade" ]]
then
    LINE=$(($i + 2))
    echo ",Moyenne par question,,,,,,,,,,,,,,,,Moyenne,Max,Min" >> $G_FILE
    string=",=AVERAGE(B3:B${LINE}),,,,,,,,,,,,,,,,"
    string+="=AVERAGE(R3:R${LINE}),=MAX(R3:R${LINE}),=MIN(R3:R${LINE})"
    #echo ",Moyenne par question,,,,,,,,,,,Moyenne,Max,Min" >> $G_FILE
    #string=",=AVERAGE(B3:B${LINE}),,,,,,,,,,,"
    #string+="=AVERAGE(M3:M${LINE}),=MAX(M3:M${LINE}),=MIN(M3:M${LINE})"
    echo "$string" >> $G_FILE
fi

echo "$i élève(s) noté(e)(s)"



