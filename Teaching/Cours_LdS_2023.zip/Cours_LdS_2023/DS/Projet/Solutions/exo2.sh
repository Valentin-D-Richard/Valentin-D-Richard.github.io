#! /bin/bash

# q1
# grep -E ",Bundesliga,[^,]+,Defender$" "$1"


# q2
# grep -E ",Bundesliga,[^,]+,Defender$" "$1" | cut -d ',' -f 1,3


# q3
# grep -E ",Bundesliga,[^,]+,Defender$" "$1" \
#     | sort -t ',' -k 2,2 \
#     | cut -d ',' -f 1,3


# q4
grep -E ",Bundesliga,[^,]+,Defender$" "$1" \
    | sort -t ',' -k 2,2 \
    | cut -d ',' -f 1,3 \
    | sed -E 's/,([A-Za-z]+) [0-9]+($| .*$)/,\1/' \
    | sed -E 's/,([^ ]+ )+([^ ]+)$/,\2/'
	   
