#! /bin/bash

USAGE='Usage: exo3.sh TP FP TN FN
Computes the F1 score'

# Aide
if [[ $1 == "--help" ]]
then
    echo "$USAGE"
    exit
fi

# Test du nombre de paramètres
if (( $# != 4 ))
then
    echo "Le script attend exactement 4 paramètres" >&2
    exit 3
fi

# Calcul du score F1
F1=$(echo "2 * $1 / (2*$1 + $4 + $2)" | bc -l)
echo $F1

# Test de la valeur
if (( $(echo "$F1 < 0.8" | bc -l) ))
then
    echo "Attention, score F1 bas !" >&2
fi
